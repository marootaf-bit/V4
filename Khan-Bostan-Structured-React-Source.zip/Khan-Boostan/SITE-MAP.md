# ساختار صفحات

| منوی اصلی | مسیر | زیرصفحه‌های مستقل |
|---|---|---|
| خانه | / | — |
| دربارهٔ شرکت | /about | /markets، /partners |
| محصولات | /products | جزئیات هر محصول: /products/:slug |
| خدمات تجارتی | /activities | /sourcing، /import، /export، /domestic-trade |
| خدمات لوجستیکی | /logistics | /process |
| پروژه‌ها | /projects | جزئیات هر پروژه: /projects/:slug |
| اخبار و رسانه‌ها | /news | /downloads؛ گالری داخل /news?view=gallery؛ جزئیات خبر: /news/:slug |
| تماس و درخواست | /contact | نوع درخواست در پارامتر kind |

دو صفحهٔ فوتر: /privacy و /terms.

مراحل همکاری از هر دو بخش خدمات قابل دسترسی است و در منوی لوجستیک گروه‌بندی شده است. صفحات جزئیات محصول، خبر و پروژه در منوی اصلی فهرست نمی‌شوند؛ از کارت‌های همان بخش باز می‌شوند. بخش اصلی هنگام ورود به زیرصفحه فعال می‌ماند.

مسیرهای سازگاری: /gallery به نمای گالری مرکز رسانه، /trade-guide به مرکز مطالب، /careers به دربارهٔ شرکت، /team به معرفی شرکت و /partners/:slug به فهرست روابط هدایت می‌شوند. این هدایت‌ها صفحهٔ محتوایی اضافی محسوب نمی‌شوند.

فرم: contact، product، sourcing، logistics، cooperation، consultation.
