import { displayDate } from '../lib/date.js'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { usePublicDict, publicItemName, publicText, publicSlug } from '../lib.jsx'
import ArrowIcon from './public/ArrowIcon.jsx'

const FALLBACK_IMAGE = '/images/trade-warehouse.webp'
const CAT = {
  news: ['خبر', 'News'], note: ['یادداشت', 'Note'], announce: ['اطلاعیه', 'Announcement'], event: ['رویداد', 'Event'],
  guide: ['راهنما', 'Guide'], insight: ['تحلیل', 'Insight'], meeting: ['دیدار', 'Meeting'], partnership: ['همکاری', 'Partnership'],
}
export const newsCat = (c, lang) => (CAT[c] ? CAT[c][lang === 'fa' ? 0 : 1] : publicText(c))

export default function NewsCard({ n }) {
  const { t, L, lang } = usePublicDict()
  const title = publicItemName(L(n.title))
  const excerpt = L(n.excerpt)
  const category = newsCat(n.category, lang)
  const [fallback, setFallback] = useState(!n.image)
  if (!title) return null
  return <Link className="tw-group tw-flex tw-h-full tw-flex-col tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-text-start tw-no-underline tw-transition-shadow hover:tw-shadow-kb motion-reduce:tw-transition-none focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={`/news/${publicSlug(n.id)}/`}>
    <div className="tw-relative tw-aspect-[16/9] tw-overflow-hidden tw-bg-kb-paper"><img src={fallback ? FALLBACK_IMAGE : n.image} alt={fallback ? '' : title} loading="lazy" onError={() => setFallback(true)} className="tw-h-full tw-w-full tw-object-cover tw-transition-transform group-hover:tw-scale-[1.03] motion-reduce:tw-transition-none motion-reduce:group-hover:tw-scale-100" />{n.featured && <span className="tw-absolute tw-start-3 tw-top-3 tw-rounded-full tw-bg-kb-gold tw-px-2.5 tw-py-1 tw-text-[10px] tw-font-bold tw-text-kb-navy">{t('featured_badge')}</span>}</div>
    <div className="tw-flex tw-flex-1 tw-flex-col tw-gap-2 tw-p-4 sm:tw-p-5"><div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2 tw-text-[11px] tw-text-kb-muted">{n.date && <time dateTime={n.date}>{displayDate(n.date, lang)}</time>}{category && <span className="tw-rounded-full tw-bg-kb-paper tw-px-2 tw-py-0.5 tw-font-bold tw-text-kb-body">{category}</span>}</div><h3 className="tw-break-words tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy">{title}</h3>{excerpt && <p className="tw-whitespace-pre-line tw-break-words tw-text-sm tw-leading-6 tw-text-kb-body">{excerpt}</p>}<span className="tw-mt-auto tw-flex tw-items-center tw-justify-between tw-gap-3 tw-pt-2"><span className="tw-text-sm tw-font-bold tw-text-kb-blue group-hover:tw-text-kb-navy">{t('read_more')}</span><span className="tw-grid tw-h-9 tw-w-9 tw-shrink-0 tw-place-items-center tw-rounded-full tw-bg-kb-paper tw-text-kb-blue group-hover:tw-bg-kb-blue group-hover:tw-text-white"><ArrowIcon /></span></span></div>
  </Link>
}
