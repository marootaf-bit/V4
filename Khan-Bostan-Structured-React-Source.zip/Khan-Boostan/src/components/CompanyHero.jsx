import Hero from './public/Hero.jsx'

export default function CompanyHero({ image, title, summary, crumbs = [], showSnapshot = false, children }) {
  return <Hero image={image} title={title} sub={summary} crumbs={crumbs.map(({to,label})=>[to,label])} showSnapshot={showSnapshot}>{children}</Hero>
}
