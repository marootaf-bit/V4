import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import CopyPageLink from './CopyPageLink.jsx'

export default function AboutProfileDownload({ profile, c, t, L, lang }) {
  if (!profile || !profile.file) return null
  const title = L(profile.title) || t('profile_t')
  return <section id="about-profile" className="tw-scroll-mt-24 tw-bg-white tw-pb-7 print:tw-bg-white" aria-labelledby="about-profile-title"><SiteContainer>
    <div className="tw-grid tw-gap-4 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4 sm:tw-grid-cols-[minmax(0,1fr)_auto] sm:tw-items-center sm:tw-gap-6 sm:tw-p-5">
      <div className="tw-flex tw-min-w-0 tw-items-start tw-gap-3">
        <span className="tw-grid tw-h-11 tw-w-11 tw-shrink-0 tw-place-items-center tw-rounded-kb tw-bg-white tw-text-kb-blue" aria-hidden="true"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3.75h8l4 4v12.5H6z" /><path d="M14 3.75v4.5h4M9 13h6M9 16.5h6" /></svg></span>
        <div className="tw-min-w-0"><div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2"><h2 id="about-profile-title" className="tw-break-words tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy">{title}</h2><CopyPageLink id="about-profile" lang={lang} sectionLabel={title} /></div></div>
      </div>
      <a href={profile.file} download={profile.file.split('/').pop()} className="tw-inline-flex tw-min-h-11 tw-w-full tw-items-center tw-justify-center tw-rounded-kb tw-bg-kb-blue tw-px-5 tw-text-sm tw-font-bold tw-text-white tw-transition-colors motion-reduce:tw-transition-none hover:tw-bg-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold focus-visible:tw-ring-offset-2 sm:tw-w-auto print:tw-hidden">{c.profileDownload}</a>
    </div>
  </SiteContainer></section>
}
