export default function EmptyState({ title, copy, action }) {
  return <div className="tw-rounded-kb-lg tw-border tw-border-dashed tw-border-kb-line tw-bg-white tw-p-8 tw-text-center"><b className="tw-text-base tw-text-kb-navy">{title}</b><p className="tw-mt-2 tw-text-sm tw-leading-6 tw-text-kb-body">{copy}</p>{action}</div>
}
