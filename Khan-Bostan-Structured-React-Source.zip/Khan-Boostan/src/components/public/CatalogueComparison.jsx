function stableValue(value) {
  if (value == null) return ''
  if (typeof value === 'object') return JSON.stringify(Object.keys(value).sort().map((key) => [key, value[key]]))
  return String(value)
}

function valueText(value, L) {
  return String(L(value) ?? '').trim()
}

export default function CatalogueComparison({ products = [], categories = [], L, fa, t, onRemove, onClear }) {
  if (!products.length) return null
  const categoryName = (id) => valueText(categories.find((category) => category.id === id)?.name, L)
  const rows = [
    { id: 'category', label: t('category'), getValue: (product) => categoryName(product.category) },
    { id: 'brand', label: t('brand_l'), getValue: (product) => valueText(product.brand, L) },
    { id: 'origin', label: t('origin_l'), getValue: (product) => valueText(product.origin, L) },
    { id: 'packaging', label: t('packaging_l'), getValue: (product) => valueText(product.packaging, L) },
    { id: 'unit', label: t('unit_l'), getValue: (product) => valueText(product.unit, L) },
  ]
  const specKeys = new Map()
  for (const product of products) {
    for (const spec of product.specs ?? []) {
      const id = stableValue(spec?.k)
      if (id && !specKeys.has(id)) specKeys.set(id, valueText(spec.k, L))
    }
  }
  for (const [id, label] of specKeys) {
    rows.push({
      id: `spec-${id}`,
      label,
      getValue: (product) => valueText((product.specs ?? []).find((spec) => stableValue(spec?.k) === id)?.v, L),
    })
  }
  const visibleRows = rows.filter((row) => products.some((product) => row.getValue(product)))
  const dash = '—'

  return <section className="tw-mt-10 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 sm:tw-p-6" aria-labelledby="product-comparison-title">
    <div className="tw-flex tw-flex-wrap tw-items-start tw-justify-between tw-gap-3">
      <div>
        <h2 id="product-comparison-title" className="tw-font-head tw-text-xl tw-font-bold tw-text-kb-navy">{fa ? 'مقایسهٔ کالاها' : 'Compare products'}</h2>
        <p className="tw-mt-1 tw-max-w-2xl tw-text-xs tw-leading-5 tw-text-kb-muted">{fa ? 'خط تیره یعنی برای آن مشخصه معلوماتی در فهرست درج نشده است.' : 'A dash means no value is listed for that product.'}</p>
      </div>
      <button type="button" onClick={onClear} className="tw-min-h-9 tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-3 tw-text-xs tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{fa ? 'پاک‌کردن مقایسه' : 'Clear comparison'}</button>
    </div>

    {products.length < 2 ? <p className="tw-mt-4 tw-rounded-kb tw-bg-kb-paper tw-p-3 tw-text-sm tw-text-kb-body" role="status">{fa ? 'برای مقایسه، یک کالای دیگر انتخاب کنید.' : 'Select one more product to compare.'}</p> : <div className="tw-mt-5 tw-overflow-x-auto tw-rounded-kb-lg tw-border tw-border-kb-line">
      <table className="tw-w-full tw-min-w-[680px] tw-border-collapse tw-text-start tw-text-sm">
        <thead className="tw-bg-kb-paper">
          <tr>
            <th scope="col" className="tw-w-44 tw-border-b tw-border-kb-line tw-p-3 tw-text-start tw-font-bold tw-text-kb-navy">{fa ? 'مشخصه' : 'Attribute'}</th>
            {products.map((product) => <th scope="col" className="tw-border-b tw-border-s tw-border-kb-line tw-p-3 tw-text-start tw-align-top" key={product.id}>
              <div className="tw-flex tw-items-start tw-justify-between tw-gap-3"><span className="tw-break-words tw-font-bold tw-leading-5 tw-text-kb-navy">{valueText(product.name, L)}</span><button type="button" onClick={() => onRemove(product.id)} aria-label={`${fa ? 'حذف' : 'Remove'} ${valueText(product.name, L)} ${fa ? 'از مقایسه' : 'from comparison'}`} className="tw-flex tw-h-7 tw-w-7 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-full tw-text-lg tw-text-kb-muted hover:tw-bg-white hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">×</button></div>
            </th>)}
          </tr>
        </thead>
        <tbody>
          {visibleRows.map((row, rowIndex) => <tr className={rowIndex % 2 ? 'tw-bg-kb-paper/70' : 'tw-bg-white'} key={row.id}>
            <th scope="row" className="tw-border-b tw-border-kb-line tw-p-3 tw-text-start tw-font-bold tw-text-kb-body">{row.label}</th>
            {products.map((product) => <td className="tw-border-b tw-border-s tw-border-kb-line tw-p-3 tw-align-top tw-break-words tw-leading-6 tw-text-kb-body" key={`${row.id}-${product.id}`}>{row.getValue(product) || dash}</td>)}
          </tr>)}
        </tbody>
      </table>
    </div>}
  </section>
}
