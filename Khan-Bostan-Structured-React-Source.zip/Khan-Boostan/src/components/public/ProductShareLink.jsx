import { useState } from 'react'

export default function ProductShareLink({ lang }) {
  const [status, setStatus] = useState('')
  const fa = lang !== 'en'

  const copyLink = async () => {
    const url = new URL(window.location.href)
    url.search = ''
    url.hash = ''
    url.searchParams.set('lang', fa ? 'fa' : 'en')
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(url.href)
      else throw new Error('Clipboard unavailable')
    } catch {
      try {
        const field = document.createElement('textarea')
        field.value = url.href
        field.setAttribute('readonly', '')
        field.style.position = 'fixed'
        field.style.opacity = '0'
        document.body.appendChild(field)
        field.select()
        const copied = document.execCommand('copy')
        field.remove()
        if (!copied) throw new Error('Copy failed')
      } catch {
        setStatus(fa ? 'کپی خودکار ممکن نشد؛ پیوند را از نوار نشانی بردارید.' : 'Could not copy automatically; use the address bar link.')
        return
      }
    }
    setStatus(fa ? 'پیوند پاکِ کالا کپی شد.' : 'Clean product link copied.')
  }

  return <span className="tw-inline-flex tw-flex-col tw-items-start tw-gap-1">
    <button type="button" onClick={copyLink} className="tw-inline-flex tw-min-h-11 tw-items-center tw-gap-2 tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-4 tw-text-sm tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">
      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M10 13.5 14 9.5" /><path d="M8.2 15.3 6.8 16.7a4 4 0 0 1-5.7-5.7l4-4a4 4 0 0 1 5.7 0" /><path d="m15.8 8.7 1.4-1.4a4 4 0 0 1 5.7 5.7l-4 4a4 4 0 0 1-5.7 0" /></svg>
      {fa ? 'کپی پیوند پاک کالا' : 'Copy clean product link'}
    </button>
    <span className="tw-sr-only" role="status" aria-live="polite">{status}</span>
  </span>
}
