import SiteContainer from './SiteContainer.jsx'
import CopyPageLink from './CopyPageLink.jsx'

function PurposeMark({ type }) {
  const common = { width: 22, height: 22, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true }
  return <span className="tw-grid tw-h-11 tw-w-11 tw-shrink-0 tw-place-items-center tw-rounded-full tw-bg-[#FFF2DF] tw-text-kb-blue">
    {type === 'mission' ? <svg {...common}><circle cx="12" cy="12" r="8.25" /><circle cx="12" cy="12" r="3" /><path d="m14.2 9.8 5-5M16 5h3.2v3.2" /></svg> : <svg {...common}><path d="M2.8 12s3.2-6.5 9.2-6.5 9.2 6.5 9.2 6.5-3.2 6.5-9.2 6.5S2.8 12 2.8 12Z" /><circle cx="12" cy="12" r="2.8" /></svg>}
  </span>
}

export default function AboutPurposeValues({ mission, vision, fa }) {
  if (!mission && !vision) return null
  const items = [
    mission && { id: 'mission', title: fa ? 'مأموریت' : 'Mission', text: mission },
    vision && { id: 'vision', title: fa ? 'چشم‌انداز' : 'Vision', text: vision },
  ].filter(Boolean)
  return <section id="about-purpose" className="tw-scroll-mt-24 tw-bg-white tw-py-7 sm:tw-py-9 print:tw-bg-white" aria-labelledby="about-purpose-title"><SiteContainer>
    <div className="tw-flex tw-items-center tw-gap-2"><h2 id="about-purpose-title" className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{fa ? 'مأموریت و چشم‌انداز' : 'Mission & vision'}</h2><CopyPageLink id="about-purpose" lang={fa ? 'fa' : 'en'} sectionLabel={fa ? 'مأموریت و چشم‌انداز' : 'Mission & vision'} /></div>
    <div className="tw-mt-4 tw-grid tw-items-stretch tw-gap-3 md:tw-grid-cols-2 sm:tw-gap-4">
      {items.map((item) => <article className="tw-flex tw-h-full tw-flex-col tw-rounded-kb-lg tw-border tw-border-kb-line tw-border-s-2 tw-border-s-kb-gold tw-bg-kb-paper tw-p-4 sm:tw-p-5 print:tw-break-inside-avoid" key={item.id}>
        <div className="tw-flex tw-items-start tw-gap-3">
          <PurposeMark type={item.id} />
          <div className="tw-min-w-0 tw-flex-1"><h3 className="tw-font-head tw-text-lg tw-font-bold tw-text-kb-navy sm:tw-text-xl">{item.title}</h3><p className="tw-mt-3 tw-text-sm tw-leading-7 tw-text-kb-body">{item.text}</p></div>
        </div>
      </article>)}
    </div>
  </SiteContainer></section>
}
