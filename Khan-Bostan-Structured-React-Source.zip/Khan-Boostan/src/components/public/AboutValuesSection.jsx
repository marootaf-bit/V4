import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import CopyPageLink from './CopyPageLink.jsx'

export default function AboutValuesSection({ values, L, fa, t }) {
  if (!values.length) return null
  return <section id="about-values" className="tw-scroll-mt-24 tw-bg-kb-paper tw-py-8 sm:tw-py-11 print:tw-bg-white" aria-labelledby="about-values-title"><SiteContainer>
    <Eyebrow>{t('nav_about')}</Eyebrow>
    <div className="tw-mt-2 tw-flex tw-items-center tw-gap-2"><h2 id="about-values-title" className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{fa ? 'ارزش‌های کاری ما' : 'Our working values'}</h2><CopyPageLink id="about-values" lang={fa ? 'fa' : 'en'} sectionLabel={fa ? 'ارزش‌های کاری ما' : 'Our working values'} /></div>
    <div className="tw-mt-4 tw-grid tw-grid-cols-1 tw-items-stretch tw-gap-3 sm:tw-grid-cols-2 lg:tw-mt-5 lg:tw-grid-cols-4">
      {values.map((value, index) => <article className="tw-flex tw-h-full tw-flex-col tw-rounded-kb-lg tw-border tw-border-kb-line tw-border-t-2 tw-border-t-kb-gold tw-bg-white tw-p-4 sm:tw-p-5 print:tw-break-inside-avoid" key={value.id ?? `${L(value.title)}-${index}`}>
        <span className="tw-inline-flex tw-h-8 tw-w-8 tw-items-center tw-justify-center tw-rounded-full tw-bg-kb-paper tw-text-xs tw-font-bold tw-text-kb-blue" aria-hidden="true">{String(index + 1).padStart(2, '0')}</span>
        {L(value.title) && <h3 className="tw-mt-3 tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy">{L(value.title)}</h3>}
        {L(value.text) && <p className="tw-mt-2 tw-flex-1 tw-text-sm tw-leading-7 tw-text-kb-body">{L(value.text)}</p>}
      </article>)}
    </div>
  </SiteContainer></section>
}
