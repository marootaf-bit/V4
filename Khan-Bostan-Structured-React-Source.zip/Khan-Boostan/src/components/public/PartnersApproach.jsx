import SiteContainer from './SiteContainer.jsx'

export default function PartnersApproach({ text, fa }) {
  if (!text) return null
  return <section className="tw-bg-kb-paper tw-py-8 sm:tw-py-10" aria-labelledby="partners-approach-title"><SiteContainer className="tw-max-w-4xl"><h2 id="partners-approach-title" className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy">{fa ? 'رویکرد ما به همکاری' : 'Our approach to cooperation'}</h2><p className="tw-mt-3 tw-text-sm tw-leading-7 tw-text-kb-body">{text}</p></SiteContainer></section>
}
