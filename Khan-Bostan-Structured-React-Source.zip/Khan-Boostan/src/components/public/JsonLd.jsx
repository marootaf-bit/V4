export default function JsonLd({ value }) {
  const json = JSON.stringify(value).replace(/</g, '\\u003c')
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: json }} />
}
