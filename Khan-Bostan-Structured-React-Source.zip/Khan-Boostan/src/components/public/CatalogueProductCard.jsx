import { Link } from 'react-router-dom'
import { publicSlug } from '../../lib.jsx'
import ArrowIcon from './ArrowIcon.jsx'
import ProductImageFrame from './ProductImageFrame.jsx'

export default function CatalogueProductCard({
  product,
  name,
  summary,
  categoryName,
  categoryId,
  className = '',
  lang,
  fa,
  t,
  sharedImage = false,
  returnTo,
  canCompare = false,
  selectedForComparison = false,
  compareDisabled = false,
  onToggleCompare,
}) {
  const detailParams = new URLSearchParams({ lang: lang === 'en' ? 'en' : 'fa' })
  if (returnTo) detailParams.set('from', returnTo)
  const to = `/products/${publicSlug(product.id)}?${detailParams.toString()}`
  const linkState = returnTo ? { returnTo } : undefined
  const statusLabel = t(`status_${product.status}`, fa ? 'نیازمند استعلام' : 'Requires inquiry')

  return <article className={`tw-flex tw-h-full tw-flex-col tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-transition-shadow hover:tw-shadow-kb motion-reduce:tw-transition-none ${className}`.trim()}>
    <Link to={to} state={linkState} className="tw-group tw-block tw-aspect-[4/3] tw-overflow-hidden tw-bg-kb-paper focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue"><ProductImageFrame src={product.image} alt={name} categoryId={categoryId} categoryName={categoryName} sharedImage={sharedImage} fa={fa} /></Link>
    <div className="tw-flex tw-flex-1 tw-flex-col tw-p-5">
      <div className="tw-flex tw-min-h-10 tw-flex-wrap tw-items-center tw-gap-2 tw-text-[10px] tw-font-bold tw-text-kb-muted">
        {product.featured && <span className="tw-rounded-full tw-bg-kb-gold tw-px-2.5 tw-py-1 tw-text-kb-navy">{t('featured_badge')}</span>}
        {categoryName && <span className="tw-rounded-full tw-bg-kb-paper tw-px-2.5 tw-py-1 tw-text-kb-body">{categoryName}</span>}
      </div>
      <h3 className="tw-mt-2 tw-break-words tw-text-lg tw-font-bold tw-leading-6 tw-text-kb-navy"><Link className="hover:tw-text-kb-blue focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={to} state={linkState}>{name}</Link></h3>
      {summary && <p className="tw-mt-2 tw-whitespace-pre-line tw-break-words tw-text-sm tw-leading-6 tw-text-kb-body">{summary}</p>}

      <div className="tw-mt-auto tw-flex tw-flex-wrap tw-items-center tw-justify-between tw-gap-3 tw-border-t tw-border-kb-line tw-pt-4">
        {product.status ? <span className="tw-text-[11px] tw-font-bold tw-leading-5 tw-text-kb-muted"><span>{fa ? 'وضعیت: ' : 'Status: '}</span><span className="tw-text-kb-body">{statusLabel}</span></span> : <span />}
        {canCompare && <label className={`tw-inline-flex tw-min-h-8 tw-items-center tw-gap-2 tw-rounded-full tw-px-2 tw-text-xs tw-font-bold focus-within:tw-outline-none focus-within:tw-ring-2 focus-within:tw-ring-kb-blue ${compareDisabled ? 'tw-cursor-not-allowed tw-text-kb-muted' : 'tw-cursor-pointer tw-text-kb-blue hover:tw-bg-kb-paper'}`}>
          <input type="checkbox" checked={selectedForComparison} disabled={compareDisabled} onChange={onToggleCompare} title={compareDisabled ? (fa ? 'حداکثر سه کالا را مقایسه کنید' : 'Compare up to three products') : undefined} className="tw-h-4 tw-w-4 tw-accent-kb-blue" />
          <span>{fa ? 'مقایسه' : 'Compare'}</span><span className="tw-sr-only">: {name}</span>
        </label>}
      </div>
      <Link className="tw-mt-3 tw-inline-flex tw-min-h-9 tw-items-center tw-gap-2 tw-text-xs tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={to} state={linkState}>{t('view_details')}<ArrowIcon /></Link>
    </div>
  </article>
}
