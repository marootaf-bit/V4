import { useState } from 'react'

export default function CopyPageLink({ id, lang, sectionLabel = '' }) {
  const [status, setStatus] = useState('')
  const fa = lang !== 'en'
  const actionLabel = fa ? `کپی پیوند بخش ${sectionLabel}` : `Copy link to ${sectionLabel}`

  const copyLink = async () => {
    const url = new URL(window.location.href)
    url.hash = id
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(url.href)
      else {
        const field = document.createElement('textarea')
        field.value = url.href
        field.setAttribute('readonly', '')
        field.style.position = 'fixed'
        field.style.opacity = '0'
        document.body.appendChild(field)
        field.select()
        const copied = document.execCommand('copy')
        field.remove()
        if (!copied) throw new Error('Clipboard unavailable')
      }
      setStatus(fa ? 'پیوند کپی شد' : 'Link copied')
    } catch {
      setStatus(fa ? 'کپی خودکار ممکن نشد؛ پیوند بخش را از نوار نشانی بردارید' : 'Could not copy; use the section link in the address bar')
    }
    window.setTimeout(() => setStatus(''), 3000)
  }

  return <span className="tw-inline-flex tw-items-center">
    <button type="button" onClick={copyLink} aria-label={actionLabel} title={actionLabel} className="tw-inline-flex tw-h-9 tw-w-9 tw-items-center tw-justify-center tw-rounded-full tw-border tw-border-kb-line tw-bg-white tw-text-kb-blue hover:tw-border-kb-blue hover:tw-bg-kb-paper focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue print:tw-hidden">
      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M10 13.5 14 9.5" /><path d="M8.2 15.3 6.8 16.7a4 4 0 0 1-5.7-5.7l4-4a4 4 0 0 1 5.7 0" /><path d="m15.8 8.7 1.4-1.4a4 4 0 0 1 5.7 5.7l-4 4a4 4 0 0 1-5.7 0" /></svg>
    </button>
    <span className="tw-sr-only" role="status" aria-live="polite">{status}</span>
  </span>
}
