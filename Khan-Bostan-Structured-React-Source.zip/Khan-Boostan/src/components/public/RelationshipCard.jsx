import { Link } from 'react-router-dom'
import ArrowIcon from './ArrowIcon.jsx'
import { usableLogo } from '../../pages/company-assets.js'
import { publicItemName } from '../../lib.jsx'

function safeWebsite(value) {
  if (!value) return ''
  try {
    const url = new URL(value)
    return ['https:', 'http:'].includes(url.protocol) ? url.href : ''
  } catch { return '' }
}

function safeIsoDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return ''
  const date = new Date(`${value}T12:00:00Z`)
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value ? value : ''
}

export default function RelationshipCard({ entry, kind, L, lang, label, c, className = '' }) {
  const logo = usableLogo(entry.logo)
  const website = safeWebsite(entry.website)
  const title = publicItemName(L(entry.name))
  if (!title) return null
  const since = String(entry.since ?? '')
  const verified = entry.verified === true && entry.demo !== true
  const source = verified ? L(entry.verificationSource) : ''
  const permission = verified ? L(entry.publicationPermission) : ''
  const verifiedAt = verified ? safeIsoDate(entry.verifiedAt) : ''
  const detailLink = verified && entry.public === true && entry.id ? `/partners/${encodeURIComponent(entry.id)}` : ''
  return <article className={`tw-flex tw-min-h-full tw-flex-col tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 ${className}`.trim()} data-relation-kind={kind}>
    <div className="tw-flex tw-items-center tw-gap-3">{logo ? <img className="tw-h-12 tw-w-16 tw-shrink-0 tw-rounded-kb tw-border tw-border-kb-line tw-bg-white tw-object-contain tw-p-1" src={logo} alt="" width="70" height="52" loading="lazy" decoding="async" /> : <span className="tw-flex tw-h-12 tw-w-12 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-kb tw-bg-kb-paper tw-text-lg tw-font-bold tw-text-kb-blue" aria-hidden="true">{title.trim().charAt(0) || '•'}</span>}<div className="tw-min-w-0"><h3 className="tw-break-words tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy">{title}</h3></div></div>
    <div className="tw-mt-2 tw-flex tw-flex-wrap tw-items-center tw-gap-2 tw-text-xs tw-text-kb-muted">{entry.country && L(entry.country) && <span>{L(entry.country)}</span>}{since && <><span aria-hidden="true">·</span><span>{since}</span></>}</div>
    <span className="tw-mt-2 tw-inline-flex tw-self-start tw-rounded-full tw-bg-kb-paper tw-px-2.5 tw-py-1 tw-text-[10px] tw-font-bold tw-text-kb-blue">{label}</span>
    {entry.field && L(entry.field) && <p className="tw-mt-3 tw-whitespace-pre-line tw-break-words tw-text-xs tw-leading-5 tw-text-kb-muted">{L(entry.field)}</p>}
    {entry.description && L(entry.description) && <p className="tw-mt-2 tw-whitespace-pre-line tw-break-words tw-text-sm tw-leading-6 tw-text-kb-body">{L(entry.description)}</p>}
    {verified && (source || permission || verifiedAt) && <dl className="tw-mt-3 tw-grid tw-gap-2 tw-border-t tw-border-kb-line tw-pt-3 tw-text-xs">
      {source && <div><dt className="tw-font-bold tw-text-kb-muted">{c.sourceLabel}</dt><dd className="tw-mt-0.5 tw-text-kb-body">{source}</dd></div>}
      {permission && <div><dt className="tw-font-bold tw-text-kb-muted">{c.permissionLabel}</dt><dd className="tw-mt-0.5 tw-text-kb-body">{permission}</dd></div>}
      {verifiedAt && <div><dt className="tw-font-bold tw-text-kb-muted">{c.verifiedOn}</dt><dd className="tw-mt-0.5 tw-text-kb-body"><time dateTime={verifiedAt}>{verifiedAt}</time></dd></div>}
    </dl>}
    {(website || detailLink) && <div className="tw-mt-auto tw-flex tw-flex-wrap tw-gap-x-4 tw-gap-y-2 tw-border-t tw-border-kb-line tw-pt-3">
      {website && <a className="tw-inline-flex tw-min-h-9 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" href={website} target="_blank" rel="noopener noreferrer">{c.website}<span className="tw-sr-only"> · {c.opensNewTab}</span><ArrowIcon kind="up" size={13} /></a>}
      {detailLink && <Link className="tw-inline-flex tw-min-h-9 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={detailLink}>{c.detail}<ArrowIcon size={13} /></Link>}
    </div>}
  </article>
}
