import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import CopyPageLink from './CopyPageLink.jsx'
import PrimaryLink from './PrimaryLink.jsx'
import ArrowIcon from './ArrowIcon.jsx'

const COPY = {
  fa: {
    roleEyebrow: 'رویکرد تجارتی',
    roleTitle: 'نقش خان‌بوستان در معامله',
    roleIntro: 'خان‌بوستان در تجارت عمومی، واردات و صادرات فعالیت می‌کند. درخواست هر کالا بر اساس مشخصات، مقدار و مقصد مطرح می‌شود.',
    roleCards: [
      ['تجارت عمومی', 'گفتگو دربارهٔ نیازهای تجارتی بر پایهٔ درخواست و مشخصات هر معامله.'],
      ['واردات', 'بررسی درخواست واردات با توجه به نوع کالا، مبدأ پیشنهادی و مقصد.'],
      ['صادرات', 'گفتگو دربارهٔ صادرات کالاهای افغانستانی بر اساس مشخصات و مقصد موردنظر.'],
    ],
    processLink: 'دیدن نمای کلی روند همکاری',
    marketEyebrow: 'شناخت درخواست',
    marketTitle: 'در بررسی کالا و بازار چه چیزهایی اهمیت دارد؟',
    marketIntro: 'برای روشن‌شدن درخواست، معلومات کالا، مشخصات، مقدار و مقصد را بیان کنید.',
    marketItems: [
      ['نیاز و مقصد', 'کالا برای کدام نیاز و مقصد موردنظر است؟'],
      ['مشخصات کالا', 'نام، نوع، درجه یا مشخصات فنی که برایتان مهم است.'],
      ['مقدار و بسته‌بندی', 'مقدار تقریبی و شکل بسته‌بندی، اگر از قبل معلوم باشد.'],
      ['مبدأ و اسناد', 'مبدأ پیشنهادی و هر سند یا شرطی که باید بررسی شود.'],
    ],
    clarityEyebrow: 'پیش از توافق',
    clarityTitle: 'موارد مهم برای روشن‌شدن شرایط معامله',
    clarityIntro: 'روشن‌ساختن این موارد میان طرف‌ها، شرایط معامله را مشخص و گفتگو را منظم می‌سازد.',
    clarityItems: [
      'نام، مشخصات و درجهٔ دقیق کالا',
      'مقدار، واحد سنجش و بسته‌بندی',
      'مبدأ پیشنهادی و مقصد نهایی',
      'قیمت پیشنهادی و شرایط حمل یا تحویل',
      'اسناد لازم و مسئولیت هر یک از طرف‌ها',
    ],
    audienceEyebrow: 'مخاطبان همکاری',
    audienceTitle: 'چه کسانی می‌توانند برای همکاری تماس بگیرند؟',
    audienceIntro: 'مسیر درخواست را با نقش و نیاز خود هماهنگ کنید تا گفتگو هدفمندتر آغاز شود.',
    audiences: [
      ['خریداران و شرکت‌های متقاضی کالا', 'اگر کالا، مقدار یا مقصد مشخصی در نظر دارید، درخواست محصول بفرستید.', 'فرستادن استعلام کالا', '/contact?kind=product'],
      ['تأمین‌کنندگان و تولیدکنندگان', 'اگر کالا یا زمینه‌ای برای پیشنهاد عرضه دارید، معلومات و پیشنهاد خود را بفرستید.', 'پیشنهاد همکاری', '/contact?kind=cooperation'],
      ['فعالان و شرکت‌های تجارتی', 'برای گفتگو دربارهٔ زمینهٔ همکاری، نوع فعالیت و پیشنهاد خود را معرفی کنید.', 'گفتگو دربارهٔ همکاری', '/contact?kind=cooperation'],
    ],
    startEyebrow: 'آغاز گفتگو',
    startTitle: 'برای فرستادن درخواست چه معلوماتی آماده کنید؟',
    startIntro: 'هر قدر معلومات روشن‌تر باشد، گفتگو هدفمندتر آغاز می‌شود. فقط مواردی را بنویسید که می‌دانید؛ برای معلومات نامعلوم حدس نزنید.',
    required: 'ضروری', optional: 'اختیاری، اگر معلوم است',
    requestItems: [
      ['نام کالا', true],
      ['مقدار و واحد موردنیاز', true],
      ['کشور یا شهر مقصد', true],
      ['مبدأ پیشنهادی', false],
      ['مشخصات، درجه یا بسته‌بندی', false],
    ],
    sendRequest: 'فرستادن استعلام کالا',
    tradeGuide: 'دیدن راهنمای آمادگی تجارتی',
  },
  en: {
    roleEyebrow: 'Trade approach',
    roleTitle: 'Khan Boostan’s role in a trade enquiry',
    roleIntro: 'Khan Boostan operates in general trade, import and export. Enquiries are framed around the goods, specifications, quantity and destination.',
    roleCards: [
      ['General trade', 'Trade discussions shaped by the request and specifications of each transaction.'],
      ['Import', 'Considering an import enquiry in light of the goods, proposed origin and destination.'],
      ['Export', 'Discussing Afghan goods for export based on the requested specifications and destination.'],
    ],
    processLink: 'View the cooperation process overview',
    marketEyebrow: 'Understanding an enquiry',
    marketTitle: 'What matters when discussing goods and markets?',
    marketIntro: 'To make an enquiry clear, share the goods, specifications, quantity and destination.',
    marketItems: [
      ['Need and destination', 'What need and destination is the request intended for?'],
      ['Product specifications', 'The product name, type, grade or technical details that matter to you.'],
      ['Quantity and packaging', 'The approximate quantity and packaging, if known.'],
      ['Origin and documents', 'A proposed origin and any documents or conditions to consider.'],
    ],
    clarityEyebrow: 'Before agreement',
    clarityTitle: 'Details to clarify before a trade agreement',
    clarityIntro: 'Clarifying these points between the parties helps define the transaction terms and keep the discussion organized.',
    clarityItems: [
      'Exact product name, specifications and grade',
      'Quantity, unit of measure and packaging',
      'Proposed origin and final destination',
      'Quoted price and transport or delivery terms',
      'Required documents and each party’s responsibilities',
    ],
    audienceEyebrow: 'Who we hear from',
    audienceTitle: 'Who can contact us about cooperation?',
    audienceIntro: 'Choose a contact route that fits your role and requirements to make the conversation more focused.',
    audiences: [
      ['Buyers and businesses seeking goods', 'If you have a product, quantity or destination in mind, send a product enquiry.', 'Send a product enquiry', '/contact?kind=product'],
      ['Suppliers and producers', 'If you have goods or a supply opportunity to propose, share the details and your proposal.', 'Propose cooperation', '/contact?kind=cooperation'],
      ['Trade businesses and professionals', 'For a cooperation discussion, introduce your field of activity and proposal.', 'Discuss cooperation', '/contact?kind=cooperation'],
    ],
    startEyebrow: 'Start a conversation',
    startTitle: 'What information should you prepare?',
    startIntro: 'Clear information helps make the first discussion more focused. Share only what you know; do not guess at unknown details.',
    required: 'Required', optional: 'Optional, if known',
    requestItems: [
      ['Product or goods', true],
      ['Required quantity and unit', true],
      ['Destination country or city', true],
      ['Preferred origin', false],
      ['Specifications, grade or packaging', false],
    ],
    sendRequest: 'Send a product enquiry',
    tradeGuide: 'View the trade readiness guide',
  },
}

function SectionHeading({ id, lang, eyebrow, title }) {
  return <div className="tw-mb-5">
    <Eyebrow>{eyebrow}</Eyebrow>
    <div className="tw-mt-2 tw-flex tw-items-start tw-gap-3">
      <h2 id={`${id}-title`} className="tw-max-w-3xl tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{title}</h2>
      <CopyPageLink id={id} lang={lang} sectionLabel={title} />
    </div>
  </div>
}

function ChecklistIcon() {
  return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="m8 6 2 2 4-4" /><path d="M15 6h5M8 13l2 2 4-4" /><path d="M15 13h5M8 20l2 2 4-4" /><path d="M15 20h5" /></svg>
}

export default function AboutTradeSections({ lang }) {
  const fa = lang !== 'en'
  const c = COPY[fa ? 'fa' : 'en']

  return <>
    <section id="about-trade-role" className="tw-scroll-mt-24 tw-bg-white tw-py-10 sm:tw-py-14" aria-labelledby="about-trade-role-title"><SiteContainer>
      <SectionHeading id="about-trade-role" lang={lang} eyebrow={c.roleEyebrow} title={c.roleTitle} />
      <p className="tw-max-w-4xl tw-text-sm tw-leading-7 tw-text-kb-body">{c.roleIntro}</p>
      <div className="tw-mt-5 tw-grid tw-gap-3 sm:tw-grid-cols-2 lg:tw-grid-cols-3">{c.roleCards.map(([title, text]) => <article key={title} className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4 sm:tw-p-5"><h3 className="tw-text-sm tw-font-bold tw-text-kb-navy">{title}</h3><p className="tw-mt-2 tw-text-xs tw-leading-6 tw-text-kb-body">{text}</p></article>)}</div>
      <Link to="/process" className="tw-mt-5 tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{c.processLink}<ArrowIcon className="rtl:tw-rotate-180" /></Link>
    </SiteContainer></section>

    <section id="about-market-criteria" className="tw-scroll-mt-24 tw-bg-kb-paper tw-py-10 sm:tw-py-14" aria-labelledby="about-market-criteria-title"><SiteContainer>
      <SectionHeading id="about-market-criteria" lang={lang} eyebrow={c.marketEyebrow} title={c.marketTitle} />
      <p className="tw-max-w-4xl tw-text-sm tw-leading-7 tw-text-kb-body">{c.marketIntro}</p>
      <div className="tw-mt-5 tw-grid tw-gap-3 sm:tw-grid-cols-2 lg:tw-grid-cols-4">{c.marketItems.map(([title, text], index) => <article key={title} className="tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4"><span className="tw-inline-flex tw-h-8 tw-w-8 tw-items-center tw-justify-center tw-rounded-full tw-bg-kb-blue tw-text-xs tw-font-bold tw-text-white" aria-hidden="true">{String(index + 1).padStart(2, '0')}</span><h3 className="tw-mt-3 tw-text-sm tw-font-bold tw-text-kb-navy">{title}</h3><p className="tw-mt-2 tw-text-xs tw-leading-6 tw-text-kb-body">{text}</p></article>)}</div>
    </SiteContainer></section>

    <section id="about-trade-clarity" className="tw-scroll-mt-24 tw-bg-white tw-py-10 sm:tw-py-14" aria-labelledby="about-trade-clarity-title"><SiteContainer>
      <SectionHeading id="about-trade-clarity" lang={lang} eyebrow={c.clarityEyebrow} title={c.clarityTitle} />
      <p className="tw-max-w-4xl tw-text-sm tw-leading-7 tw-text-kb-body">{c.clarityIntro}</p>
      <ul className="tw-mt-5 tw-grid tw-gap-2 sm:tw-grid-cols-2">{c.clarityItems.map((item) => <li key={item} className="tw-flex tw-items-start tw-gap-3 tw-rounded-kb tw-border tw-border-kb-line tw-bg-kb-paper tw-p-3"><span className="tw-mt-0.5 tw-text-kb-blue"><ChecklistIcon /></span><span className="tw-text-sm tw-leading-6 tw-text-kb-body">{item}</span></li>)}</ul>
    </SiteContainer></section>

    <section id="about-collaborators" className="tw-scroll-mt-24 tw-bg-kb-paper tw-py-10 sm:tw-py-14" aria-labelledby="about-collaborators-title"><SiteContainer>
      <SectionHeading id="about-collaborators" lang={lang} eyebrow={c.audienceEyebrow} title={c.audienceTitle} />
      <p className="tw-max-w-4xl tw-text-sm tw-leading-7 tw-text-kb-body">{c.audienceIntro}</p>
      <div className="tw-mt-5 tw-grid tw-gap-3 lg:tw-grid-cols-3">{c.audiences.map(([title, text, action, href]) => <article key={title} className="tw-flex tw-min-h-full tw-flex-col tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4 sm:tw-p-5"><h3 className="tw-text-sm tw-font-bold tw-leading-6 tw-text-kb-navy">{title}</h3><p className="tw-mt-2 tw-flex-1 tw-text-xs tw-leading-6 tw-text-kb-body">{text}</p><PrimaryLink to={href} variant="blue" className="tw-mt-4 tw-w-full sm:tw-w-auto">{action}<ArrowIcon className="rtl:tw-rotate-180" /></PrimaryLink></article>)}</div>
    </SiteContainer></section>

    <section id="about-start-enquiry" className="tw-scroll-mt-24 tw-bg-white tw-py-10 sm:tw-py-14" aria-labelledby="about-start-enquiry-title"><SiteContainer>
      <SectionHeading id="about-start-enquiry" lang={lang} eyebrow={c.startEyebrow} title={c.startTitle} />
      <p className="tw-max-w-4xl tw-text-sm tw-leading-7 tw-text-kb-body">{c.startIntro}</p>
      <div className="tw-mt-5 tw-grid tw-gap-2 sm:tw-grid-cols-2 lg:tw-grid-cols-3">{c.requestItems.map(([label, required]) => <div key={label} className="tw-flex tw-items-center tw-gap-3 tw-rounded-kb tw-border tw-border-kb-line tw-bg-kb-paper tw-p-3"><span className="tw-text-kb-blue"><ChecklistIcon /></span><span className="tw-flex-1 tw-text-sm tw-font-bold tw-text-kb-navy">{label}</span><span className="tw-shrink-0 tw-text-[10px] tw-font-bold tw-text-kb-muted">{required ? c.required : c.optional}</span></div>)}</div>
      <div className="tw-mt-5 tw-flex tw-flex-wrap tw-items-center tw-gap-x-5 tw-gap-y-3"><PrimaryLink to="/contact?kind=product" variant="gold">{c.sendRequest}<ArrowIcon className="rtl:tw-rotate-180" /></PrimaryLink><Link to="/sourcing" className="tw-inline-flex tw-min-h-10 tw-items-center tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{c.tradeGuide}</Link></div>
    </SiteContainer></section>
  </>
}
