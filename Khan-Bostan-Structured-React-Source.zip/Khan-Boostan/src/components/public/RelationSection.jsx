import SiteContainer from './SiteContainer.jsx'
import RelationshipCard from './RelationshipCard.jsx'

export default function RelationSection({ section, L, lang, c }) {
  const count = section.items.length
  const compact = count <= 2
  const gridLayout = count === 1
    ? 'tw-mx-auto tw-w-full tw-max-w-xl'
    : count === 2
      ? 'tw-mx-auto tw-w-full tw-max-w-4xl sm:tw-grid-cols-2'
      : 'sm:tw-grid-cols-2 lg:tw-grid-cols-3'
  const centeredRemainderIndex = count > 2
    ? count % 3 === 1 ? count - 1 : count % 3 === 2 ? count - 2 : -1
    : -1

  return <section id={section.id} className={`tw-scroll-mt-24 tw-bg-white ${compact ? 'tw-py-6 sm:tw-py-8' : 'tw-py-10 sm:tw-py-12'}`} aria-labelledby={`${section.id}-title`}><SiteContainer>
    <div className="tw-mb-5"><h2 id={`${section.id}-title`} className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{section.title}</h2></div>
    <div className={`tw-grid tw-gap-3 ${gridLayout}`}>
      {section.items.map((entry, index) => <RelationshipCard key={entry.id ?? index} entry={entry} kind={section.kind} L={L} lang={lang} c={c} label={section.title} className={index === centeredRemainderIndex ? 'lg:tw-col-start-2' : ''} />)}
    </div>
  </SiteContainer></section>
}
