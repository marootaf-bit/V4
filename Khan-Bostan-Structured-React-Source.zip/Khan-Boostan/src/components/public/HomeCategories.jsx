import { Link } from 'react-router-dom'
import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import ArrowIcon from './ArrowIcon.jsx'
import HomeMedia from './HomeMedia.jsx'

const CATEGORY_IMAGES = {
  food: '/images/product-rice.webp',
  agri: '/images/product-dried-fruit.webp',
  construction: '/images/product-cement.webp',
  machinery: '/images/product-generator.webp',
  household: '/images/product-kitchenware.webp',
  textile: '/images/product-fabric.webp',
  energy: '/images/product-solar.webp',
  spare: '/images/product-spareparts.webp',
}
export default function HomeCategories({ categories, products, categoryName, L, fa, lang }) {
  const visibleCategories = categories.filter((item) => Boolean(L(item.name)))
  if (!visibleCategories.length) return null
  const count = (id) => products.filter((item) => item.category === id && Boolean(L(item.name))).length
  const formatCount = new Intl.NumberFormat(lang === 'fa' ? 'fa-AF' : 'en', { useGrouping: false })
  return <section id="home-products" className="tw-scroll-mt-20 tw-bg-white tw-py-10 sm:tw-py-14" aria-labelledby="home-categories-title"><SiteContainer>
    <div className="tw-mb-6 tw-flex tw-flex-col tw-gap-3 sm:tw-flex-row sm:tw-items-end sm:tw-justify-between">
      <div>
        <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-3"><Eyebrow>{fa ? 'محصولات' : 'PRODUCTS'}</Eyebrow></div>
        <h2 id="home-categories-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{fa ? 'حوزه‌ها و دسته‌بندی محصولات' : 'Trade areas & product categories'}</h2>
        <p className="tw-mt-2 tw-max-w-2xl tw-text-sm tw-leading-6 tw-text-kb-body">{fa ? 'دسته‌بندی‌ها را مرور کنید و برای جزئیات هر کالا، کاتالوگ را ببینید.' : 'Explore product categories and open the catalogue for product details.'}</p>
      </div>
      <Link to="/products" className="tw-inline-flex tw-min-h-10 tw-shrink-0 tw-items-center tw-gap-2 tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{fa ? 'همهٔ دسته‌ها' : 'All categories'}<ArrowIcon /></Link>
    </div>

    {visibleCategories.length > 0 && <div className="tw-grid tw-items-stretch tw-gap-3 sm:tw-grid-cols-2 lg:tw-grid-cols-4">{visibleCategories.map((item, index) => <Link to={`/products?c=${item.id}`} className="tw-group tw-flex tw-h-full tw-flex-col tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-transition-colors hover:tw-border-kb-blue/40 hover:tw-bg-white motion-reduce:tw-transition-none focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" key={item.id}>
      <HomeMedia className="tw-aspect-[16/9] tw-w-full tw-object-cover tw-transition-transform group-hover:tw-scale-[1.03] motion-reduce:tw-transition-none motion-reduce:group-hover:tw-scale-100" src={CATEGORY_IMAGES[item.id] || '/images/trade-warehouse.webp'} alt="" loading={index < 4 ? 'eager' : 'lazy'} />
      <span className="tw-flex tw-min-h-[72px] tw-flex-1 tw-items-center tw-justify-between tw-gap-2 tw-p-4"><b className="tw-min-w-0 tw-text-sm tw-leading-6 tw-text-kb-navy">{L(item.name)}</b><span className="tw-flex tw-shrink-0 tw-flex-col tw-items-end tw-text-[10px] tw-font-bold tw-leading-4 tw-text-kb-blue"><span>{formatCount.format(count(item.id))} {fa ? 'مورد' : 'entries'}</span></span></span>
    </Link>)}</div>}

  </SiteContainer></section>
}
