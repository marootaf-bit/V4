import SiteContainer from './SiteContainer.jsx'
import Eyebrow from './Eyebrow.jsx'
import CopyPageLink from './CopyPageLink.jsx'

export default function AboutApproach({ approach, fa, title }) {
  if (!approach) return null
  return <section id="about-approach" className="tw-scroll-mt-24 tw-bg-kb-paper tw-py-7 sm:tw-py-9 print:tw-bg-white" aria-labelledby="about-approach-title"><SiteContainer className="tw-max-w-4xl">
    <Eyebrow>{fa ? 'رویکرد' : 'APPROACH'}</Eyebrow>
    <div className="tw-mt-2 tw-flex tw-items-center tw-gap-2"><h2 id="about-approach-title" className="tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy sm:tw-text-3xl">{title}</h2><CopyPageLink id="about-approach" lang={fa ? 'fa' : 'en'} sectionLabel={title} /></div>
    <p className="tw-mt-3 tw-max-w-[70ch] tw-whitespace-pre-line tw-text-sm tw-leading-7 tw-text-kb-body">{approach}</p>
  </SiteContainer></section>
}
