export default function ArrowIcon({ className = '', kind = 'arrow', size = 16 }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true }
  if (kind === 'up') return <svg className={className} {...common}><path d="M7 17 17 7M8 7h9v9" /></svg>
  if (kind === 'search') return <svg className={className} {...common}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></svg>
  return <svg className={`kb-direction-arrow ${className}`} {...common}><path d="M4 12h15" /><path d="m12 5 7 7-7 7" /></svg>
}
