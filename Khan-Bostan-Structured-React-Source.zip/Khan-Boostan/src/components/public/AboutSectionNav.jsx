import { useEffect, useState } from 'react'
import SiteContainer from './SiteContainer.jsx'

export default function AboutSectionNav({ items, fa }) {
  const [activeHref, setActiveHref] = useState(items[0]?.href ?? '')
  const sectionKey = items.map((item) => item.href).join('|')

  useEffect(() => {
    if (!('IntersectionObserver' in window)) return undefined
    const targets = items.map((item) => document.querySelector(item.href)).filter(Boolean)
    if (!targets.length) return undefined
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)
      if (visible[0]) setActiveHref(`#${visible[0].target.id}`)
    }, { rootMargin: '-12% 0px -50% 0px', threshold: 0 })
    targets.forEach((target) => observer.observe(target))
    return () => observer.disconnect()
  }, [sectionKey])

  useEffect(() => {
    const root = document.documentElement
    const originalBehavior = root.style.scrollBehavior
    const preference = window.matchMedia('(prefers-reduced-motion: reduce)')
    const syncPreference = () => { root.style.scrollBehavior = preference.matches ? 'auto' : originalBehavior }
    syncPreference()
    preference.addEventListener?.('change', syncPreference)
    return () => {
      preference.removeEventListener?.('change', syncPreference)
      root.style.scrollBehavior = originalBehavior
    }
  }, [])

  if (!items.length) return null
  return <section className="tw-sticky tw-top-0 tw-z-30 tw-border-y tw-border-kb-line tw-bg-white/95 tw-py-2 tw-backdrop-blur-sm print:tw-hidden" aria-label={fa ? 'فهرست بخش‌های دربارهٔ ما' : 'About page sections'}>
    <SiteContainer className="tw-flex tw-items-center tw-gap-2 sm:tw-gap-3">
      <span className="tw-flex tw-shrink-0 tw-flex-col tw-text-[11px] tw-font-bold tw-text-kb-muted"><span>{fa ? 'پرش به:' : 'Jump to:'}</span><small className="tw-text-[9px] tw-font-normal tw-text-kb-muted sm:tw-hidden">{fa ? 'افقی بکشید' : 'Swipe'}</small></span>
      <nav className="tw-min-w-0 tw-flex-1 tw-overflow-x-auto tw-overscroll-x-contain tw-py-1 focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue lg:tw-overflow-visible" tabIndex={0} aria-label={fa ? 'پیوندهای درون صفحهٔ دربارهٔ ما' : 'About page index'}>
        <ul className="tw-flex tw-w-max tw-gap-2 lg:tw-grid lg:tw-w-full lg:tw-grid-cols-6">
          {items.map((item) => {
            const active = item.href === activeHref
            return <li key={item.href}><a href={item.href} aria-current={active ? 'location' : undefined} className={`tw-inline-flex tw-min-h-9 tw-items-center tw-whitespace-nowrap tw-rounded-full tw-border tw-px-3 tw-text-center tw-text-xs tw-font-bold tw-transition-colors motion-reduce:tw-transition-none focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue lg:tw-w-full lg:tw-justify-center lg:tw-whitespace-normal ${active ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-line tw-bg-kb-paper tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`}>{item.label}</a></li>
          })}
        </ul>
      </nav>
    </SiteContainer>
  </section>
}
