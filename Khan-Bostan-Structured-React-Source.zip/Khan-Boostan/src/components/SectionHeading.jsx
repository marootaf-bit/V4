import Eyebrow from './public/Eyebrow.jsx'

export default function SectionHeading({ eyebrow, title, description, light = false }) {
  return <div className="tw-mb-8 tw-flex tw-flex-wrap tw-items-end tw-justify-between tw-gap-4 md:tw-mb-10"><div className="tw-max-w-[62ch]">{eyebrow && <Eyebrow className={light ? 'tw-text-kb-gold' : ''}>{eyebrow}</Eyebrow>}<h2 className={`tw-mt-2 tw-font-head tw-text-3xl tw-font-bold tw-leading-tight sm:tw-text-4xl ${light ? 'tw-text-white' : 'tw-text-kb-navy'}`}>{title}</h2>{description && <p className={`tw-mt-2 tw-text-sm tw-leading-7 ${light ? 'tw-text-white/75' : 'tw-text-kb-body'}`}>{description}</p>}</div></div>
}
