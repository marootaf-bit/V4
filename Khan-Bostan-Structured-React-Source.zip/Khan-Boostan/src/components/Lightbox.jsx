import { useEffect, useRef } from 'react'
import { usePublicDict } from '../lib.jsx'
import ArrowIcon from './public/ArrowIcon.jsx'

// Shared gallery/product viewer: keep keyboard and screen-reader focus inside the dialog.
export default function Lightbox({ items, index, setIndex, close }) {
  const { t, L, lang } = usePublicDict()
  const dialogRef = useRef(null)
  const closeRef = useRef(null)

  useEffect(() => {
    const trigger = document.activeElement
    const background = [...document.querySelectorAll('.public-site > header, .public-site > main, .public-site > footer')]
    const priorInert = background.map((element) => element.inert)
    const previousOverflow = document.body.style.overflow
    background.forEach((element) => { element.inert = true })
    document.body.style.overflow = 'hidden'
    closeRef.current?.focus()
    return () => {
      background.forEach((element, i) => { element.inert = priorInert[i] })
      document.body.style.overflow = previousOverflow
      if (trigger?.isConnected) trigger.focus({ preventScroll: true })
    }
  }, [])

  useEffect(() => {
    const handle = (event) => {
      if (event.key === 'Escape') { event.preventDefault(); close(); return }
      if (event.key === 'Tab') {
        const dialog = dialogRef.current
        if (!dialog) return
        const focusable = [...dialog.querySelectorAll('button:not([disabled]), a[href], video[controls], [tabindex]:not([tabindex="-1"])')].filter((element) => element.getClientRects().length > 0)
        if (!focusable.length) { event.preventDefault(); return }
        const first = focusable[0], last = focusable[focusable.length - 1]
        if (!dialog.contains(document.activeElement)) { event.preventDefault(); first.focus() }
        else if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus() }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus() }
        return
      }
      // Native video controls retain their arrow-key seeking behavior.
      if (event.target instanceof HTMLVideoElement) return
      if (event.key === 'ArrowLeft') {
        event.preventDefault()
        const delta = lang === 'fa' ? 1 : -1
        setIndex((i) => (i + delta + items.length) % items.length)
      }
      if (event.key === 'ArrowRight') {
        event.preventDefault()
        const delta = lang === 'fa' ? -1 : 1
        setIndex((i) => (i + delta + items.length) % items.length)
      }
    }
    document.addEventListener('keydown', handle)
    return () => document.removeEventListener('keydown', handle)
  }, [items.length, setIndex, close, lang])

  const item = items[index]
  if (!item) return null
  const caption = L(item.caption, '')
  const mediaDescription = caption || L(item.alt, '') || (lang === 'fa' ? 'تصویر' : 'Image')
  const announcement = lang === 'fa'
    ? `${item.video ? 'ویدیو' : 'تصویر'} ${index + 1} از ${items.length}: ${mediaDescription}`
    : `${item.video ? 'Video' : 'Image'} ${index + 1} of ${items.length}: ${mediaDescription}`
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
  return <div ref={dialogRef} tabIndex="-1" className="tw-fixed tw-inset-0 tw-z-[100] tw-grid tw-place-items-center tw-bg-kb-navy tw-p-4" role="dialog" aria-modal="true" aria-label={lang === 'fa' ? 'نمایش تصویر یا ویدیو' : 'Media viewer'} onClick={close}>
    <button ref={closeRef} type="button" className="tw-absolute tw-end-4 tw-top-4 tw-grid tw-h-11 tw-w-11 tw-place-items-center tw-rounded-full tw-border tw-border-white/20 tw-text-white hover:tw-border-kb-gold hover:tw-text-kb-gold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold" onClick={(event) => { event.stopPropagation(); close() }} aria-label={t('close')}><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12" /></svg></button>
    {items.length > 1 && <>
      <button type="button" className="tw-absolute tw-start-3 tw-top-1/2 tw-grid tw-h-11 tw-w-11 -tw-translate-y-1/2 tw-place-items-center tw-rounded-full tw-border tw-border-white/20 tw-text-white hover:tw-border-kb-gold hover:tw-text-kb-gold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold md:tw-start-6" aria-label={t('prev')} onClick={(event) => { event.stopPropagation(); setIndex((i) => (i - 1 + items.length) % items.length) }}><ArrowIcon className="tw-rotate-180 rtl:tw-rotate-0" /></button>
      <button type="button" className="tw-absolute tw-end-3 tw-top-1/2 tw-grid tw-h-11 tw-w-11 -tw-translate-y-1/2 tw-place-items-center tw-rounded-full tw-border tw-border-white/20 tw-text-white hover:tw-border-kb-gold hover:tw-text-kb-gold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold md:tw-end-6" aria-label={t('next')} onClick={(event) => { event.stopPropagation(); setIndex((i) => (i + 1) % items.length) }}><ArrowIcon className="rtl:tw-rotate-180" /></button>
    </>}
    <figure className="tw-max-h-full tw-w-full tw-max-w-4xl" onClick={(event) => event.stopPropagation()}>
      <span className="tw-sr-only" aria-live="polite" aria-atomic="true">{announcement}</span>
      {item.video ? <video src={item.video} poster={item.poster || item.image} controls autoPlay={!reducedMotion} playsInline aria-label={mediaDescription} className="tw-max-h-[76vh] tw-w-full tw-rounded-kb-lg tw-bg-black" /> : <img src={item.image} alt={mediaDescription} className="tw-mx-auto tw-max-h-[76vh] tw-w-auto tw-rounded-kb-lg tw-object-contain" />}
      {caption && <figcaption className="tw-mt-3 tw-text-center tw-text-sm tw-text-white/80">{caption}</figcaption>}
    </figure>
  </div>
}
