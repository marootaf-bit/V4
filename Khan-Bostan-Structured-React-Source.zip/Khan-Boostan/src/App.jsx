import { lazy, Suspense } from 'react'
import { Routes, Route } from 'react-router-dom'
import SiteShell from './SiteShell.jsx'
import ScrollToTop from './components/public/ScrollToTop.jsx'
import './public-tailwind.generated.css'
import './redesign.css'

const PreviewAdmin = lazy(() => import('./pages/PreviewAdmin.jsx'))

export default function App() {
  return <>
    <ScrollToTop />
    <Suspense fallback={null}>
      <Routes>
        <Route path="/admin/*" element={<PreviewAdmin />} />
        <Route path="/*" element={<SiteShell />} />
      </Routes>
    </Suspense>
  </>
}
