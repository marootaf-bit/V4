import { Link } from 'react-router-dom'
import { usePublicDict } from '../lib.jsx'
import pages from '../content/business.json'
import Hero from '../components/public/Hero.jsx'
import PrimaryLink from '../components/public/PrimaryLink.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'
import ContactActions from '../components/public/ContactActions.jsx'

export default function BusinessPage({page}){
 const {lang,L}=usePublicDict(),fa=lang==='fa',content=pages[page]
 const parent=page==='markets'?['/about',fa?'دربارهٔ شرکت':'About']:page==='process'?['/logistics',fa?'خدمات لوجستیکی':'Logistics']:['/activities',fa?'خدمات تجارتی':'Trade services']
 const isTop=['activities','logistics'].includes(page)
 return <main id="main" className="tw-flex-1"><Hero title={L(content.title)} sub={L(content.intro)} image={content.image} crumbs={[...(!isTop?[parent]:[]),[null,L(content.title)]]}/>
  <section className="kb-section"><div className="kb-wrap kb-business-grid">{content.cards.map(card=><article className="kb-business-card" key={card.title.en}><h2>{L(card.title)}</h2><p>{L(card.body)}</p>{card.to&&<Link className="kb-text-link" to={card.to}>{fa?'بررسی این بخش':'Explore this section'}<ArrowIcon/></Link>}</article>)}</div></section>
  {page==='activities'&&<div className="kb-wrap kb-actions tw-mb-10"><PrimaryLink to="/export">{fa?'صادرات از افغانستان':'Export from Afghanistan'}</PrimaryLink><PrimaryLink to="/logistics">{fa?'کالا را خریده‌اید؟ خدمات لوجستیکی':'Already purchased? Logistics services'}</PrimaryLink></div>}
  <section className="kb-business-detail"><div className="kb-wrap"><div><h2>{fa?'مراحل پیشنهادی همکاری':'The cooperation process'}</h2><ol>{content.steps.map(step=><li key={step.en}>{L(step)}</li>)}</ol></div><div><h2>{fa?'برای شروع چه معلوماتی بفرستید؟':'What to share with your enquiry'}</h2><ul className="kb-value-list">{content.details.map(item=><li key={item.en}><span aria-hidden="true">✓</span>{L(item)}</li>)}</ul><p>{fa?'اگر بخشی از معلومات را ندارید، همان ابتدا مطرح کنید تا نیاز به بررسی مشخص شود.':'If some details are not yet available, mention this so the next review can be identified.'}</p></div></div></section>
  <section className="kb-section kb-business-faq"><div className="kb-wrap"><h2>{fa?'پرسش‌های این خدمت':'Questions about this service'}</h2>{content.faq.map(item=><details key={item.q.en}><summary>{L(item.q)}</summary><p>{L(item.a)}</p></details>)}{page==='activities'&&<details><summary>{fa?'آیا برای مشاوره هم می‌توان مراجعه کرد؟':'Can I ask for advice separately?'}</summary><p>{fa?'بله؛ مشاوره می‌تواند جداگانه یا بخشی از بررسی سفارش باشد. موضوع و بازار موردنظر را برای تعیین امکان گفتگو مطرح کنید.':'Yes. Advice can be a separate enquiry or part of reviewing an order. Share the topic and market to discuss how we can help.'}</p><Link to="/contact?kind=consultation" className="kb-text-link">{fa?'درخواست مشاوره':'Request advice'}</Link></details>}</div></section>
  <div className="kb-wrap kb-business-cta"><h2>{fa?'نیاز خود را با ما در میان بگذارید.':'Tell us what you need.'}</h2><p>{fa?'واتساپ و ایمیل، راه‌های اصلی شروع گفتگو هستند.':'WhatsApp and email are the primary ways to start a conversation.'}</p><ContactActions kind={content.kind} subject={L(content.title)}/></div>
 </main>
}
