import { displayDate } from '../lib/date.js'
import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict, publicNews, publicSlug } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import NotFoundCompact from './NotFoundCompact.jsx'
import NewsCard, { newsCat } from '../components/NewsCard.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import SectionHeading from '../components/SectionHeading.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'

export default function NewsDetail() {
  const { slug } = useParams()
  const { data } = useContent()
  const { t, L, lang } = usePublicDict()
  const [copied, setCopied] = useState(false)
  const [shareStatus, setShareStatus] = useState('')
  if (!data) return <PublicLoading />
  const publicItems = publicNews(data.news ?? []).filter((item) => Boolean(L(item.title)))
  const newsItem = publicItems.find((item) => item.id === slug || publicSlug(item.id) === slug)
  if (!newsItem) return <NotFoundCompact />
  const categoryLabel = newsCat(newsItem.category, lang)
  const body = L(newsItem.body)
  const related = publicItems.filter((item) => item.id !== newsItem.id).sort((a, b) => Number(b.category === newsItem.category) - Number(a.category === newsItem.category) || (b.date ?? '').localeCompare(a.date ?? '')).slice(0, 3)
  const share = async () => {
    const url = window.location.href
    setShareStatus('')
    setCopied(false)
    if (navigator.share) {
      try {
        await navigator.share({ title: L(newsItem.title), url })
        setShareStatus(lang === 'fa' ? 'پیوند شریک شد.' : 'Link shared.')
        return
      } catch (error) {
        if (error?.name === 'AbortError') return
      }
    }
    try {
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard is unavailable')
      await navigator.clipboard.writeText(url)
      setCopied(true)
      setShareStatus(lang === 'fa' ? 'پیوند کپی شد.' : 'Link copied.')
      setTimeout(() => setCopied(false), 2000)
    } catch {
      setShareStatus(lang === 'fa' ? 'شریک‌سازی در این مرورگر ممکن نیست؛ نشانی صفحه را از نوار آدرس کپی کنید.' : 'Sharing is unavailable in this browser. Copy the page address from the address bar.')
    }
  }

  return <main id="main" className="tw-flex-1"><Hero image={newsItem.image || '/images/trade-detail.webp'} crumbs={[["/news", t('news_t')], [null, L(newsItem.title)]]} title={L(newsItem.title)} sub={L(newsItem.excerpt)} compact />
    <article className="tw-bg-white tw-py-10 sm:tw-py-14"><SiteContainer className="tw-max-w-4xl">
      <div className="tw-mb-6 tw-flex tw-flex-wrap tw-items-center tw-gap-3 tw-text-xs tw-text-kb-muted">{newsItem.date && <time dateTime={newsItem.date}>{displayDate(newsItem.date, lang)}</time>}{categoryLabel && <span className="tw-rounded-full tw-bg-kb-paper tw-px-2.5 tw-py-1 tw-text-[10px] tw-font-bold tw-text-kb-body">{categoryLabel}</span>}<button type="button" onClick={share} className="tw-ms-auto tw-inline-flex tw-min-h-9 tw-items-center tw-gap-2 tw-rounded-full tw-border tw-border-kb-line tw-px-3 tw-text-xs tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{copied ? <><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" className="tw-text-kb-blue" aria-hidden="true"><path d="M20 6 9 17l-5-5" /></svg>{t('copied')}</> : <><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect width="14" height="14" x="8" y="8" rx="2" ry="2" /><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" /></svg>{t('share')}</>}</button>{shareStatus && <p role="status" aria-atomic="true" className="tw-w-full tw-text-xs tw-leading-5 tw-text-kb-muted">{shareStatus}</p>}</div>
      <img {...(newsItem.image ? { src: newsItem.image } : {})} alt={L(newsItem.title)} className="tw-mb-7 tw-aspect-[16/9] tw-w-full tw-rounded-kb-lg tw-object-cover" />
      {body && <div className="tw-mx-auto tw-max-w-[70ch] tw-whitespace-pre-line tw-break-words tw-text-[16px] tw-leading-[2] tw-text-kb-body">{body}</div>}
      {newsItem.source && <p className="tw-mt-6 tw-border-t tw-border-kb-line tw-pt-4 tw-text-xs tw-text-kb-muted">{t('source_l')}: {newsItem.source}</p>}
      <div className="tw-mt-8 tw-flex tw-flex-wrap tw-gap-3"><Link to="/news" className="tw-inline-flex tw-min-h-10 tw-items-center tw-rounded-kb tw-border tw-border-kb-line tw-px-4 tw-text-xs tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{t('back')}</Link><Link to="/contact?kind=cooperation" className="tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-rounded-kb tw-bg-kb-gold tw-px-4 tw-text-xs tw-font-bold tw-text-kb-navy hover:tw-bg-kb-navy hover:tw-text-white focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{t('cooperate')}<ArrowIcon /></Link></div>
      {related.length > 0 && <section className="tw-mt-14" aria-labelledby="related-news-title"><SectionHeading eyebrow={t('news_t')} title={t('related_news')} /><div className="tw-grid tw-gap-4 md:tw-grid-cols-3">{related.map((item) => <NewsCard n={item} key={item.id} />)}</div></section>}
    </SiteContainer></article>
  </main>
}
