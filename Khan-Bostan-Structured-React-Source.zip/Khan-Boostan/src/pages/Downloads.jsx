import { useContent, bySort } from '../../src/lib/store.jsx'
import { usePublicDict, publicRecords, publicDocumentDescription } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import DocumentIcon from '../components/public/DocumentIcon.jsx'
import ExternalLinkIcon from '../components/public/ExternalLinkIcon.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'

const KIND = { profile: ['پروفایل شرکت', 'Company profile'], catalog: ['کتالوگ', 'Catalogue'], brochure: ['بروشور', 'Brochure'], certificate: ['گواهی‌نامه', 'Certificate'], form: ['فورم', 'Form'], other: ['سند', 'Document'] }

const fileLinkProps = (file) => {
  try {
    const url = new URL(file, window.location.href)
    if (url.origin === window.location.origin) return { download: url.pathname.split('/').pop() || true }
    return { target: '_blank', rel: 'noopener noreferrer' }
  } catch { return {} }
}

export default function Downloads() {
  const { data } = useContent()
  const { t, L, lang } = usePublicDict()
  const fa = lang !== 'en'
  if (!data) return <PublicLoading />
  const docs = [...publicRecords(data.documents ?? [])].filter((doc) => Boolean(doc.file) && Boolean(L(doc.title))).sort(bySort)
  return <main id="main" className="tw-flex-1"><Hero image="/images/trade-documents.webp" crumbs={[[null, t('downloads_t')]]} title={t('downloads_t')} sub={t('downloads_d')} compact />
    <section className="tw-bg-kb-paper tw-py-10 sm:tw-py-14"><SiteContainer>
      {docs.length > 0 && <div className="tw-grid tw-gap-4 sm:tw-grid-cols-2 lg:tw-grid-cols-3">{docs.map((doc) => <article className="tw-flex tw-min-h-64 tw-flex-col tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5 sm:tw-p-6" key={doc.id}>
        <div className="tw-flex tw-flex-wrap tw-items-start tw-justify-between tw-gap-3"><span className="tw-flex tw-h-11 tw-w-11 tw-items-center tw-justify-center tw-rounded-kb tw-bg-kb-paper tw-text-kb-blue"><DocumentIcon /></span><span className="tw-rounded-full tw-bg-kb-paper tw-px-2.5 tw-py-1 tw-text-[10px] tw-font-bold tw-text-kb-body">{KIND[doc.kind] ? KIND[doc.kind][lang === 'fa' ? 0 : 1] : t('nav_downloads')}</span></div>
        <h3 className="tw-mt-4 tw-text-base tw-font-bold tw-leading-6 tw-text-kb-navy">{L(doc.title)}</h3><p className="tw-mt-2 tw-text-sm tw-leading-6 tw-text-kb-body">{publicDocumentDescription(doc, L, lang)}</p>
        <div className="tw-mt-3 tw-flex tw-flex-wrap tw-gap-x-4 tw-gap-y-1 tw-text-[11px] tw-text-kb-muted">{doc.lang && <span>{t('lang_l')}: {doc.lang === 'fa+en' ? (lang === 'fa' ? 'دری و انگلیسی' : 'Dari & English') : doc.lang === 'fa' ? (lang === 'fa' ? 'دری' : 'Dari') : (lang === 'fa' ? 'انگلیسی' : 'English')}</span>}{doc.size && <span>{t('size_l')}: {doc.size}</span>}{doc.updated && <span>{t('updated_l')}: {doc.updated}</span>}</div>
        <div className="tw-mt-auto tw-pt-5">{doc.file && <a href={doc.file} {...fileLinkProps(doc.file)} className="tw-inline-flex tw-min-h-10 tw-items-center tw-gap-2 tw-rounded-kb tw-bg-kb-blue tw-px-4 tw-text-xs tw-font-bold tw-text-white hover:tw-bg-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold">{t('download_l')}<ExternalLinkIcon /></a>}</div>
      </article>)}</div>}
    </SiteContainer></section>
  </main>
}
