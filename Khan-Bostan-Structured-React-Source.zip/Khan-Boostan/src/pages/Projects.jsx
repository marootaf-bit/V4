import { Link } from 'react-router-dom'
import { useState } from 'react'
import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict, publicItemName, publicRecords, publicSlug } from '../lib.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import Hero from '../components/public/Hero.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import Eyebrow from '../components/public/Eyebrow.jsx'
import EmptyState from '../components/public/EmptyState.jsx'
import CallToAction from '../components/public/CallToAction.jsx'

const STORY_FIELDS = {
  fa: [['نیاز مشتری', 'need'], ['نقش و اقدامات خان بوستان', 'action'], ['نتیجه', 'result']],
  en: [['Client need', 'need'], ['Our role & actions', 'action'], ['Result', 'result']],
}
const PROJECT_PARTNER_IDS = ['demo-partner-1', 'demo-supplier-1', 'demo-supplier-2', 'demo-client-1', 'demo-client-2', 'demo-affiliate-1']

export default function Projects() {
  const { data } = useContent()
  const { t, L, lang } = usePublicDict()
  const fa = lang !== 'en'
  const [sector, setSector] = useState('all')
  const [year, setYear] = useState('all')
  if (!data) return <PublicLoading />

  const projects = publicRecords(data.projects ?? []).filter((item) => Boolean(L(item.title)))
  const sectorKey = (value) => typeof value === 'string' ? value : (value?.en ?? value?.fa ?? '')
  const sectors = [...new Map(projects.map((item) => [sectorKey(item.sector), L(item.sector)])).entries()].filter(([key, label]) => key && label).map(([key, label]) => ({ key, label }))
  const years = [...new Set(projects.map((item) => String(item.year ?? '')).filter(Boolean))]
  const filtered = projects.filter((item) => (sector === 'all' || sectorKey(item.sector) === sector) && (year === 'all' || String(item.year) === year))
  const testimonials = publicRecords(data.testimonials ?? []).filter((item) => Boolean(L(item.quote))).slice(0, 3)
  const partners = PROJECT_PARTNER_IDS.map((id) => publicRecords(data.partners ?? []).find((item) => item.id === id && Boolean(L(item.name)))).filter(Boolean)

  return <main id="main" className="tw-flex-1">
    <Hero image="/images/project-construction.webp" crumbs={[[null, fa ? 'پرونده‌های همکاری' : 'Trade cases']]} title={fa ? 'پرونده‌های همکاری' : 'Trade cases'} sub={t('projects_d')} />
    <section className="tw-bg-kb-paper tw-py-5 sm:tw-py-7" aria-label={fa ? 'فیلتر پرونده‌های تجارتی' : 'Filter trade cases'}><SiteContainer className={`tw-grid tw-gap-4 ${years.length ? 'sm:tw-grid-cols-2' : ''}`}><label className="tw-flex tw-min-h-12 tw-flex-col tw-justify-center tw-gap-1 tw-rounded-kb-lg tw-border tw-border-kb-control tw-bg-white tw-px-4 tw-py-2"><span className="tw-text-[10px] tw-font-bold tw-text-kb-muted">{t('filter_sector')}</span><select className="tw-w-full tw-bg-transparent tw-text-sm tw-font-bold tw-text-kb-navy tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" value={sector} onChange={(event) => setSector(event.target.value)}><option value="all">{t('all')}</option>{sectors.map((item) => <option value={item.key} key={item.key}>{item.label}</option>)}</select></label>{years.length > 0 && <label className="tw-flex tw-min-h-12 tw-flex-col tw-justify-center tw-gap-1 tw-rounded-kb-lg tw-border tw-border-kb-control tw-bg-white tw-px-4 tw-py-2"><span className="tw-text-[10px] tw-font-bold tw-text-kb-muted">{t('filter_year')}</span><select className="tw-w-full tw-bg-transparent tw-text-sm tw-font-bold tw-text-kb-navy tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" value={year} onChange={(event) => setYear(event.target.value)}><option value="all">{t('all')}</option>{years.map((item) => <option value={item} key={item}>{item}</option>)}</select></label>}</SiteContainer></section>

    <section className="tw-bg-white tw-py-8 sm:tw-py-12" aria-label={fa ? 'پرونده‌های همکاری' : 'Trade cases'}><SiteContainer>
      {filtered.length > 0 ? <div className="tw-grid tw-gap-5 lg:tw-grid-cols-2">{filtered.map((item, index) => <article className={`tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white ${filtered.length % 2 === 1 && index === filtered.length - 1 ? 'lg:tw-col-span-2 lg:tw-mx-auto lg:tw-w-full lg:tw-max-w-3xl' : ''}`} id={`project-${publicSlug(item.id)}`} key={item.id}>
        <div className="tw-relative tw-aspect-[16/9] tw-overflow-hidden tw-bg-kb-navy"><img className="tw-h-full tw-w-full tw-object-cover" src={item.image || '/images/project-construction.webp'} alt="" loading="lazy" /><div className="tw-absolute tw-inset-x-0 tw-bottom-0 tw-bg-gradient-to-t tw-from-kb-navy/90 tw-to-transparent tw-p-4"><div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2 tw-text-[11px] tw-font-bold tw-text-white"><span>{L(item.sector)}</span>{item.year && <><span aria-hidden="true">·</span><span>{item.year}</span></>}{L(item.market) && <><span aria-hidden="true">·</span><span>{L(item.market)}</span></>}{item.featured && <span className="tw-rounded-full tw-bg-kb-gold tw-px-2.5 tw-py-1 tw-text-[10px] tw-text-kb-navy">{t('featured_badge')}</span>}</div></div></div>
        <div className="tw-border-t tw-border-kb-line"><div className="tw-p-4 sm:tw-p-5"><h2 className="tw-break-words tw-text-lg tw-font-bold tw-leading-7 tw-text-kb-navy"><Link to={`/projects/${publicSlug(item.id)}`}>{publicItemName(L(item.title))}</Link></h2><Link className="kb-text-link" to={`/projects/${publicSlug(item.id)}`}>{fa ? "مشاهدهٔ جزئیات همکاری" : "View case details"}</Link></div>
          <div className="tw-border-t tw-border-kb-line tw-p-4 sm:tw-p-5"><dl className="tw-grid tw-gap-3">{STORY_FIELDS[fa ? 'fa' : 'en'].filter(([, key]) => Boolean(L(item[key]))).map(([label, key]) => <div className="tw-border-s-2 tw-border-kb-gold tw-ps-3" key={key}><dt className="tw-text-[10px] tw-font-bold tw-tracking-[.08em] tw-text-kb-muted">{label}</dt><dd className="tw-mt-1 tw-whitespace-pre-line tw-break-words tw-text-sm tw-leading-6 tw-text-kb-body">{L(item[key])}</dd></div>)}</dl>{publicItemName(L(item.client)) && <p className="tw-mt-4 tw-break-words tw-border-t tw-border-kb-line tw-pt-3 tw-text-xs tw-leading-6 tw-text-kb-muted"><b className="tw-break-words tw-text-kb-navy">{fa ? 'از:' : 'From:'} {publicItemName(L(item.client))}</b></p>}</div>
        </div>
      </article>)}</div> : (sector !== 'all' || year !== 'all') && <EmptyState title={t('no_items')} copy={fa ? 'پرونده‌ای با این فیلتر پیدا نشد.' : 'No trade cases match these filters.'} />}
    </SiteContainer></section>

    {testimonials.length > 0 && <section className="tw-bg-kb-paper tw-py-10 sm:tw-py-14" aria-labelledby="projects-testimonials-title"><SiteContainer><div className="tw-mb-6"><Eyebrow>{fa ? 'دیدگاه‌ها' : 'TESTIMONIALS'}</Eyebrow><h2 id="projects-testimonials-title" className="tw-mt-2 tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{fa ? 'دیدگاه مشتریان' : 'Client feedback'}</h2></div><div className="tw-grid tw-gap-4 lg:tw-grid-cols-3">{testimonials.map((item) => <figure className="tw-flex tw-h-full tw-flex-col tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-5" key={item.id}>{item.demo ? <p className="tw-flex-1 tw-text-sm tw-leading-7 tw-text-kb-body">{L(item.quote)}</p> : <blockquote className="tw-flex-1 tw-text-sm tw-leading-7 tw-text-kb-body">“{L(item.quote)}”</blockquote>}<figcaption className="tw-mt-5 tw-border-t tw-border-kb-line tw-pt-3">{L(item.name) && <span className="tw-block tw-text-xs tw-font-bold tw-text-kb-navy">{L(item.name)}</span>}{(L(item.role) || L(item.company)) && <span className="tw-mt-1 tw-block tw-text-xs tw-text-kb-muted">{[L(item.role), L(item.company)].filter(Boolean).join(' — ')}</span>}</figcaption></figure>)}</div></SiteContainer></section>}

    {partners.length > 0 && <section className="tw-bg-white tw-py-9 sm:tw-py-12" aria-labelledby="projects-partners-title"><SiteContainer><div className="tw-mb-5 tw-flex tw-flex-wrap tw-items-center tw-justify-between tw-gap-3"><h2 id="projects-partners-title" className="tw-font-head tw-text-xl tw-font-bold tw-text-kb-navy">{t('partners_t')}</h2></div><div className="tw-grid tw-gap-3 sm:tw-grid-cols-2 lg:tw-grid-cols-3">{partners.map((item) => <div className="tw-flex tw-min-h-20 tw-items-center tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-4" key={item.id}><span className="tw-grid tw-h-10 tw-w-10 tw-shrink-0 tw-place-items-center tw-rounded-full tw-bg-white tw-font-head tw-text-sm tw-font-bold tw-text-kb-blue" aria-hidden="true">{String(L(item.name)).trim().slice(0, 1)}</span><span className="tw-text-sm tw-font-bold tw-leading-5 tw-text-kb-navy">{L(item.name)}</span></div>)}</div></SiteContainer></section>}

    <CallToAction />
  </main>
}
