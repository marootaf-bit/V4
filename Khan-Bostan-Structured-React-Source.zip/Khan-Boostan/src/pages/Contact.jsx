import { useLocation } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import ContactChannels from '../components/public/ContactChannels.jsx'
import ContactForm from '../components/public/ContactForm.jsx'
import FaqList from '../components/public/FaqList.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'

export default function Contact() {
  const { data, settings } = useContent()
  const { t, L, lang } = usePublicDict()
  const location = useLocation()
  const query = new URLSearchParams(location.search)
  const requested = query.get('kind')
  const kind = ['contact', 'product', 'cooperation', 'sourcing', 'logistics', 'consultation'].includes(requested) ? requested : 'contact'
  const subject = (query.get('subject') || '').slice(0, 160)
  const productName = (query.get('productName') || '').slice(0, 180)
  if (!data) return <PublicLoading />

  const contact = settings.contact ?? {}
  const whatsapp = String(contact.whatsapp ?? '').trim()
  const phone = String(contact.phone ?? '').trim()
  const maskedContact = (value) => /[xX*•]/.test(String(value ?? ''))
  const waUrl = whatsapp && !maskedContact(whatsapp) ? `https://wa.me/${whatsapp.replace(/[^0-9]/g, '')}` : ''
  const phoneUrl = phone && !maskedContact(phone) ? `tel:${phone}` : ''
  const contactIntro = lang === 'fa'
    ? 'برای استعلام محصول، تأمین سفارشی، خدمات لوجستیکی یا مشاوره، از واتساپ یا ایمیل شروع کنید. تلفن، مراجعه و فرم نیز در دسترس‌اند.'
    : 'Start by WhatsApp or email for product, sourcing, logistics or advice enquiries. Phone, office visits and the form are also available.'
  const address = L(contact.address)
  const hours = L(contact.hours)
  const ways = [
    ...(contact.email ? [{ kind: 'mail', label: t('email'), value: contact.email, href: `mailto:${contact.email}`, dir: 'ltr' }] : []),
    ...(phoneUrl ? [{ kind: 'phone', label: t('phone'), value: phone, href: phoneUrl, dir: 'ltr' }] : []),
    ...(waUrl ? [{ kind: 'whatsapp', label: t('whatsapp_l'), value: whatsapp, href: waUrl, external: true, dir: 'ltr' }] : []),
    ...(address ? [{ kind: 'pin', label: t('address'), value: address }] : []),
    ...(hours ? [{ kind: 'clock', label: t('hours'), value: hours }] : []),
  ]
  ways.sort((a,b) => ['whatsapp','mail','phone','pin','clock'].indexOf(a.kind) - ['whatsapp','mail','phone','pin','clock'].indexOf(b.kind))
  const faqs = (data.faq ?? []).filter((item) => item.topic === 'contact')

  return <main id="main" className="tw-flex-1"><Hero image="/images/about-office.webp" crumbs={[[null, t('nav_contact')]]} title={t('contact_title')} compact />
    <ContactChannels items={ways} lang={lang} t={t} intro={contactIntro} />
    <section className="tw-bg-white tw-py-10 sm:tw-py-14" aria-label={lang === 'fa' ? 'فرم تماس' : 'Contact form'}><SiteContainer className="tw-max-w-4xl"><ContactForm key={location.search} email={contact.email} initialKind={kind} initialSubject={subject} initialProductName={productName} lang={lang} t={t} /></SiteContainer></section>
    {faqs.length > 0 && <section className="tw-bg-kb-paper tw-py-10 sm:tw-py-14" aria-labelledby="contact-faq-title"><SiteContainer><h2 id="contact-faq-title" className="tw-mb-5 tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{t('faq_t')}</h2><FaqList items={faqs} /></SiteContainer></section>}
  </main>
}
