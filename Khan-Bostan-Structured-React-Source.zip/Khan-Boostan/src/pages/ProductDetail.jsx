import { useEffect, useState } from 'react'
import { Link, useLocation, useParams } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict, publicItemName, publicItemSummary, publicItemDescription, publicSlug, publicRecords } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import NotFoundCompact from './NotFoundCompact.jsx'
import ProductCard from '../components/ProductCard.jsx'
import Lightbox from '../components/Lightbox.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import Eyebrow from '../components/public/Eyebrow.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'
import DocumentIcon from '../components/public/DocumentIcon.jsx'
import JsonLd from '../components/public/JsonLd.jsx'
import ProductImageFrame from '../components/public/ProductImageFrame.jsx'
import ProductShareLink from '../components/public/ProductShareLink.jsx'
import ProductCanonicalMeta from '../components/public/ProductCanonicalMeta.jsx'

function safeCatalogueReturnPath(candidate) {
  if (typeof candidate !== 'string' || typeof window === 'undefined') return '/products'
  try {
    const url = new URL(candidate, window.location.origin)
    if (url.origin !== window.location.origin || url.pathname.replace(/\/+$/, '') !== '/products') return '/products'
    return `${url.pathname}${url.search}${url.hash}`
  } catch {
    return '/products'
  }
}

function isVerifiedPublicProduct(product) {
  return product?.verified === true && product?.public === true && product?.demo !== true
}

function stableValue(value) {
  if (value == null) return ''
  if (typeof value === 'object') return JSON.stringify(Object.keys(value).sort().map((key) => [key, value[key]]))
  return String(value)
}

function sharedVerifiedSpecCount(product, candidate) {
  const pairFor = (spec) => {
    const key = stableValue(spec?.k).trim()
    const value = stableValue(spec?.v).trim()
    return key && value ? JSON.stringify([key, value]) : ''
  }
  const left = new Set((product.specs ?? []).map(pairFor).filter(Boolean))
  return (candidate.specs ?? []).reduce((score, spec) => {
    const pair = pairFor(spec)
    return score + (pair && left.has(pair) ? 1 : 0)
  }, 0)
}

function verifiedDateLabel(value, lang) {
  if (!value) return ''
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return ''
  return new Intl.DateTimeFormat(lang === 'en' ? 'en-US' : 'fa-AF', { dateStyle: 'medium', timeZone: 'UTC' }).format(date)
}

export default function ProductDetail() {
  const { slug } = useParams()
  const location = useLocation()
  const { data } = useContent()
  const { t, L, lang } = usePublicDict()
  const fa = lang !== 'en'
  const [lb, setLb] = useState(null)
  const [selectedImageIndex, setSelectedImageIndex] = useState(0)
  const [failedImageSources, setFailedImageSources] = useState({})

  useEffect(() => {
    setLb(null)
    setSelectedImageIndex(0)
    setFailedImageSources({})
  }, [slug])

  if (!data) return <PublicLoading />
  const product = (data.products ?? []).find((item) => (item.id === slug || publicSlug(item.id) === slug) && Boolean(L(item.name)))
  if (!product) return <NotFoundCompact />
  const fromQuery = new URLSearchParams(location.search).get('from')
  const returnTo = safeCatalogueReturnPath(location.state?.returnTo || fromQuery)
  const category = (data.categories ?? []).find((item) => item.id === product.category)
  const relatedCandidates = (data.products ?? []).filter((item) => item.id !== product.id && item.category === product.category && Boolean(L(item.name)))
  const canRankRelated = isVerifiedPublicProduct(product) && relatedCandidates.length > 0 && relatedCandidates.every(isVerifiedPublicProduct)
  const relatedSorted = canRankRelated
    ? [...relatedCandidates].sort((a, b) => sharedVerifiedSpecCount(product, b) - sharedVerifiedSpecCount(product, a))
    : relatedCandidates
  const related = relatedSorted.slice(0, 3)
  const sharedImage = Boolean(product.image && (data.products ?? []).filter((item) => item.image === product.image).length > 1)
  const images = (product.gallery?.length ? product.gallery : [product.image]).filter(Boolean)
  const imageIndex = images.length ? Math.min(Math.max(0, selectedImageIndex), images.length - 1) : 0
  const selectedImage = images[imageIndex]
  const selectedSharedIllustration = Boolean(sharedImage && selectedImage === product.image)
  const availableImages = images.filter((image) => !failedImageSources[image] && !(sharedImage && image === product.image))
  const rows = [
    ['brand_l', L(product.brand)],
    ['origin_l', L(product.origin)],
    ['packaging_l', L(product.packaging)],
    ['unit_l', L(product.unit)],
    ['moq_l', product.moq],
  ].filter(([, value]) => value && String(value).trim())
  const specs = (product.specs ?? []).filter((item) => L(item?.k) && L(item?.v))
  const displayName = publicItemName(L(product.name))
  const contactParams = new URLSearchParams({ kind: 'product', subject: displayName, productName: displayName })
  const contactHref = `/contact?${contactParams.toString()}`
  const productDocuments = publicRecords(data.documents ?? []).filter((doc) => doc.kind === 'catalog' && doc.verified === true && doc.public === true && doc.demo !== true && Boolean(doc.file || doc.url) && (doc.product === product.id || (doc.category && doc.category === product.category)))
  const reviewedDate = isVerifiedPublicProduct(product) ? verifiedDateLabel(product.verifiedAt, lang) : ''
  const productSchema = isVerifiedPublicProduct(product) && typeof window !== 'undefined' ? {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: displayName,
    url: `${window.location.origin}${location.pathname}`,
    ...(publicItemSummary(product, L, lang) ? { description: publicItemSummary(product, L, lang) } : {}),
    ...(category ? { category: L(category.name) } : {}),
    ...(product.image ? { image: new URL(product.image, window.location.origin).href } : {}),
    ...(product.brand ? { brand: { '@type': 'Brand', name: L(product.brand) } } : {}),
    ...(specs.length ? { additionalProperty: specs.map((item) => ({ '@type': 'PropertyValue', name: L(item.k), value: L(item.v) })) } : {}),
  } : null

  const markImageFailed = (image) => setFailedImageSources((current) => ({ ...current, [image]: true }))
  const openLightbox = () => {
    const index = availableImages.indexOf(selectedImage)
    if (index >= 0) setLb({ i: index })
  }
  const changeLightboxIndex = (next) => {
    if (!availableImages.length) return
    const current = lb?.i ?? 0
    const requested = typeof next === 'function' ? next(current) : next
    const nextIndex = Math.min(availableImages.length - 1, Math.max(0, requested))
    setLb({ i: nextIndex })
    setSelectedImageIndex(images.indexOf(availableImages[nextIndex]))
  }

  return <>
    <ProductCanonicalMeta pathname={location.pathname} lang={lang} />
    <main id="main" className="tw-flex-1"><Hero image={sharedImage ? '/images/catalogue-line-art.svg' : (product.image || '/images/hero-trade.webp')} crumbs={[[returnTo, t('products_t')], [null, displayName]]} title={displayName} sub={publicItemSummary(product, L, lang)} compact />
      <section className="tw-bg-kb-paper tw-py-10 sm:tw-py-14"><SiteContainer>
        <nav className="tw-mb-5 tw-flex tw-flex-wrap tw-items-center tw-gap-3 tw-text-sm tw-text-kb-navy" aria-label={fa ? 'دسته‌بندی محصول' : 'Product category'}><Link className="tw-font-bold tw-text-kb-blue hover:tw-text-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" to={returnTo}>{t('products_t')}</Link>{category && L(category.name) && <span>{L(category.name)}</span>}</nav>
        <div className="tw-grid tw-gap-8 lg:tw-grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:tw-gap-10">
          <div>
            {selectedImage && !failedImageSources[selectedImage] && !selectedSharedIllustration
              ? <button type="button" onClick={openLightbox} aria-label={fa ? `نمایش تصویر بزرگ کالا: ${displayName}` : `Open image of ${displayName}`} className="tw-group tw-block tw-aspect-[4/3] tw-w-full tw-cursor-zoom-in tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-0 focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue"><ProductImageFrame src={selectedImage} alt={displayName} categoryId={product.category} categoryName={L(category?.name)} fa={fa} onImageError={markImageFailed} /></button>
              : <div className="tw-aspect-[4/3] tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white"><ProductImageFrame src={selectedImage && !failedImageSources[selectedImage] ? selectedImage : null} alt={displayName} categoryId={product.category} categoryName={L(category?.name)} sharedImage={selectedSharedIllustration} fa={fa} /></div>}
            {images.length > 0 && <div className="tw-mt-3">
              <div className="tw-mb-2 tw-flex tw-items-center tw-justify-between tw-gap-2"><span className="tw-text-[10px] tw-font-bold tw-text-kb-muted">{fa ? 'گالری تصاویر' : 'Image gallery'}</span><span className="tw-text-[10px] tw-font-bold tw-text-kb-muted" aria-live="polite">{fa ? `تصویر ${new Intl.NumberFormat('fa-AF', { useGrouping: false }).format(imageIndex + 1)} از ${new Intl.NumberFormat('fa-AF', { useGrouping: false }).format(images.length)}` : `Image ${imageIndex + 1} of ${images.length}`}</span></div>
              {images.length > 1 && <div className="tw-flex tw-gap-2 tw-overflow-x-auto tw-pb-1" role="group" aria-label={fa ? 'انتخاب تصویر محصول' : 'Select product image'}>{images.map((image, index) => <button type="button" onClick={() => setSelectedImageIndex(index)} disabled={Boolean(failedImageSources[image])} aria-pressed={imageIndex === index} aria-label={fa ? `انتخاب تصویر ${index + 1} از ${images.length}` : `Select image ${index + 1} of ${images.length}`} className={`tw-h-16 tw-w-16 tw-shrink-0 tw-overflow-hidden tw-rounded-kb tw-border-2 tw-bg-white tw-p-0 focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue disabled:tw-cursor-not-allowed disabled:tw-opacity-50 ${imageIndex === index ? 'tw-border-kb-blue tw-ring-2 tw-ring-kb-blue/20' : 'tw-border-kb-line'}`} key={`${image}-${index}`}>
                {failedImageSources[image] ? <span className="tw-grid tw-h-full tw-w-full tw-place-items-center tw-bg-kb-paper" aria-label={fa ? 'تصویر بارگذاری نشد' : 'Image did not load'} /> : <img src={image} alt="" loading="lazy" decoding="async" onError={() => markImageFailed(image)} className="tw-h-full tw-w-full tw-object-cover" />}
              </button>)}</div>}
            </div>}
            <div className="tw-mt-4 tw-grid tw-gap-3">
              {product.status && <div className="tw-flex tw-flex-wrap tw-items-center tw-justify-between tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4"><span className="tw-text-sm tw-font-bold tw-text-kb-navy">{fa ? 'وضعیت عرضه' : 'Supply status'}</span><span className="tw-rounded-full tw-border tw-border-kb-gold/35 tw-bg-[#FFF8EE] tw-px-2.5 tw-py-1 tw-text-[10px] tw-font-bold tw-text-[#714613]">{t(`status_${product.status}`, fa ? 'نیازمند استعلام' : 'Requires inquiry')}</span></div>}
              {rows.length > 0 && <dl className="tw-divide-y tw-divide-kb-line tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white" aria-label={fa ? 'معلومات عرضهٔ ثبت‌شده' : 'Listed supply information'}>{rows.map(([key, value]) => <div className="tw-flex tw-flex-wrap tw-items-baseline tw-justify-between tw-gap-2 tw-px-4 tw-py-3 tw-text-sm" key={key}><dt className="tw-break-words tw-font-bold tw-text-kb-navy">{t(key)}</dt><dd className="tw-min-w-0 tw-break-words tw-text-kb-body">{value}</dd></div>)}</dl>}
              {reviewedDate && <p className="tw-rounded-kb tw-bg-white tw-px-4 tw-py-3 tw-text-xs tw-leading-5 tw-text-kb-muted">{fa ? `آخرین به‌روزرسانی: ${reviewedDate}` : `Last updated: ${reviewedDate}`}</p>}
            </div>
          </div>
          <div>
            <div className="tw-mb-4 tw-flex tw-flex-wrap tw-items-center tw-gap-2">{category && <span className="tw-rounded-full tw-bg-white tw-px-3 tw-py-1 tw-text-xs tw-font-bold tw-text-kb-blue">{L(category.name)}</span>}{product.featured && <span className="tw-rounded-full tw-bg-kb-gold tw-px-2.5 tw-py-1 tw-text-[10px] tw-font-bold tw-text-kb-navy">{t('featured_badge')}</span>}</div>
            <h2 className="tw-font-head tw-text-2xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-3xl">{fa ? 'معرفی و کاربردها' : 'Overview & applications'}</h2>
            <div className="tw-mt-4 tw-flex tw-flex-wrap tw-gap-3"><Link to={contactHref} className="tw-inline-flex tw-min-h-11 tw-items-center tw-gap-2 tw-rounded-kb tw-bg-kb-gold tw-px-5 tw-text-sm tw-font-bold tw-text-kb-navy hover:tw-bg-kb-navy hover:tw-text-white focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{t('get_info')}<ArrowIcon /></Link><Link to={returnTo} className="tw-inline-flex tw-min-h-11 tw-items-center tw-rounded-kb tw-border tw-border-kb-line tw-bg-white tw-px-5 tw-text-sm tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{fa ? 'بازگشت به نتایج' : 'Back to results'}</Link><ProductShareLink lang={lang} /></div>
            {publicItemDescription(product, L, lang) && <p className="tw-mt-4 tw-whitespace-pre-line tw-break-words tw-text-sm tw-leading-7 tw-text-kb-body">{publicItemDescription(product, L, lang)}</p>}
            {specs.length > 0 && <><h3 className="tw-mb-3 tw-mt-7 tw-text-lg tw-font-bold tw-text-kb-navy">{t('specs')}</h3><dl className="tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white">{specs.map((item, index) => <div className={`tw-grid tw-grid-cols-1 tw-gap-1 tw-px-4 tw-py-3 tw-text-sm sm:tw-grid-cols-[minmax(0,4fr)_minmax(0,8fr)] sm:tw-gap-3 ${index % 2 ? 'tw-bg-kb-paper' : 'tw-bg-white'}`} key={`${L(item.k)}-${index}`}><dt className="tw-break-words tw-font-bold tw-text-kb-navy">{L(item.k)}</dt><dd className="tw-break-words tw-text-kb-body">{L(item.v)}</dd></div>)}</dl></>}
            {productDocuments.length > 0
              ? <p className="tw-mt-4 tw-flex tw-items-center tw-gap-2 tw-text-xs tw-text-kb-muted"><DocumentIcon /><Link to="/downloads" className="tw-font-bold tw-text-kb-blue hover:tw-underline">{fa ? 'اسناد مرتبط در مرکز دانلود' : 'Related documents in the download centre'}</Link></p>
              : null}
          </div>
        </div>
        {related.length > 0 && <section className="tw-mt-14" aria-labelledby="related-products-title"><Eyebrow>{t('category', fa ? 'دسته‌بندی' : 'Category')}</Eyebrow><h2 id="related-products-title" className="tw-mt-2 tw-font-head tw-text-3xl tw-font-bold tw-leading-tight tw-text-kb-navy sm:tw-text-4xl">{t('related')}</h2>{canRankRelated && <p className="tw-mt-2 tw-text-sm tw-text-kb-muted">{fa ? 'ترتیب بر اساس مشخصات مشترک کالاها است.' : 'Order is based on shared product specifications.'}</p>}<div className="tw-mt-6 tw-grid tw-gap-4 sm:tw-grid-cols-2 lg:tw-grid-cols-3">{related.map((item) => <ProductCard p={item} key={item.id} returnTo={returnTo} />)}</div></section>}
      </SiteContainer></section></main>
    {lb && availableImages.length > 0 && <Lightbox items={availableImages.map((image) => ({ image, caption: null, alt: displayName }))} index={Math.min(lb.i, availableImages.length - 1)} setIndex={changeLightboxIndex} close={() => setLb(null)} />}
    {productSchema && <JsonLd value={productSchema} />}
  </>
}
