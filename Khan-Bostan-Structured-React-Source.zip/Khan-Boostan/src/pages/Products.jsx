import { useEffect, useRef } from 'react'
import { Link, useLocation, useSearchParams } from 'react-router-dom'
import { useContent, bySort } from '../../src/lib/store.jsx'
import { usePublicDict, publicItemName, publicItemSummary, publicRecords, publicSlug } from '../lib.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import Hero from '../components/public/Hero.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import CatalogueFilterBar from '../components/public/CatalogueFilterBar.jsx'
import CatalogueProductCard from '../components/public/CatalogueProductCard.jsx'
import CatalogueComparison from '../components/public/CatalogueComparison.jsx'
import EmptyState from '../components/public/EmptyState.jsx'
import CallToAction from '../components/public/CallToAction.jsx'
import JsonLd from '../components/public/JsonLd.jsx'

const FACET_FIELDS = [
  { key: 'brand', fa: 'برند', en: 'Brand' },
  { key: 'origin', fa: 'کشور مبدأ', en: 'Country of origin' },
  { key: 'packaging', fa: 'بسته‌بندی', en: 'Packaging' },
  { key: 'unit', fa: 'واحد عرضه', en: 'Supply unit' },
]
const VALID_SORTS = ['default', 'name', 'category', 'origin']

const normalizeSearch = (value) => String(value ?? '')
  .normalize('NFKC')
  .replace(/[ي]/g, 'ی')
  .replace(/[ك]/g, 'ک')
  .replace(/[\u064B-\u065F\u0670]/g, '')
  .replace(/\u200c/g, ' ')
  .toLowerCase()

function rawText(value) {
  if (Array.isArray(value)) return value.map(rawText).join(' ')
  if (value && typeof value === 'object') return Object.values(value).map(rawText).join(' ')
  return String(value ?? '')
}

function stableValue(value) {
  if (value == null) return ''
  if (typeof value === 'object') return JSON.stringify(Object.keys(value).sort().map((key) => [key, value[key]]))
  return String(value)
}

function localizedText(value, L) {
  return String(L(value) ?? '').trim()
}

function buildFacetOptions(items, field, L, collator) {
  const values = new Map()
  for (const item of items) {
    const raw = item?.[field]
    const value = stableValue(raw)
    const label = localizedText(raw, L)
    if (!value.trim() || !label) continue
    // A pending placeholder is not a meaningful country-of-origin facet.
    if (field === 'origin' && /pending confirmation|در انتظار تأیید/i.test(label)) continue
    const current = values.get(value) ?? { value, label, count: 0 }
    current.count += 1
    values.set(value, current)
  }
  return [...values.values()].sort((a, b) => collator.compare(a.label, b.label))
}

function buildSpecOptions(items, L, collator) {
  const values = new Map()
  for (const product of items) {
    for (const spec of product.specs ?? []) {
      const keyId = stableValue(spec?.k)
      const valueId = stableValue(spec?.v)
      const keyLabel = localizedText(spec?.k, L)
      const valueLabel = localizedText(spec?.v, L)
      if (!keyId || !valueId || !keyLabel || !valueLabel) continue
      const value = JSON.stringify([keyId, valueId])
      const current = values.get(value) ?? { value, label: `${keyLabel}: ${valueLabel}`, count: 0 }
      current.count += 1
      values.set(value, current)
    }
  }
  return [...values.values()].sort((a, b) => collator.compare(a.label, b.label))
}

function parseSpecFilter(value) {
  if (!value) return null
  try {
    const parsed = JSON.parse(value)
    return Array.isArray(parsed) && parsed.length === 2 ? parsed : null
  } catch {
    return null
  }
}

function matchesSpec(product, specFilter) {
  if (!specFilter) return true
  return (product.specs ?? []).some((spec) => stableValue(spec?.k) === specFilter[0] && stableValue(spec?.v) === specFilter[1])
}

function isVerifiedPublicProduct(product) {
  return product?.verified === true && product?.public === true && product?.demo !== true
}

function getPaginationTokens(total, current) {
  if (total <= 7) return Array.from({ length: total }, (_, index) => index + 1)
  const pages = new Set([1, total])
  if (current <= 4) for (let page = 1; page <= 5; page += 1) pages.add(page)
  else if (current >= total - 3) for (let page = total - 4; page <= total; page += 1) pages.add(page)
  else for (let page = current - 1; page <= current + 1; page += 1) pages.add(page)
  const sorted = [...pages].sort((a, b) => a - b)
  const tokens = []
  for (let index = 0; index < sorted.length; index += 1) {
    if (index > 0 && sorted[index] - sorted[index - 1] > 1) tokens.push(`ellipsis-${sorted[index - 1]}-${sorted[index]}`)
    tokens.push(sorted[index])
  }
  return tokens
}

export default function Products() {
  const { data } = useContent()
  const { t, L, lang } = usePublicDict()
  const fa = lang !== 'en'
  const [searchParams, setSearchParams] = useSearchParams()
  const location = useLocation()
  const resultsRef = useRef(null)
  const scrollResultsPending = useRef(false)
  const query = searchParams.get('q') || ''
  const categoryId = searchParams.get('c') || 'all'
  const requestedPage = Math.max(1, Number.parseInt(searchParams.get('page') || '1', 10) || 1)
  const selectedFacets = Object.fromEntries(FACET_FIELDS.map(({ key }) => [key, searchParams.get(key) || '']))
  const specFilterId = searchParams.get('spec') || ''
  const specFilter = parseSpecFilter(specFilterId)
  const requestedSort = searchParams.get('sort') || 'default'
  const pageSize = 8

  useEffect(() => {
    if (!scrollResultsPending.current) return undefined
    scrollResultsPending.current = false
    let secondFrame = 0
    const firstFrame = requestAnimationFrame(() => {
      secondFrame = requestAnimationFrame(() => {
        const target = resultsRef.current
        if (!target) return
        target.focus({ preventScroll: true })
        const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
        target.scrollIntoView({ behavior: reducedMotion ? 'instant' : 'smooth', block: 'start' })
      })
    })
    return () => { cancelAnimationFrame(firstFrame); if (secondFrame) cancelAnimationFrame(secondFrame) }
  }, [requestedPage])

  const updateFilter = (key, value) => {
    const next = new URLSearchParams(searchParams)
    if (value && value !== 'all' && !(key === 'sort' && value === 'default')) next.set(key, value)
    else next.delete(key)
    next.delete('page')
    setSearchParams(next, { replace: true, preventScrollReset: true })
  }

  const clearAllFilters = () => {
    const next = new URLSearchParams()
    if (searchParams.has('lang')) next.set('lang', searchParams.get('lang'))
    if (searchParams.has('compare')) next.set('compare', searchParams.get('compare'))
    setSearchParams(next, { replace: true, preventScrollReset: true })
  }

  if (!data) return <PublicLoading />

  const categories = (data.categories ?? []).filter((item) => Boolean(L(item.name)))
  const all = [...(data.products ?? []).filter((item) => Boolean(L(item.name)))].sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || bySort(a, b))
  const collator = new Intl.Collator(lang === 'en' ? 'en-US' : 'fa-AF', { sensitivity: 'base', numeric: true })
  const normalizedQuery = normalizeSearch(query.trim())
  const categoryFor = (id) => categories.find((item) => item.id === id)
  const categoryName = (id) => localizedText(categoryFor(id)?.name, L)
  const originOptions = buildFacetOptions(all.filter(isVerifiedPublicProduct), 'origin', L, collator)
  const sortBy = VALID_SORTS.includes(requestedSort) && (requestedSort !== 'origin' || originOptions.length > 1) ? requestedSort : 'default'

  const matchesSearch = (product) => {
    if (!normalizedQuery) return true
    const category = categoryFor(product.category)
    const specText = (product.specs ?? []).flatMap((spec) => [spec?.k, spec?.v])
    const searchable = [product.name, product.short, product.description, product.brand, product.origin, product.packaging, product.unit, category?.name, specText]
      .map(rawText)
      .join(' ')
    return normalizeSearch(searchable).includes(normalizedQuery)
  }

  const matches = (product, excludedFacet = '') => {
    if (excludedFacet !== 'category' && categoryId !== 'all' && product.category !== categoryId) return false
    if (!matchesSearch(product)) return false
    for (const { key } of FACET_FIELDS) {
      if (excludedFacet === key || !selectedFacets[key]) continue
      if (stableValue(product[key]) !== selectedFacets[key]) return false
    }
    if (excludedFacet !== 'spec' && !matchesSpec(product, specFilter)) return false
    return true
  }

  const matched = all.filter((product) => matches(product))
  const sortedFiltered = [...matched].sort((a, b) => {
    const nameA = localizedText(a.name, L)
    const nameB = localizedText(b.name, L)
    if (sortBy === 'name') return collator.compare(nameA, nameB) || bySort(a, b)
    if (sortBy === 'category') return collator.compare(categoryName(a.category), categoryName(b.category)) || collator.compare(nameA, nameB)
    if (sortBy === 'origin') return collator.compare(localizedText(a.origin, L), localizedText(b.origin, L)) || collator.compare(nameA, nameB)
    return Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || bySort(a, b)
  })

  const facetBase = (field) => all.filter((product) => matches(product, field))
  const categoryBase = all.filter((product) => matches(product, 'category'))
  const categoryCounts = { all: categoryBase.length }
  for (const category of categories) categoryCounts[category.id] = categoryBase.filter((product) => product.category === category.id).length

  const facetOptions = Object.fromEntries(FACET_FIELDS.map(({ key }) => {
    const items = facetBase(key)
    const safeItems = key === 'origin' ? items.filter(isVerifiedPublicProduct) : items
    return [key, buildFacetOptions(safeItems, key, L, collator)]
  }))
  const specOptions = buildSpecOptions(facetBase('spec'), L, collator)
  const labelForFacet = (key, value) => {
    const option = facetOptions[key]?.find((item) => item.value === value)
    if (option) return option.label
    const product = all.find((item) => stableValue(item[key]) === value)
    return product ? localizedText(product[key], L) : value
  }
  const labelForSpec = (value) => {
    const option = specOptions.find((item) => item.value === value)
    if (option) return option.label
    const pair = parseSpecFilter(value)
    if (!pair) return value
    for (const product of all) {
      const spec = (product.specs ?? []).find((item) => stableValue(item?.k) === pair[0] && stableValue(item?.v) === pair[1])
      if (spec) return `${localizedText(spec.k, L)}: ${localizedText(spec.v, L)}`
    }
    return value
  }

  const activeFilters = []
  if (query.trim()) activeFilters.push({ key: 'q', label: `${fa ? 'جستجو' : 'Search'}: ${query.trim()}` })
  if (categoryId !== 'all') activeFilters.push({ key: 'c', label: `${fa ? 'دسته' : 'Category'}: ${categoryName(categoryId)}` })
  for (const { key, fa: faLabel, en: enLabel } of FACET_FIELDS) {
    if (selectedFacets[key]) activeFilters.push({ key, label: `${fa ? faLabel : enLabel}: ${labelForFacet(key, selectedFacets[key])}` })
  }
  if (specFilterId && specFilter) activeFilters.push({ key: 'spec', label: `${fa ? 'مشخصات' : 'Specification'}: ${labelForSpec(specFilterId)}` })

  const filterControls = FACET_FIELDS.map(({ key, fa: faLabel, en: enLabel }) => {
    const options = [...(facetOptions[key] ?? [])]
    const value = selectedFacets[key]
    if (value && !options.some((option) => option.value === value)) options.unshift({ value, label: labelForFacet(key, value), count: 0 })
    return { key, label: fa ? faLabel : enLabel, value, options }
  }).filter((filter) => filter.options.length > 1 || Boolean(filter.value))
  if (specOptions.length > 1 || specFilterId) {
    const options = [...specOptions]
    if (specFilterId && !options.some((option) => option.value === specFilterId)) options.unshift({ value: specFilterId, label: labelForSpec(specFilterId), count: 0 })
    filterControls.push({ key: 'spec', label: fa ? 'مشخصات فنی' : 'Specification', value: specFilterId, options })
  }

  const sortOptions = [
    { value: 'default', label: fa ? 'ترتیب پیش‌فرض' : 'Default order' },
    { value: 'name', label: fa ? 'نام کالا' : 'Product name' },
    { value: 'category', label: fa ? 'دسته‌بندی' : 'Category' },
    ...(originOptions.length > 1 ? [{ value: 'origin', label: fa ? 'کشور مبدأ' : 'Country of origin' }] : []),
  ]

  const numberFormat = new Intl.NumberFormat(lang === 'fa' ? 'fa-AF' : 'en-US', { useGrouping: false })
  const countText = fa ? `${numberFormat.format(matched.length)} محصول` : `${numberFormat.format(matched.length)} products`
  const totalPages = Math.max(1, Math.ceil(matched.length / pageSize))
  const currentPage = Math.min(requestedPage, totalPages)
  const pageItems = sortedFiltered.slice((currentPage - 1) * pageSize, currentPage * pageSize)
  const firstResult = matched.length ? (currentPage - 1) * pageSize + 1 : 0
  const lastResult = Math.min(currentPage * pageSize, matched.length)
  const rangeText = fa
    ? `${numberFormat.format(firstResult)} تا ${numberFormat.format(lastResult)} از ${numberFormat.format(matched.length)} محصول`
    : `${numberFormat.format(firstResult)}–${numberFormat.format(lastResult)} of ${numberFormat.format(matched.length)} products`

  const imageUseCount = all.reduce((counts, item) => {
    if (item.image) counts[item.image] = (counts[item.image] ?? 0) + 1
    return counts
  }, {})
  const updatePage = (page) => {
    const next = new URLSearchParams(searchParams)
    if (page <= 1) next.delete('page')
    else next.set('page', String(page))
    scrollResultsPending.current = true
    setSearchParams(next, { replace: true, preventScrollReset: true })
  }

  const comparableProducts = all.filter((product) => isVerifiedPublicProduct(product) && (product.specs?.length || product.brand || product.origin || product.packaging || product.unit))
  const comparableIds = new Set(comparableProducts.map((product) => product.id))
  let comparisonIds = []
  try {
    const parsed = JSON.parse(searchParams.get('compare') || '[]')
    if (Array.isArray(parsed)) comparisonIds = parsed.map(String)
  } catch {
    comparisonIds = (searchParams.get('compare') || '').split(',').filter(Boolean)
  }
  comparisonIds = [...new Set(comparisonIds.filter((id) => comparableIds.has(id)))].slice(0, 3)
  const compared = comparisonIds.map((id) => comparableProducts.find((product) => product.id === id)).filter(Boolean)
  const toggleComparison = (id) => {
    const nextIds = comparisonIds.includes(id) ? comparisonIds.filter((current) => current !== id) : comparisonIds.length < 3 ? [...comparisonIds, id] : comparisonIds
    const next = new URLSearchParams(searchParams)
    if (nextIds.length) next.set('compare', JSON.stringify(nextIds))
    else next.delete('compare')
    setSearchParams(next, { replace: true, preventScrollReset: true })
  }
  const clearComparison = () => {
    const next = new URLSearchParams(searchParams)
    next.delete('compare')
    setSearchParams(next, { replace: true, preventScrollReset: true })
  }

  const docs = publicRecords(data.documents ?? []).filter((doc) => doc.kind === 'catalog' && doc.verified === true && doc.public === true && doc.demo !== true && Boolean(doc.file || doc.url))
  const brands = publicRecords(data.brands ?? []).filter((brand) => brand.verified === true && brand.public === true && brand.demo !== true && Boolean(L(brand.name)))
  const returnTo = `${location.pathname}${location.search}${location.hash || ''}`

  const verifiedProducts = all.filter(isVerifiedPublicProduct)
  const siteOrigin = typeof window !== 'undefined' ? window.location.origin : ''
  const listSchema = verifiedProducts.length && siteOrigin ? {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    numberOfItems: verifiedProducts.length,
    itemListElement: verifiedProducts.map((product, index) => {
      const name = publicItemName(L(product.name))
      const category = categoryFor(product.category)
      const item = {
        '@type': 'Product',
        name,
        url: `${siteOrigin}/products/${encodeURIComponent(publicSlug(product.id))}`,
      }
      const description = publicItemSummary(product, L, lang)
      if (description) item.description = description
      if (category) item.category = L(category.name)
      if (product.image) item.image = new URL(product.image, siteOrigin).href
      if (product.brand) item.brand = { '@type': 'Brand', name: L(product.brand) }
      return { '@type': 'ListItem', position: index + 1, item }
    }),
  } : null

  return <main id="main" className="tw-flex-1">
    <Hero image="/images/catalogue-line-art.svg" crumbs={[[null, t('nav_products')]]} title={t('nav_products')} sub={t('products_d')} compact />
    <section id="ref-shop-catalogue" className="tw-bg-white tw-py-3 sm:tw-py-6" aria-label={fa ? 'فهرست کالاها' : 'Product catalogue'}>
      <div className="tw-sticky tw-top-0 tw-z-30 tw-bg-white/95 tw-py-2 tw-shadow-sm"><CatalogueFilterBar
        fa={fa}
        t={t}
        L={L}
        query={query}
        onQueryChange={(value) => updateFilter('q', value)}
        categories={categories}
        categoryId={categoryId}
        categoryCounts={categoryCounts}
        onCategoryChange={(value) => updateFilter('c', value)}
        countText={countText}
        sortBy={sortBy}
        sortOptions={sortOptions}
        onSortChange={(value) => updateFilter('sort', value)}
        filters={filterControls}
        onFilterChange={(key, value) => updateFilter(key, value)}
        activeFilters={activeFilters}
        onClearAll={clearAllFilters}
      /></div>
      <SiteContainer className="tw-mt-4">
        {matched.length ? <>
          <div className="tw-mb-4 tw-flex tw-flex-wrap tw-items-center tw-justify-between tw-gap-2"><p className="tw-text-sm tw-font-bold tw-text-kb-navy">{rangeText}</p><p className="tw-text-xs tw-text-kb-muted">{fa ? 'برای جزئیات هر کالا، کارت آن را باز کنید.' : 'Open a product card for its details.'}</p></div>
          <div ref={resultsRef} id="product-results" role="region" aria-labelledby="product-results-title" tabIndex="-1" style={{ scrollMarginTop: '8rem' }}><h2 id="product-results-title" className="tw-sr-only">{fa ? 'نتایج محصولات' : 'Product results'}</h2><div className="tw-flex tw-flex-wrap tw-justify-center tw-gap-5">{pageItems.map((product) => {
            const name = publicItemName(L(product.name))
            return <CatalogueProductCard
              key={product.id}
              product={product}
              name={name}
              summary={publicItemSummary(product, L, lang)}
              categoryName={categoryName(product.category)}
              categoryId={product.category}
              className="tw-basis-full tw-grow-0 tw-shrink-0 sm:tw-basis-[calc(50%_-_0.625rem)] lg:tw-basis-[calc(33.333333%_-_0.833333rem)] 2xl:tw-basis-[calc(25%_-_0.9375rem)]"
              lang={lang}
              fa={fa}
              t={t}
              sharedImage={imageUseCount[product.image] > 1}
              returnTo={returnTo}
              canCompare={comparableIds.has(product.id)}
              selectedForComparison={comparisonIds.includes(product.id)}
              compareDisabled={comparisonIds.length >= 3 && !comparisonIds.includes(product.id)}
              onToggleCompare={() => toggleComparison(product.id)}
            />
          })}</div></div>
          {totalPages > 1 && <nav className="tw-mt-8 tw-flex tw-flex-wrap tw-items-center tw-justify-between tw-gap-4" aria-label={fa ? 'صفحه‌بندی کاتالوگ محصولات' : 'Product catalogue pagination'}>
            <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2">
              <button type="button" disabled={currentPage <= 1} onClick={() => updatePage(currentPage - 1)} className="tw-min-h-10 tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-4 tw-text-sm tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue disabled:tw-cursor-not-allowed disabled:tw-opacity-50">{fa ? 'قبلی' : 'Previous'}</button>
              <div className="tw-flex tw-flex-wrap tw-items-center tw-gap-1" role="group" aria-label={fa ? 'رفتن به شمارهٔ صفحه' : 'Go to page number'}>
                {getPaginationTokens(totalPages, currentPage).map((token) => typeof token === 'number' ? <button type="button" key={token} aria-current={currentPage === token ? 'page' : undefined} onClick={() => updatePage(token)} className={`tw-grid tw-h-10 tw-min-w-10 tw-place-items-center tw-rounded-kb tw-border tw-px-3 tw-text-sm tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${currentPage === token ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-control tw-bg-white tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`}>{numberFormat.format(token)}</button> : <span key={token} aria-hidden="true" className="tw-px-1 tw-text-sm tw-text-kb-muted">…</span>)}
              </div>
              <button type="button" disabled={currentPage >= totalPages} onClick={() => updatePage(currentPage + 1)} className="tw-min-h-10 tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-4 tw-text-sm tw-font-bold tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue disabled:tw-cursor-not-allowed disabled:tw-opacity-50">{fa ? 'بعدی' : 'Next'}</button>
            </div>
            <span className="tw-text-xs tw-font-bold tw-text-kb-muted" aria-live="polite">{fa ? `صفحهٔ ${numberFormat.format(currentPage)} از ${numberFormat.format(totalPages)}` : `Page ${numberFormat.format(currentPage)} of ${numberFormat.format(totalPages)}`}</span>
          </nav>}
        </> : activeFilters.length > 0 && <EmptyState title={t('no_results')} copy={fa ? 'عبارت جستجو یا فیلترها را تغییر دهید؛ می‌توانید فیلترها را پاک کنید یا املای عبارت را بررسی نمایید.' : 'Try removing a filter or checking the spelling of your search.'} action={<button className="tw-mt-4 tw-min-h-10 tw-rounded-kb tw-bg-kb-blue tw-px-4 tw-text-sm tw-font-bold tw-text-white hover:tw-bg-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold" type="button" onClick={clearAllFilters}>{fa ? 'پاک‌کردن جستجو و فیلترها' : 'Clear search and filters'}</button>} />}
        {compared.length > 0 && <CatalogueComparison products={compared} categories={categories} L={L} fa={fa} t={t} onRemove={toggleComparison} onClear={clearComparison} />}
      </SiteContainer>
    </section>

    {brands.length > 0 && <section className="tw-bg-kb-paper tw-py-8 sm:tw-py-10" aria-labelledby="products-brands-title"><SiteContainer><Link to="/partners#brands" className="tw-group tw-flex tw-flex-col tw-gap-4 sm:tw-flex-row sm:tw-items-center sm:tw-justify-between focus-visible:tw-rounded-kb focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue"><div><span className="tw-text-[10px] tw-font-bold tw-tracking-[.12em] tw-text-kb-navy">{fa ? 'برندهای عرضه‌شده' : 'Brands offered'}</span><h2 id="products-brands-title" className="tw-mt-2 tw-font-head tw-text-xl tw-font-bold tw-text-kb-navy">{fa ? 'فهرست برندها با توضیح دقیق نوع رابطه' : 'Brand list with the exact type of relation'}</h2></div><ArrowIcon className="tw-shrink-0 tw-text-kb-blue" /></Link></SiteContainer></section>}

    {docs.length > 0
      ? <section className="tw-bg-white tw-py-8 sm:tw-py-10" aria-labelledby="products-documents-title"><SiteContainer><Link to="/downloads" className="tw-group tw-flex tw-flex-col tw-gap-4 sm:tw-flex-row sm:tw-items-center sm:tw-justify-between focus-visible:tw-rounded-kb focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue"><div><span className="tw-text-[10px] tw-font-bold tw-tracking-[.12em] tw-text-kb-navy">{fa ? 'کاتالوگ محصولات' : 'Product catalogue'}</span><h2 id="products-documents-title" className="tw-mt-2 tw-text-lg tw-font-bold tw-text-kb-navy">{fa ? 'کاتالوگ‌ها در مرکز دانلود' : 'Catalogues in the download centre'}</h2></div><ArrowIcon className="tw-shrink-0 tw-text-kb-blue" /></Link></SiteContainer></section>
      : <section className="tw-bg-white tw-py-7 sm:tw-py-9" aria-labelledby="products-documents-title"><SiteContainer className="tw-flex tw-flex-col tw-gap-4 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-kb-paper tw-p-5 sm:tw-flex-row sm:tw-items-center sm:tw-justify-between sm:tw-p-6"><div><span className="tw-text-[10px] tw-font-bold tw-tracking-[.12em] tw-text-kb-navy">{fa ? 'اسناد محصولات' : 'Product documents'}</span><h2 id="products-documents-title" className="tw-mt-2 tw-text-lg tw-font-bold tw-text-kb-navy">{fa ? 'برای دریافت کاتالوگ محصولات با ما تماس بگیرید' : 'Request a product catalogue'}</h2><p className="tw-mt-2 tw-max-w-3xl tw-text-sm tw-leading-6 tw-text-kb-body">{fa ? 'برای دریافت معلومات بیشتر دربارهٔ کالاها با ما تماس بگیرید.' : 'Contact us for more information about our products.'}</p></div><Link to={`/contact?kind=product&lang=${lang === 'en' ? 'en' : 'fa'}`} className="tw-inline-flex tw-min-h-10 tw-shrink-0 tw-items-center tw-justify-center tw-gap-2 tw-rounded-kb tw-bg-kb-blue tw-px-4 tw-text-sm tw-font-bold tw-text-white hover:tw-bg-kb-navy focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold">{fa ? 'استعلام دربارهٔ کالا' : 'Ask about a product'}<ArrowIcon /></Link></SiteContainer></section>}
    <CallToAction />
    {listSchema && <JsonLd value={listSchema} />}
  </main>
}
