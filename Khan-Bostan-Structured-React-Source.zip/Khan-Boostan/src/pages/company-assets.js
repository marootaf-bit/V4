// Uploaded relation images can be absent or malformed. Only HTTP(S) image URLs
// are offered to <img>; every logo also has a visible text-name fallback.
export function usableLogo(value) {
  if (typeof value !== 'string' || !value.trim() || value.length > 2048) return ''
  try {
    const base = typeof window === 'undefined' ? 'https://example.invalid' : window.location.origin
    const url = new URL(value.trim(), base)
    return ['http:', 'https:'].includes(url.protocol) ? url.href : ''
  } catch { return '' }
}
