import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { useContent, bySort } from '../../src/lib/store.jsx'
import { usePublicDict, publicRecords } from '../lib.jsx'
import CompanyHero from '../components/CompanyHero.jsx'
import CompanyLoading from '../components/CompanyLoading.jsx'
import AboutSectionNav from '../components/public/AboutSectionNav.jsx'
import AboutIntroSection from '../components/public/AboutIntroSection.jsx'
import AboutPurposeValues from '../components/public/AboutPurposeValues.jsx'
import AboutApproach from '../components/public/AboutApproach.jsx'
import AboutManagementMessage from '../components/public/AboutManagementMessage.jsx'
import AboutValuesSection from '../components/public/AboutValuesSection.jsx'
import TeamDirectory from '../components/public/TeamDirectory.jsx'
import AboutProfileDownload from '../components/public/AboutProfileDownload.jsx'
import AboutFaqSection from '../components/public/AboutFaqSection.jsx'
import AboutTradeSections from '../components/public/AboutTradeSections.jsx'
import AboutRelatedPages from '../components/public/AboutRelatedPages.jsx'
import CallToAction from '../components/public/CallToAction.jsx'
import PrimaryLink from '../components/public/PrimaryLink.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'
import JsonLd from '../components/public/JsonLd.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'

const COPY = {
  fa: {
    pageTitle: 'درباره ما', intro: 'معرفی و ماهیت فعالیت', official: 'نام رسمی شرکت',
    history: 'تاریخچه', structure: 'ساختار و شیوهٔ کار', natureTitle: 'ماهیت فعالیت',
    natureNote: 'فعالیت شرکت چندبخشی است و به یک محصول ثابت وابسته نیست.',
    missionVision: 'مأموریت و چشم‌انداز', approach: 'چگونگی شکل‌گیری همکاری',
    messageTitle: 'پیام مدیریت', colleagues: 'تیم شرکت', values: 'ارزش‌های کاری',
    photo: 'فضای کاری تجارتی', meetingPhoto: 'نشست تجارتی', profile: 'پروفایل شرکت',
    profileDownload: 'دانلود', activities: 'فعالیت‌های تجارتی', contact: 'تماس با ما',
    faqTitle: 'پرسش‌های متداول دربارهٔ شرکت', relatedTitle: 'صفحه‌های مرتبط',
    tradeRoleNav: 'نقش ما', marketCriteriaNav: 'بازار و کالا', clarityNav: 'پیش از توافق', collaboratorsNav: 'مخاطبان همکاری', startEnquiryNav: 'آغاز درخواست',
    partnersTitle: 'شرکا و روابط تجارتی', partnersText: 'رکوردهای روابط تجارتی و برندهای عرضه‌شده را ببینید.',
    careersTitle: 'فرصت‌های شغلی', careersText: 'معلومات صفحهٔ فرصت‌های شغلی را بررسی کنید.', openPage: 'رفتن به صفحه',
    reviewed: 'آخرین به‌روزرسانی',
  },
  en: {
    pageTitle: 'About us', intro: 'Introduction & nature of work', official: 'Official company name',
    history: 'Company history', structure: 'Organization & way of working', natureTitle: 'Nature of activity',
    natureNote: 'Our activity is multi-sector and not tied to a single fixed product.',
    missionVision: 'Mission & vision', approach: 'How trade enquiries are approached',
    messageTitle: 'Message from management', colleagues: 'Our team', values: 'Working values',
    photo: 'Commercial workspace', meetingPhoto: 'Business meeting', profile: 'Company profile',
    profileDownload: 'Download', activities: 'Trade activities', contact: 'Contact us',
    faqTitle: 'Frequently asked questions about the company', relatedTitle: 'Related pages',
    tradeRoleNav: 'Our role', marketCriteriaNav: 'Market & goods', clarityNav: 'Before agreement', collaboratorsNav: 'Who we work with', startEnquiryNav: 'Start an enquiry',
    partnersTitle: 'Partners & trade relationships', partnersText: 'Browse trade-relationship records and brands offered.',
    careersTitle: 'Careers', careersText: 'Review information on the careers page.', openPage: 'Open page',
    reviewed: 'Last updated',
  },
}

function validIsoDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false
  const date = new Date(`${value}T12:00:00Z`)
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value
}

export default function About() {
  const { data, settings } = useContent()
  const { t, L, lang } = usePublicDict()
  const { hash } = useLocation()
  const fa = lang !== 'en'
  const c = COPY[fa ? 'fa' : 'en']
  const company = settings?.company ?? {}
  const about = settings.about ?? {}
  const sections = settings.sections ?? {}
  const team = [...publicRecords(data?.team ?? [])].filter((member) => Boolean(L(member.name))).sort(bySort)
  const teamVisible = Boolean(sections.showTeam !== false && team.length)
  const speaker = team.find((member) => member.group === 'leadership' && L(member.message)) ?? team.find((member) => L(member.message))
  const message = speaker ? L(speaker.message) : ''
  const values = (about.values ?? []).filter((item) => L(item.title) || L(item.text))
  const fullIntroduction = L(company.about)
  const history = L(about.history)
  const structure = L(about.structure)
  const mission = L(about.mission)
  const vision = L(about.vision)
  const approach = L(company.approach)
  const profile = sections.showDownloads !== false ? publicRecords(data?.documents ?? []).find((doc) => doc.kind === 'profile' && doc.file && Boolean(L(doc.title))) : null
  const aboutFaqs = publicRecords(data?.faq ?? []).filter((item) => ['about', 'general'].includes(item.topic) && item.approved === true && item.demo !== true && L(item.q) && L(item.a))
  const reviewDate = about.reviewedAtVerified === true && about.reviewedAtDemo !== true && validIsoDate(about.reviewedAt) ? about.reviewedAt : ''
  const reviewDateLabel = reviewDate ? new Intl.DateTimeFormat(fa ? 'fa-AF' : 'en', { dateStyle: 'long', timeZone: 'UTC' }).format(new Date(`${reviewDate}T12:00:00Z`)) : ''
  const origin = typeof window === 'undefined' ? '' : window.location.origin
  const organizationName = L(company.legal) || L(company.name)
  const pageUrl = origin ? `${origin}/about` : ''
  const schema = pageUrl && organizationName ? {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'Organization', '@id': `${origin}/#organization`, name: organizationName, url: origin, logo: `${origin}/brand/khan-boostan-official.png` },
      { '@type': 'AboutPage', '@id': `${pageUrl}#webpage`, url: pageUrl, name: c.pageTitle, description: L(company.summary), about: { '@id': `${origin}/#organization` }, breadcrumb: { '@id': `${pageUrl}#breadcrumb` } },
      { '@type': 'BreadcrumbList', '@id': `${pageUrl}#breadcrumb`, itemListElement: [
        { '@type': 'ListItem', position: 1, name: t('home'), item: origin },
        { '@type': 'ListItem', position: 2, name: t('nav_about'), item: pageUrl },
      ] },
    ],
  } : null
  const navItems = [
    { href: '#about-intro', label: c.intro },
    (mission || vision) && { href: '#about-purpose', label: c.missionVision },
    approach && { href: '#about-approach', label: c.approach },
    values.length > 0 && { href: '#about-values', label: c.values },
    teamVisible && { href: '#team', label: c.colleagues },
    { href: '#about-trade-role', label: c.tradeRoleNav },
    { href: '#about-market-criteria', label: c.marketCriteriaNav },
    { href: '#about-trade-clarity', label: c.clarityNav },
    { href: '#about-collaborators', label: c.collaboratorsNav },
    { href: '#about-start-enquiry', label: c.startEnquiryNav },
    aboutFaqs.length > 0 && { href: '#about-faq', label: c.faqTitle },
    profile && { href: '#about-profile', label: c.profile },
    { href: '#about-related-pages', label: c.relatedTitle },
  ].filter(Boolean)

  useEffect(() => {
    if (hash !== '#team' || !teamVisible) return
    const frame = requestAnimationFrame(() => {
      const behavior = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'
      document.getElementById('team')?.scrollIntoView({ behavior, block: 'start' })
    })
    return () => cancelAnimationFrame(frame)
  }, [hash, teamVisible])

  if (!data) return <CompanyLoading lang={lang} />

  return <main id="main" className="tw-flex-1 print:tw-bg-white">
    {schema && <JsonLd value={schema} />}
    <div className="print:tw-hidden"><CompanyHero image="/images/about-office.webp" imageSet="/images/about-office-sm.webp 640w, /images/about-office-md.webp 1000w, /images/about-office.webp 1536w" title={c.pageTitle} summary={L(company.summary)} crumbs={[{ label: t('nav_about') }]} showSnapshot={sections.showFacts !== false} compact contentPanel>
      <PrimaryLink to="/activities" variant="gold" className="tw-w-full sm:tw-w-auto">{c.activities}<ArrowIcon /></PrimaryLink>
      <PrimaryLink to="/contact" variant="blue" className="tw-w-full sm:tw-w-auto">{c.contact}<ArrowIcon /></PrimaryLink>
    </CompanyHero></div>
    <h1 className="tw-hidden print:tw-mb-5 print:tw-block tw-font-head tw-text-3xl tw-font-bold tw-text-kb-navy">{c.pageTitle}</h1>
    <AboutSectionNav items={navItems} fa={fa} />
    {reviewDateLabel && <SiteContainer className="tw-pt-3 print:tw-pt-0"><p className="tw-text-xs tw-text-kb-muted"><span className="tw-font-bold">{c.reviewed}:</span> <time dateTime={reviewDate}>{reviewDateLabel}</time></p></SiteContainer>}
    <AboutIntroSection c={c} L={L} companyLegal={company.legal} fullIntroduction={fullIntroduction} natureNote={c.natureNote} history={history} structure={structure} lang={lang} />
    <AboutPurposeValues mission={mission} vision={vision} fa={fa} />
    <AboutApproach approach={approach} fa={fa} title={c.approach} />
    {teamVisible && message && <AboutManagementMessage speaker={speaker} message={message} lang={lang} L={L} c={c} />}
    <AboutValuesSection values={values} L={L} fa={fa} t={t} />
    {teamVisible && <TeamDirectory members={team} L={L} lang={lang} t={t} />}
    <AboutTradeSections lang={lang} />
    <AboutFaqSection items={aboutFaqs} L={L} c={c} lang={lang} />
    <AboutRelatedPages c={c} lang={lang} />
    <AboutProfileDownload profile={profile} c={c} t={t} L={L} lang={lang} />
    <div className="print:tw-hidden"><CallToAction showActivitiesLink /></div>
  </main>
}
