import ContactActions from '../components/public/ContactActions.jsx'
import { Link } from 'react-router-dom'
import { useContent, bySort } from '../lib/store.jsx'
import { usePublicDict, publicNews } from '../lib.jsx'
import HomeCategories from '../components/public/HomeCategories.jsx'
import HomeNews from '../components/public/HomeNews.jsx'
import HomeContact from '../components/public/HomeContact.jsx'
import ArrowIcon from '../components/public/ArrowIcon.jsx'
import PrimaryLink from '../components/public/PrimaryLink.jsx'

export default function Home() {
  const { data, settings } = useContent()
  const { t, L, lang } = usePublicDict()
  const fa = lang === 'fa'
  const company = settings.company ?? {}
  const sections = settings.sections ?? {}
  const categories = (data?.categories ?? []).filter(item => L(item.name))
  const products = (data?.products ?? []).filter(item => L(item.name))
  const stories = [...publicNews(data?.news ?? [])].filter(item => L(item.title)).sort((a,b) => (b.date ?? '').localeCompare(a.date ?? '') || bySort(a,b))
  const featured = stories.find(item => item.featured) ?? stories[0]
  const services = [
    { key:'products', to:'/products', image:'/images/product-rice.webp', title:fa?'محصولات اصلی شرکت':'Our main products', copy:fa?'محصولات وارداتی و صادراتی را مرور کنید و دربارهٔ مشخصات، قیمت و شرایط عرضه بپرسید.':'Explore main import and export products and enquire about specifications, pricing and supply terms.' },
    { key:'sourcing', to:'/sourcing', image:'/images/trade-warehouse.webp', title:fa?'تأمین کالا به سفارش شما':'Goods sourced for your needs', copy:fa?'جنس موردنظر شما در فهرست نیست؟ برای شناسایی، بررسی و قیمت‌گیری از بازار داخلی یا خارجی درخواست بفرستید.':'Not finding your goods in the catalogue? Request identification, review and pricing from domestic or overseas markets.' },
    { key:'logistics', to:'/logistics', image:'/images/trade-cargo.webp', title:fa?'لوجستیک برای کالای شما':'Logistics for your goods', copy:fa?'کالا را خریده‌اید؟ برای همه یا بخشی از مراحل انتقال، امور گمرکی و تحویل با ما گفتگو کنید.':'Already purchased? Discuss all or selected stages of transport, customs coordination and delivery.' },
  ]
  const steps = fa ? [['شناخت نیاز','نوع کالا، مقدار و مقصد را مشخص کنید.'],['بررسی و پیشنهاد','دربارهٔ مشخصات، قیمت و شرایط توافق کنید.'],['هماهنگی','آماده‌سازی کالا و اسناد را پیگیری کنید.'],['انتقال و تحویل','مراحل انتقال تا تحویل را دنبال کنید.']] : [['Define the need','Specify your goods, quantity and destination.'],['Review the proposal','Discuss specifications, pricing and terms.'],['Coordinate','Follow preparation of goods and documents.'],['Deliver','Track the shipment through to delivery.']]
  return <main id="main" className="kb-home tw-flex-1">
    <section className="kb-home-hero" aria-labelledby="home-title">
      <div className="kb-hero-photo"><img src={settings.hero?.image || '/images/hero-trade.webp'} alt="" width="1536" height="1024" fetchpriority="high" /></div>
      <div className="kb-wrap kb-hero-layout">
        <div className="kb-hero-copy">
          <span className="kb-kicker kb-kicker-light">{fa?'خان بوستان | مزارشریف، افغانستان':'KHAN BOSTAN | MAZAR-E-SHARIF, AFGHANISTAN'}</span>
          <h1 id="home-title">{fa?'تجارت و لوجستیک،':'Trade & logistics.'}<br/><em>{fa?'متناسب با نیاز شما.':'Built around your needs.'}</em></h1>
          <p>{fa?'خان بوستان یک شرکت تجارتی و لوجستیکی در مزارشریف است؛ برای تاجران، عمده‌فروشان، کارخانه‌ها و شرکت‌ها، محصولات اصلی، تأمین سفارشی و خدمات انتقال و تحویل ارائه می‌کند.':'Khan Bostan is a trading and logistics company in Mazar-e-Sharif, serving traders, wholesalers, factories and businesses with main products, custom sourcing and logistics.'}</p>
          <div className="kb-actions"><PrimaryLink to="/products" variant="gold">{fa?'مرور محصولات':'Explore products'}<ArrowIcon/></PrimaryLink><Link className="kb-text-link kb-light-link" to="/contact">{fa?'شروع گفتگو':'Let’s talk'}<ArrowIcon/></Link></div>
        </div>
        <aside className="kb-hero-note"><span className="kb-note-label">{fa?'مسیر همکاری':'YOUR NEXT STEP'}</span><h2>{fa?'از یک درخواست روشن شروع کنیم.':'Start with a clear enquiry.'}</h2><p>{fa?'کالا، مقدار و مقصد را با ما شریک کنید.':'Share your goods, quantity and destination.'}</p><Link to="/contact?kind=product">{fa?'درخواست معلومات و قیمت':'Enquire about products'}<ArrowIcon/></Link></aside>
      </div>
      <div className="kb-hero-bottom"><div className="kb-wrap"><span>{fa?'واردات و صادرات':'IMPORT & EXPORT'}</span><span>{fa?'تأمین کالا':'PRODUCT SOURCING'}</span><span>{fa?'خدمات لوجستیکی':'LOGISTICS SERVICES'}</span></div></div>
    </section>

    <section className="kb-section" aria-labelledby="service-title"><div className="kb-wrap">
      <div className="kb-section-heading"><div><span className="kb-kicker">{fa?'فعالیت‌های ما':'WHAT WE DO'}</span><h2 id="service-title">{fa?'کدام همکاری را نیاز دارید؟':'What do you need help with?'}</h2></div><Link className="kb-text-link" to="/activities">{fa?'تمام فعالیت‌ها':'All trade activities'}<ArrowIcon/></Link></div>
      <div className="kb-home-paths">{services.map((item,index)=><Link className="kb-service-card" to={item.to} key={item.key}><img src={item.image} alt="" loading="lazy"/><div className="kb-service-copy"><span className="kb-service-number">{new Intl.NumberFormat(fa?'fa-AF':'en',{minimumIntegerDigits:2}).format(index+1)}</span><h3>{item.title}</h3><p>{item.copy}</p><span className="kb-text-link">{fa?'جزئیات همکاری':'Explore this service'}<ArrowIcon/></span></div></Link>)}</div>
    </div></section>

    <section className="kb-about-band" aria-labelledby="company-title"><div className="kb-wrap kb-about-layout"><div className="kb-about-picture"><img src="/images/about-office.webp" alt={fa?'فضای دفتر':'Office interior'} loading="lazy"/><div className="kb-picture-caption"><img src="/brand/khan-boostan-official.png" alt=""/><span>{fa?'خان بوستان':'Khan Bostan'}<small>{fa?'تجارت جهانی | آینده بهتر':'Global Trade | Better Future'}</small></span></div></div><div className="kb-about-copy"><span className="kb-kicker">{fa?'دربارهٔ خان بوستان':'ABOUT KHAN BOSTAN'}</span><h2 id="company-title">{fa?'همکاری روشن، از نخستین گفتگو.':'Clarity, from the first conversation.'}</h2><p>{L(company.summary,fa?'خان بوستان در حوزهٔ واردات و صادرات فعالیت می‌کند.':'Khan Bostan works in import and export.')}</p><ul className="kb-value-list">{(fa?['شناخت نیاز مشتری','گفتگوی روشن دربارهٔ شرایط','پیگیری مراحل همکاری']:['Understand the client’s needs','Discuss terms clearly','Follow each stage of cooperation']).map(text=><li key={text}><span aria-hidden="true">✓</span>{text}</li>)}</ul><PrimaryLink to="/about">{fa?'بیشتر دربارهٔ شرکت':'Discover our company'}<ArrowIcon/></PrimaryLink></div></div></section>

    {sections.showProducts !== false && <HomeCategories categories={categories} products={products} L={L} fa={fa} lang={lang}/>}

    <section className="kb-process-band" aria-labelledby="process-title"><div className="kb-wrap"><div className="kb-section-heading"><div><span className="kb-kicker kb-kicker-light">{fa?'مراحل همکاری':'HOW WE WORK'}</span><h2 id="process-title">{fa?'از درخواست تا تحویل.':'From enquiry to delivery.'}</h2></div><Link className="kb-text-link kb-light-link" to="/process">{fa?'شناخت مراحل':'See the process'}<ArrowIcon/></Link></div><ol className="kb-process-grid">{steps.map(([title,copy],index)=><li key={title}><span>{new Intl.NumberFormat(fa?'fa-AF':'en',{minimumIntegerDigits:2}).format(index+1)}</span><h3>{title}</h3><p>{copy}</p></li>)}</ol></div></section>
    {sections.showNews !== false && <HomeNews featuredStory={featured} recentStories={stories.filter(item=>item.id!==featured?.id).slice(0,2)} cases={[]} lang={lang} fa={fa} L={L} t={t}/>}
    <section className="kb-section"><div className="kb-wrap"><h2>{fa?'برای گفتگو آماده‌ایم':'Start a conversation'}</h2><p>{fa?'برای استعلام محصول، تأمین سفارشی یا لوجستیک، از واتساپ و ایمیل شروع کنید.':'Start by WhatsApp or email for product, sourcing or logistics enquiries.'}</p><ContactActions/></div></section><HomeContact contact={settings.contact ?? {}} lang={lang} t={t} L={L}/>
  </main>
}
