import { useState } from 'react'
import { useContent, bySort } from '../../src/lib/store.jsx'
import { usePublicDict, publicRecords } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import CallToAction from '../components/public/CallToAction.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import Lightbox from '../components/Lightbox.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'
import SectionHeading from '../components/SectionHeading.jsx'

const albumKey = (value) => typeof value === 'string' ? value : (value?.fa || value?.en || '')

export default function Gallery() {
  const { data, settings } = useContent()
  const { t, L, lang } = usePublicDict()
  const fa = lang !== 'en'
  const [album, setAlbum] = useState('all')
  const [lb, setLb] = useState(null)
  if (!data) return <PublicLoading />
  const all = [...publicRecords(data.gallery ?? [])].sort(bySort)
  // Keep the selected album independent of the display language.
  const albums = [...new Map(all.map((item) => item.album).filter(Boolean).map((value) => [albumKey(value), value])).values()]
  const photos = all.filter((item) => !item.video && (album === 'all' || albumKey(item.album) === album))
  const videos = settings.sections?.showGallery === false ? [] : all.filter((item) => item.video && (album === 'all' || albumKey(item.album) === album))
  const openPhoto = (index) => setLb({ items: photos.map((item) => ({ image: item.image, caption: item.caption })), index })
  const openVideo = (index) => setLb({ items: videos.map((item) => ({ video: item.video, poster: item.poster || item.image, image: item.image, caption: item.caption })), index })

  return <>
    <main id="main" className="tw-flex-1"><Hero image="/images/gallery-office.webp" crumbs={[[null, t('nav_news')], [null, t('nav_gallery')]]} title={lang === 'fa' ? 'گالری عکس و ویدیو' : 'Photo & video gallery'} sub={t('gallery_d')} />
      <section className="tw-bg-kb-paper tw-py-7 sm:tw-py-10"><SiteContainer>
        {albums.length > 1 && <div className="tw-mt-0 tw-grid tw-gap-2 sm:tw-grid-cols-[auto_minmax(0,1fr)] sm:tw-items-center"><span className="tw-flex tw-items-center tw-justify-between tw-gap-3 tw-text-xs tw-font-bold tw-text-kb-muted">{t('albums')}:<small className="tw-text-[10px] tw-font-normal tw-text-kb-muted sm:tw-hidden">{fa ? 'برای دیدن همه، افقی بکشید' : 'Swipe to see all albums'}</small></span><div className="tw-min-w-0 tw-overflow-x-auto tw-pb-2 sm:tw-overflow-visible" tabIndex={0} role="group" aria-label={lang === 'fa' ? 'فیلتر آلبوم؛ برای دیدن همهٔ گزینه‌ها افقی پیمایش کنید' : 'Filter by album; scroll horizontally to see all options'}><div className="tw-flex tw-w-max tw-gap-2 sm:tw-w-full sm:tw-flex-wrap"><button type="button" className={`tw-min-h-9 tw-shrink-0 tw-rounded-full tw-border tw-px-4 tw-text-xs tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${album === 'all' ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-line tw-bg-white tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`} aria-pressed={album === 'all'} onClick={() => setAlbum('all')}>{t('all')}</button>{albums.map((value) => <button type="button" className={`tw-min-h-9 tw-shrink-0 tw-rounded-full tw-border tw-px-4 tw-text-xs tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${album === albumKey(value) ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-line tw-bg-white tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`} aria-pressed={album === albumKey(value)} onClick={() => setAlbum(albumKey(value))} key={albumKey(value)}>{L(value)}</button>)}</div></div></div>}
        {photos.length > 0 && <div className="tw-mt-7 tw-grid tw-grid-cols-2 tw-items-start tw-gap-3 md:tw-grid-cols-3 lg:tw-grid-cols-4">{photos.map((item, index) => <figure className="tw-min-w-0 tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white" key={item.id ?? index}><button className="tw-group tw-relative tw-block tw-aspect-[4/3] tw-w-full tw-overflow-hidden tw-bg-kb-navy tw-p-0 tw-text-start focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" type="button" onClick={() => openPhoto(index)}><span className="tw-sr-only">{fa ? 'نمایش تصویر' : 'View image'}{item.caption ? `: ${L(item.caption)}` : ''}</span><img src={item.image} alt="" loading="lazy" className="tw-h-full tw-w-full tw-object-cover tw-transition-transform group-hover:tw-scale-[1.04] motion-reduce:tw-transition-none motion-reduce:group-hover:tw-scale-100" /><span className="tw-absolute tw-end-2 tw-top-2 tw-max-w-[80%] tw-whitespace-normal tw-break-words tw-rounded-kb tw-bg-kb-navy/80 tw-px-2.5 tw-py-1 tw-text-start tw-text-[10px] tw-font-bold tw-leading-5 tw-text-white">{L(item.album)}</span></button>{item.caption && <figcaption className="tw-min-h-14 tw-p-3 tw-text-xs tw-leading-5 tw-text-kb-body">{L(item.caption)}</figcaption>}</figure>)}</div>}
        {videos.length > 0 && settings.sections?.showGallery !== false && <div id="videos" className="tw-mt-14 tw-scroll-mt-28"><SectionHeading eyebrow={t('nav_videos')} title={t('nav_videos')} /><div className="tw-grid tw-gap-4 sm:tw-grid-cols-2 lg:tw-grid-cols-3">{videos.map((item, index) => <figure className="tw-min-w-0 tw-overflow-hidden tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white" key={item.id ?? index}><button className="tw-group tw-relative tw-block tw-aspect-video tw-w-full tw-overflow-hidden tw-bg-kb-navy tw-p-0 tw-text-start focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" type="button" onClick={() => openVideo(index)} aria-label={`${fa ? 'نمایش ویدیو' : 'View video'}${item.caption ? `: ${L(item.caption)}` : ''}`}><img src={item.poster || item.image} alt="" loading="lazy" className="tw-h-full tw-w-full tw-object-cover tw-opacity-85 tw-transition-opacity group-hover:tw-opacity-100 motion-reduce:tw-transition-none" /><span className="tw-absolute tw-inset-0 tw-grid tw-place-items-center"><span className="tw-grid tw-h-14 tw-w-14 tw-place-items-center tw-rounded-full tw-bg-kb-navy/80 tw-text-white tw-backdrop-blur-sm"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.14v13.72a1 1 0 0 0 1.5.86l11-6.86a1 1 0 0 0 0-1.72l-11-6.86a1 1 0 0 0-1.5.86z" /></svg></span></span></button>{item.caption && <figcaption className="tw-whitespace-pre-line tw-break-words tw-p-3 tw-text-xs tw-leading-5 tw-text-kb-body">{L(item.caption)}</figcaption>}</figure>)}</div></div>}
      </SiteContainer></section>
      <CallToAction />
    </main>
    {lb && <Lightbox items={lb.items} index={lb.index} setIndex={(next) => setLb((current) => ({ ...current, index: typeof next === 'function' ? next(current.index) : next }))} close={() => setLb(null)} />}
  </>
}
