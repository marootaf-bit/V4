# Website imagery

## Newly generated assets
Generated with the built-in image generation tool for this project on 2026-10-30. These are illustrative commercial images, not evidence of company inventory, premises or completed projects. Originals are included locally; no remote hotlinks are needed.

- src/public/photography/cotton-export.png — used on home, product listing/detail and the illustrative cotton project.
- src/public/photography/tyre-import.png — used on home, product listing/detail and the illustrative tyre project.

Cotton prompt:
Create a photorealistic commercial cotton export product photograph, landscape 3:2. Close foreground of clean white raw cotton fibers protruding naturally from one compressed cotton bale secured with muted steel bands, several neat cotton bales in an airy industrial warehouse softly out of focus behind. Natural warm side light, authentic fine fiber textures, refined navy and warm neutral color palette, documentary quality, realistic perspective. No people, no text, no logos, no watermarks. This is an illustrative website asset for a trading company, not an actual facility photograph.

Tyre prompt:
Photorealistic premium commercial product photograph of three new heavy duty truck tyres standing upright, one slightly turned showing deep realistic tread, in foreground of a clean spacious tyre distribution warehouse. Landscape 3:2 composition, charcoal black rubber, accurate circular forms and tread construction, soft daylight from warehouse windows, subtle blue steel shelving in background, realistic industrial documentary photography. No people, no legible text, no labels, no brands, no logos, no watermark. Illustrative asset for a trading company website, not a claim of actual inventory.

## Retained assets
Images under deploy/images are retained from the user-provided project, including transport, warehouse, paperwork and the additional demo product photographs. Existing provenance is in deploy/images/SOURCES.md where provided; this revision does not independently establish third-party licensing of legacy assets. The company logo is retained from the user-provided brand image. Font license files are retained where supplied.

## Search decision
Cotton and tyre image searches returned corporate supplier and publication imagery without a clear redistribution license in the retrieved information. Those search results were not downloaded or incorporated. The two generated photographs above replace the earlier symbolic SVG product illustrations.
