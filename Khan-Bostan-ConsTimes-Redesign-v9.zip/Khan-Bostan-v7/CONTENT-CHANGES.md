# Demo content and replacement guide

- Cotton exports and tyre imports follow the supplied business brief; their photographs are generated illustrative images.
- Six extra products are demo records: dried fruit, saffron, rice, cooking oil, cement and fabric. They are marked demo: true.
- Six project scenarios are explicitly illustrative, not real completed-project claims; each has a working detail route and demo: true.
- Three evergreen cooperation guides remain available as articles.
- The small header notice identifies the design as a preview with sample content.
- All product and project content is in src/lib/demo-content.json; service text is in src/content/business.json.
- Replace company contact settings before deployment. Masked phone numbers are deliberately not turned into live WhatsApp links.
- Contact form prepares an email draft; it does not have a sending backend. This deliverable is a React design revision, not a Laravel/SQLite implementation.
- The existing /admin area is a read-only preview, not a production CMS.
