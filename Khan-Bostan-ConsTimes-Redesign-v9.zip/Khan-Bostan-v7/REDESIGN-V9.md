# ConsTimes adaptation — Khan Bostan

The supplied ConsTimes template informed the site-wide palette, compact square-cornered shapes, dark charcoal/teal surfaces, warm amber accent, clear top contact strip, and restrained section styling. Khan Bostan keeps the existing 18-page React information architecture, custom sourcing/trade/logistics content, bilingual navigation and page-specific layouts, adapted to the template direction.

Real Unsplash photographs replace the generated home banner, cotton and tyre assets. These depict general industrial contexts rather than verified company facilities or goods. Attribution/licence notes are in ASSETS.md. Remaining sample editorial/product imagery is clearly demo material and can be swapped with company-approved photos.
