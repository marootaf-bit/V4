# SITE-MAP.md — ساختار منو و مسیرها

هشت بخش اصلی (طبق الزام بریف) با زیرمنوها؛ همه با دسترسی کیبورد و لمس.

| بخش | مسیر | فرزندان |
|---|---|---|
| خانه | `/` | — |
| دربارهٔ شرکت | `/about` | بازارهای فعالیت `/markets` · روابط تجارتی `/partners` |
| محصولات | `/products` | — (جزئیات: `/products/:id` — ۸ کالا) |
| خدمات تجارتی | `/activities` | تأمین سفارشی `/sourcing` · واردات `/import` · صادرات `/export` · تجارت داخلی `/domestic-trade` |
| خدمات لوجستیکی | `/logistics` | مراحل همکاری `/process` |
| پروژه‌ها | `/projects` | — (جزئیات: `/projects/:id` — ۶ پروژه) |
| اخبار و رسانه‌ها | `/news` | گالری `/news?view=gallery` · دانلودها `/downloads` |
| تماس و درخواست | `/contact` | — |

صفحات تکمیلی: مقالهٔ خبری `/news/:id` (۶ مطلب) · حریم خصوصی `/privacy` · شرایط استفاده `/terms` · 404.

## مسیرهای فرم درخواست

فرم تماس یک صفحه با ۶ نوع درخواست است که از پارامتر query انتخاب می‌شود:
`?kind=` `contact` (عمومی) · `product` (محصول) · `sourcing` (تأمین) · `logistics` (لوجستیک) · `cooperation` (روابط تجارتی) · `consultation` (مشاوره).
همراه با `&subject=` و `&productName=` برای پیش‌پر کردن (مثلاً از دکمهٔ «برای دریافت پیشنهاد» در صفحهٔ هر محصول).

## نقشهٔ داده

- `src/lib/demo-content.json` — settings, products(8), news(6), projects(6), team(4), partners(4), gallery(12), documents(3), faq(8), …
- `src/content/business.json` — محتوای ۸ صفحهٔ خدمت (activities, sourcing, import, export, domestic-trade, logistics, markets, process)؛ هرکدام cards/steps/details و ۴ پرسش متداول.
- `src/content/navigation.js` — منو (منبع `npm run check`).
