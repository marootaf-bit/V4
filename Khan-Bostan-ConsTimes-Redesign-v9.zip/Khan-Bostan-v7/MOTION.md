# MOTION.md — سیستم انیمیشن خان بوستان v5

سند پیاده‌سازی حرکت (Motion) طبق نقشهٔ ۲۵بندی بریف چهارم. همهٔ مقدارها از توکن‌های مرکزی در `src/redesign.css` خوانده می‌شوند؛ هیچ کتابخانهٔ جدیدی اضافه نشده است.

## معماری مشترک

| قطعه | فایل | نقش |
|---|---|---|
| `Reveal` | `src/lib/motion.jsx` | تنها مکانیزم ورود محتوا (IntersectionObserver، آستانهٔ ۵٪). یک‌بار در هر ورود صفحه اجرا می‌شود؛ کلید `pathname#rkey\|id\|className` در `Map` ماژول ذخیره می‌شود → با Back درون SPA، بخش‌ها بدون اجرای دوبارهٔ آبشار، فوراً نمایان می‌شوند. Observer پس از fire و در unmount قطع می‌شود (سازگار با StrictMode). |
| `useScrolled(64)` | `src/lib/motion.jsx` | فقط سایهٔ هدر بعد از ۶۴px (ارتفاع هدر ثابت می‌ماند). |
| `Accordion` | `src/components/public/Accordion.jsx` | آکاردئون مشترک با ارتفاع اندازه‌گیری‌شده (`scrollHeight` + rAF دوبل)، `aria-expanded/controls`، چرخش «+» به «×» با `rotate(45deg)`، پنلِ بسته `visibility:hidden` (غیرقابل فوکوس)، در reduced-motion آنی. |
| `Lightbox` | `src/components/public/Lightbox.jsx` | لایت‌باکس مشترک: Escape، فلش‌های جهت‌دار RTL-aware، تلهٔ Tab، قفل اسکرول، فوکوس روی دکمهٔ بستن، فقط هنگام باز mount می‌شود (بسته = کاملاً از DOM خارج). |
| توکن‌ها | `src/redesign.css` | `--t-fast:150ms` `--t-open:240ms` `--t-menu:260ms` `--t-enter:450ms` — `--ease: cubic-bezier(0.22,1,0.36,1)`. |
| کلاس‌های پایه | `src/redesign.css` | `.kb-reveal` (+ `kb-r-sm` ۱۲px / `kb-r-side` ۱۸px از سمت مقابل)، `.kb-stagger>li` با `--i×--stagger`، `.kb-cell` (wrapper جداکنندهٔ transform ورود از hover)، `.kb-swap` (fade ۱۵۰ms نتیجهٔ فیلتر). |

**قواعد پایه:** ورود فقط `transform/opacity` (۱۲–۲۰px، موبایل ≤۱۰px)؛ پاراگراف‌های یک بخش با هم؛ stagger ≤۲۴۰ms؛ بدون CLS (قاب‌ها ثابت)؛ فاصله‌ها RTL/LTR-aware با `translate` مقید به جهت؛ متن بلند/جدول/فوتر دسکتاپ بدون reveal؛ hover روی wrapper جدا (`kb-cell`) تا transform ورود را بازنویسی نکند.

**Fallback بدون JS:** حالت «مخفی تا reveal» فقط با `html.kb-motion-ok` فعال است؛ این کلاس فقط وقتی JS و IntersectionObserver موجود باشند روی `<html>` گذاشته می‌شود → بدون JS همهٔ محتوا فوراً نمایان است.

**Reduced motion:** بلوک کامل `prefers-reduced-motion: reduce` همهٔ reveal/transition/animationها را خنثی و محتوا را کاملاً نمایان می‌کند؛ آکاردئون/منو آنی باز و بسته می‌شوند.

## جدول بخش‌ها (۲۵بندی)

| # | بخش | فایل(ها) | افکت ورود | مدت/Delay | Trigger | موبایل | Reduced-motion |
|---|---|---|---|---|---|---|---|
| ۱ | هدر | shell/Header.jsx + redesign.css | فقط سایه بعد از ۶۴px (`is-scrolled`)؛ ارتفاع ثابت، بدون پنهان‌شدن | 180ms | scroll | همان | بدون سایهٔ تدریجی (آنی) |
| ۲ | Dropdown دسکتاپ | shell/Header.jsx + redesign.css | opacity+translateY(6px)؛ ورود 180ms / خروج 140ms؛ بسته = `visibility:hidden` (خارج از Tab) | 180/140ms | hover/focus/کلیک | — | آنی |
| ۳ | منوی موبایل | shell/Header.jsx + redesign.css | پنل از سمت شروعِ زبان (RTL راست / LTR چپ)، backdrop fade؛ حالت `closing` 260ms؛ تلهٔ فوکوس + قفل اسکرول + Escape + بازگشت فوکوس به دکمه | 260ms (backdrop 180ms) | دکمهٔ همبرگر | بله | آنی |
| ۴ | هیرو | reference-design.css | عنوان/عکس بدون انیمیشن (فوری، منتظر JS نمی‌ماند)؛ خلاصه/دکمه‌ها/نوار پایین ≤10px/350ms با delay 40/90/140ms؛ KBTC ثابت | ≤350ms (کل ≤500ms) | لود صفحه | همان | همه فوری |
| ۵ | کارت‌های مسیر (خانه) | pages/Home.jsx | fade-up 16px، stagger 70ms؛ hover فقط translateY ≤4px/180ms (روی `kb-cell`) — بدون چرخش | 420ms | ورود در دید | ≤10px | نمایان |
| ۶ | Intro | pages/Home.jsx | متن گروهی 12px (sm)؛ موزاییک تصویر از سمت مقابل 18px (side) | 450ms | ورود در دید | فقط fade-up کوتاه | نمایان |
| ۷ | محصولات (خانه) | pages/Home.jsx | stagger 80ms؛ hover تصویر scale 1.025/280ms؛ دکمه 150ms | 420ms | ورود در دید | همان | نمایان |
| ۸ | Callout تأمین سفارشی | pages/Home.jsx | fade-up با delay 160ms | 420ms | ورود در دید | همان | نمایان |
| ۹ | کشورها | components/public/MarketsCountries.jsx | هاب 12px آرام؛ ۶ کارت stagger 50ms (سقف 250ms)؛ hover فقط border/background — بدون پرچم متحرک | 450ms/50ms | ورود در دید | همان | نمایان |
| ۱۰ | مسیرهای تیره (market) | pages/Home.jsx + reference-design.css | متن گروهی 12px؛ ۳ مسیر fade-up ≤10px stagger 60ms؛ hover فقط رنگ h3/↗ به طلایی — بدون پارالاکس | 400ms/60ms | ورود در دید | همان | نمایان |
| ۱۱ | مراحل (خانه) | pages/Home.jsx + reference-design.css | خط اتصال `scaleX(0→1)` 600ms (origin مطابق dir) + li stagger 80ms — بدون bounce/شمارش | 450ms/80ms | ورود در دید | فقط fade-up کوتاه؛ خط در گرید ۱×۴ حذف | نمایان + خط آنی |
| ۱۲ | مخاطبان | pages/Home.jsx | یک fade-up گروهی 12px (بدون stagger تک‌کارت) | 450ms | ورود در دید | همان | نمایان |
| ۱۳ | پروژه‌های خانه | pages/Home.jsx | stagger 70ms؛ hover تصویر scale 1.025 + border؛ حفظ اندازهٔ فشرده — بدون اسلایدر | 450ms/70ms | ورود در دید | همان | نمایان |
| ۱۴ | FAQ (همهٔ صفحات) | components/public/Accordion.jsx | باز 220–260ms (ارتفاع اندازه‌گیری‌شده)؛ «+» چرخش 45°؛ `aria-expanded`؛ بدون `max-height` قطع‌کننده | 240ms | کلیک/کیبورد | همان | آنی |
| ۱۵ | تماس/دکمه‌ها | Home.jsx + redesign.css | fade-up یکبار (sm)؛ hover رنگ 150ms؛ `active scale(.98)`؛ بدون تپش؛ spinner فقط برای عملیات واقعی (ایمیل) | 450ms/150ms | ورود/تعامل | همان | نمایان |
| ۱۶ | دربارهٔ ما — هیرو | pages/About.jsx | فوری (مثل هیروی خانه) | — | لود | همان | — |
| ۱۷ | ریل دربارهٔ ما | pages/About.jsx + editorial.css | لینک فعال طلایی (150ms)؛ موبایل: آکاردئون جمع‌شونده 220ms | 150/220ms | scroll-spy/کلیک | آکاردئون | آنی |
| ۱۸ | تاریخچه/مدیریت/تیم/… | pages/About.jsx | timeline stagger 70ms (kb-stagger)؛ مدیریت گروهی 450ms (بدون افکت تایپ)؛ تیم stagger 60ms (بدون زوم چهره)؛ مأموریت/چشم‌انداز با هم — بدون flip | 450ms/60–70ms | ورود در دید | ≤10px | نمایان |
| ۱۹ | حوزه‌ها | pages/About.jsx + editorial.css | hover فقط translateY ≤3px + border (بدون سایهٔ اضافی) | 180ms | hover | بدون hover لمسی | — |
| ۲۰ | خدمات (BusinessPage) | pages/BusinessPage.jsx | ردیف‌ها fade-up 12px stagger 60ms؛ مراحل/FAQ از مکانیزم مشترک؛ پنل معلومات بدون شناوری | 450ms/60ms | ورود در دید | همان | نمایان |
| ۲۱ | جستجو/فیلتر | pages/Products.jsx + redesign.css | نتیجه با `kb-swap` fade 150ms؛ **کلید swap با debounce 220ms** تا تایپ فلیکر ندهد؛ شمارش فوری؛ بدون spinner/تأخیر مصنوعی | 150ms | فیلتر/تایپ | همان | آنی |
| ۲۲ | گالری محصول | pages/ProductDetail.jsx + editorial.css | تصویر اصلی فوری؛ تعویض thumbnail با crossfade 180ms در قاب ثابت 4:3 (بدون CLS)؛ thumbnail فعال حاشیهٔ واضح؛ Lightbox 180ms (scale .98→1) با Escape/فوکوس/قفل اسکرول | 180ms | کلیک/کیبورد | همان | آنی |
| ۲۳ | گالری عمومی | pages/Gallery.jsx | همان گالری مشترک + Lightbox | 180ms | کلیک/کیبورد | همان | آنی |
| ۲۴ | فرم‌ها | components/public/ContactForm.jsx + redesign.css | focus 150ms (حلقه/رنگ)؛ خطا fade (بدون لرزش)؛ فیلدهای وابسته با key + `kb-field-anim` 180ms (داده حفظ می‌شود)؛ mailto ≠ موفقیت | 150–180ms | تعامل | همان | آنی |
| ۲۵ | فوتر | shell/Footer.jsx + editorial.css | دسکتاپ: بدون انیمیشن ورود؛ موبایل: ۲ آکاردئون 220ms (بخش‌ها/منابع)، برند و تماس همیشه نمایان | 220ms | کلیک | آکاردئون | آنی |

## روش تست

- `qa/verify5.mjs` — ۲۹ چک خودکار (Playwright): کنتراست گرادیان‌آگاه، ورود/یک‌بار‌بودن/Back، reduced-motion (emulateMedia)، منو/آکاردئون/لایت‌باکس با کیبورد، فیلتر+debounce، بدون سرریز افقی در 390/768/1440 × fa/en × ۱۱ صفحه، بدون خطای کنسول. **نتیجه: ۲۹/۲۹ PASS.**
- ویدئوهای ضبط‌شدهٔ مرورگر (شواهد حرکت): `motion-videos/1-home-desktop-1440.webm` (ورود+اسکرول+FAQ)، `2-home-mobile-390.webm` (فیلتر+منو)، `3-about-mobile-390.webm` (ریل+اسکرول).

## محدودیت‌ها

- تصاویر «معرفی — نمایشی» هستند و مستند شرکت نیستند (نشان دیمو سراسری).
- در بارگذاری کامل صفحه (refresh/ورود مستقیم)، انیمیشن ورود طبق تعریف «یک‌بار در هر ورود صفحه» دوباره اجرا می‌شود؛ حالت «بدون اجرای دوباره» فقط برای Back درون SPA است (تست B6).
- منوی موبایل با انیمیشن خروجِ ۲۶۰ms بسته می‌شود؛ در reduced-motion بسته‌شدن آنی است.
