# Version 7 validation

- Architecture: eight primary navigation sections and eighteen fixed pages passed.
- Production build: passed; local fonts and background assets copied from deploy are available at runtime.
- Server-render validation: 78 route/language combinations passed, with no missing referenced media or unresolved checked internal links.
- Two PDF files: seven pages rasterized and visually inspected; Dari shaping corrected.
- Browser preview service unavailable. Desktop/mobile rendering, menu behaviour, animation timing and interactive controls require browser verification. Server rendering is not an interaction test.
- Source ZIP excludes dependencies, build outputs, generated CSS and temporary QA scripts.
