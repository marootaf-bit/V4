# Website imagery

## Newly generated assets
Generated with the built-in image generation tool for this project on 2026-10-30. These are illustrative commercial images, not evidence of company inventory, premises or completed projects. Originals are included locally; no remote hotlinks are needed.

- src/public/photography/cotton-export.webp — used on home, product listing/detail and the illustrative cotton project. (2079KB PNG → 113KB WebP, q82, ≤1600px)
- src/public/photography/tyre-import.webp — used on home, product listing/detail and the illustrative tyre project. (2505KB PNG → 182KB WebP, q82, ≤1600px)

Cotton prompt:
Create a photorealistic commercial cotton export product photograph, landscape 3:2. Close foreground of clean white raw cotton fibers protruding naturally from one compressed cotton bale secured with muted steel bands, several neat cotton bales in an airy industrial warehouse softly out of focus behind. Natural warm side light, authentic fine fiber textures, refined navy and warm neutral color palette, documentary quality, realistic perspective. No people, no text, no logos, no watermarks. This is an illustrative website asset for a trading company, not an actual facility photograph.

Tyre prompt:
Photorealistic premium commercial product photograph of three new heavy duty truck tyres standing upright, one slightly turned showing deep realistic tread, in foreground of a clean spacious tyre distribution warehouse. Landscape 3:2 composition, charcoal black rubber, accurate circular forms and tread construction, soft daylight from warehouse windows, subtle blue steel shelving in background, realistic industrial documentary photography. No people, no legible text, no labels, no brands, no logos, no watermark. Illustrative asset for a trading company website, not a claim of actual inventory.

## Retained assets
Images under deploy/images are retained from the user-provided project, including transport, warehouse, paperwork and the additional demo product photographs. Existing provenance is in deploy/images/SOURCES.md where provided; this revision does not independently establish third-party licensing of legacy assets. The company logo is retained from the user-provided brand image. Font license files are retained where supplied.

## Search decision
Cotton and tyre image searches returned corporate supplier and publication imagery without a clear redistribution license in the retrieved information. Those search results were not downloaded or incorporated. The two generated photographs above replace the earlier symbolic SVG product illustrations.


## Documents (this revision)

- src/public/docs/enquiry-checklist.txt — real checklist, Dari text (kept).
- src/public/docs/company-profile-demo.pdf — 2-page bilingual demo profile, generated from demo-content data (80KB).
- src/public/docs/products-catalogue-demo.pdf — 5-page demo catalogue of the 8 catalogue items, product photos embedded (290KB).

## Team avatars

Image generation was unavailable this session; team members use monogram avatars (initials in a gold-ring circle over the navy/blue panel) rendered in CSS. Real photos replace them after approval.

## Optimization note

All photography is WebP. The two hero photographs were re-compressed from PNG (~4.6MB total) to ~295KB total with no visible quality loss at display sizes.


## Recovered from the previous site package (this revision)

Copied read-only from Khan-Bostan-Structured-React-Source.zip (user's repo github.com/marootaf-bit/V4), provenance per its deploy/images/SOURCES.md:

- deploy/images/about-office.webp (+ -md, -sm) — AI-generated illustrative workspace (2026-10, per previous SOURCES.md), used on the home intro mosaic and the About story section.
- deploy/images/team/team-1..7.jpg — placeholder member photos from the previous package; team-1..4 currently used as demo avatars (replaced by real photos after approval).
- deploy/images/project-construction.webp, project-grocery.webp — illustrative project scenes for the construction and domestic-supply demo projects.
- deploy/images/news-exhibition.webp — copied for future use (currently unreferenced).

## Version 7 document previews
Images under src/public/document-previews are first-page rasterizations of the two locally bundled demo PDFs. The PDFs were regenerated with local Noto Arabic font shaping and existing illustrative product imagery. They are not screenshots of company-issued documents.

## Real stock photography update
Generated cotton, tyre and hero photos were replaced by real photographs from Unsplash: textile bales by SIL Group (credit requested at https://silgroup.co.uk/), tyre warehouse by Iggy Love, cargo port by PortCalls Asia, and warehouse bags by Zemos. These show general industry scenes and do not represent Khan Bostan premises, stock, or shipments. Sources are free to use under the Unsplash License.

## ConsTimes / real photography
The repo's ConsTimes RTL template is the visual reference (charcoal #15222c, teal #213438, amber #d38e25, compact squared controls). Photo files in `src/public/photos-stock` are real Unsplash photographs: textile bales by SIL Group (please credit silgroup.co.uk), warehouse sacks by Zemos, warehouse tires by Iggy Love, and port cargo by PortCalls Asia. Available under Unsplash License. General reference only; not Khan Bostan inventory, premises, people, or shipments.
