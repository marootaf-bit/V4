import { useEffect, useRef, useState, useId } from 'react'
import { useReducedMotion } from '../../lib/motion.jsx'

/* Shared accordion — FAQ blocks, footer/mobile groups, about rail.
   Open/close: 240ms height (measured, never a guessed max-height),
   content fades in ~150ms. Native <button> keeps keyboard access;
   aria-expanded + aria-controls wire the region. Focus stays on the
   button (never moved). prefers-reduced-motion → instant. */
export default function Accordion({ title, children, defaultOpen = false, className = '', titleClassName = '', tag: Tag = 'div', id }) {
  const [open, setOpen] = useState(defaultOpen)
  const [height, setHeight] = useState(open ? null : 0) // null = auto
  const box = useRef(null), timer = useRef(0)
  const reduced = useReducedMotion()
  const generatedId = useId()
  const uid = useRef(id || `acc-${generatedId}`)

  useEffect(() => () => clearTimeout(timer.current), [])

  const toggle = () => {
    if (reduced) { setOpen(o => !o); setHeight(null); return }
    clearTimeout(timer.current)
    if (!open) {
      const h = box.current ? box.current.scrollHeight : 0
      setHeight(0)
      requestAnimationFrame(() => requestAnimationFrame(() => setHeight(h)))
      timer.current = setTimeout(() => setHeight(null), 260)
      setOpen(true)
    } else {
      const h = box.current ? box.current.scrollHeight : 0
      setHeight(h)
      requestAnimationFrame(() => requestAnimationFrame(() => setHeight(0)))
      setOpen(false)
    }
  }

  return <Tag className={`kb-acc ${open ? 'is-open' : ''} ${className}`}>
    <button type="button" className={`kb-acc-btn ${titleClassName}`} aria-expanded={open} aria-controls={uid.current + '-p'} onClick={toggle}>
      <span>{title}</span><span className="kb-acc-x" aria-hidden="true">+</span>
    </button>
    <div className="kb-acc-panel" id={uid.current + '-p'} role="region" ref={box}
      style={{ height: open && height === null ? 'auto' : height }}
      aria-hidden={!open} inert={!open ? '' : undefined}>
      <div className="kb-acc-in">{children}</div>
    </div>
  </Tag>
}
