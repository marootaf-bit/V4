import { useEffect, useRef } from 'react'
import { usePublicDict } from '../../lib.jsx'

/* Shared lightbox — product gallery, projects gallery, media gallery.
   Opens with opacity + scale(.98→1) over 180ms; closes on Escape /
   close button / backdrop; arrow keys navigate (RTL-aware); Tab is
   trapped across [close, prev, next]; body scroll is locked and restored;
   unmounted while closed so hidden controls are never tabbable. */
export default function Lightbox({ items, index, onIndex, onClose }) {
  const { lang, L } = usePublicDict()
  const fa = lang !== 'en'
  const s = (a, b) => (fa ? a : b)
  const box = useRef(null), closeBtn = useRef(null)
  const item = items[index]
  const isOpen = Boolean(item)
  useEffect(() => {
    if (!isOpen) return
    const previous = document.activeElement
    return () => { if (previous instanceof HTMLElement && previous.isConnected) previous.focus() }
  }, [isOpen])

  useEffect(() => {
    if (!item) return
    const onKey = (e) => {
      if (e.key === 'Escape') onClose()
      else if (e.key === 'ArrowLeft') onIndex((index + (fa ? 1 : -1) + items.length) % items.length)
      else if (e.key === 'ArrowRight') onIndex((index + (fa ? -1 : 1) + items.length) % items.length)
      else if (e.key === 'Tab') {
        const f = [...box.current.querySelectorAll('button')]
        const first = f[0], last = f.at(-1)
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus() }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus() }
      }
    }
    document.addEventListener('keydown', onKey)
    closeBtn.current?.focus()
    const old = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = old }
  }, [index, item, items.length, fa, onClose, onIndex])

  if (!item) return null
  return <div className="kb-lightbox" ref={box} role="dialog" aria-modal="true" aria-label={item.label || s('نمایش تصویر', 'Image viewer')} onClick={e => { if (e.target === e.currentTarget) onClose() }}>
    <button className="kb-lb-close" ref={closeBtn} onClick={onClose}>{s('بستن ×', 'Close ×')}</button>
    <span className="kb-lb-count">{index + 1} / {items.length}</span>
    <button className="kb-lb-btn kb-lb-prev" onClick={() => onIndex((index - 1 + items.length) % items.length)} aria-label={s('تصویر قبلی', 'Previous image')}>{fa ? '→' : '←'}</button>
    <figure><img src={item.image} alt={item.alt || ''} /><figcaption>{item.caption}{item.note ? <small>{item.note}</small> : null}</figcaption></figure>
    <button className="kb-lb-btn kb-lb-next" onClick={() => onIndex((index + 1) % items.length)} aria-label={s('تصویر بعدی', 'Next image')}>{fa ? '←' : '→'}</button>
  </div>
}
