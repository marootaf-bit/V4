import { Link } from 'react-router-dom'
import markets from '../../content/markets.json'
import { usePublicDict } from '../../lib.jsx'
import { Reveal } from '../../lib/motion.jsx'

// Shared countries block — single source of truth: src/content/markets.json
// variant: 'grid'    → hub card + country cards (home & markets pages)
//          'compact' → one-line strip (about page)
// reveal:  when true, cards reveal on scroll (hub first, then 50ms apart, max 200ms)
export default function MarketsCountries({ variant = 'grid', reveal = false }) {
  const { lang, L } = usePublicDict()
  const fa = lang !== 'en'
  const s = (a, b) => (fa ? a : b)
  const hub = markets.hub
  const countries = markets.countries || []

  if (variant === 'compact') {
    return <div className="kb-countries-compact">
      <div className="kb-cc-hub"><TradePin /><b>{L(hub.name)}</b><span>{L(hub.role)}</span></div>
      <ul>{countries.map(c => <li key={c.id}><Link to={`/markets#c-${c.id}`}>{L(c.name)}</Link></li>)}</ul>
      <Link className="v3-link" to="/markets">{s('جزئیات بازارها و کشورها', 'Markets & countries detail')} ↗</Link>
    </div>
  }

  const hubBody = <span className="kb-country-flag" aria-hidden="true"><TradeGlobe /></span>
  const cardBody = c => <span className="kb-country-flag" aria-hidden="true"><TradePin /></span>

  return <div className="kb-countries">
    {reveal
      ? <Reveal as="article" rkey="countries-hub" variant="sm" className="kb-country hub" id="c-afghanistan">
          {hubBody}<div><p className="kb-country-role">{L(hub.role)}</p><h3>{L(hub.name)}</h3><p>{L(hub.text)}</p></div>
        </Reveal>
      : <article className="kb-country hub" id="c-afghanistan">
          {hubBody}<div><p className="kb-country-role">{L(hub.role)}</p><h3>{L(hub.name)}</h3><p>{L(hub.text)}</p></div>
        </article>}
    {countries.map((c, i) => reveal
      ? <Reveal as="article" rkey={'country-' + c.id} key={c.id} delay={i * 50} className="kb-country" id={'c-' + c.id}>
          {cardBody(c)}<div>
            <p className="kb-country-role">{L(c.role)}</p>
            <h3>{L(c.name)}</h3>
            <p className="kb-country-goods"><b>{s('کالاهای مورد بررسی:', 'Goods reviewed:')}</b> {L(c.goods)}</p>
            <p>{L(c.text)}</p>
          </div>
        </Reveal>
      : <article className="kb-country" key={c.id} id={'c-' + c.id}>
          {cardBody(c)}<div>
            <p className="kb-country-role">{L(c.role)}</p>
            <h3>{L(c.name)}</h3>
            <p className="kb-country-goods"><b>{s('کالاهای مورد بررسی:', 'Goods reviewed:')}</b> {L(c.goods)}</p>
            <p>{L(c.text)}</p>
          </div>
        </article>)}
  </div>
}
function TradeGlobe() { return <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a15 15 0 0 1 0 18 15 15 0 0 1 0-18Z" /></svg> }
function TradePin() { return <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" aria-hidden="true"><path d="M12 21s-7-6.1-7-11a7 7 0 0 1 14 0c0 4.9-7 11-7 11Z" /><circle cx="12" cy="10" r="2.5" /></svg> }
