import { Link } from 'react-router-dom'
import { useContent } from '../../lib/store.jsx'
import { usePublicDict } from '../../lib.jsx'
// Primary contact channels: WhatsApp (when a valid number exists in settings) and email
// as prominent buttons, plus the enquiry form. No invented numbers: if settings.contact.whatsapp
// is empty/masked, the WhatsApp button simply does not render (reported as needed info).
export default function ContactActions({kind='contact',subject='',productName=''}){
 const {settings}=useContent(),{lang}=usePublicDict(),fa=lang==='fa'
 const contact=settings.contact??{},raw=String(contact.whatsapp??''),digits=raw.replace(/\D/g,'')
 const wa=!/[xX*•]/.test(raw)&&digits.length>=7&&digits.length<=15?`https://wa.me/${digits}?text=${encodeURIComponent(subject)}`:''
 const email=String(contact.email??'').trim()
 const query=new URLSearchParams(productName?{kind,subject,productName}:{kind,subject})
 return <div className="kb-actions">
  {wa&&<a className="kb-cta-button" href={wa} target="_blank" rel="noopener noreferrer">{fa?'گفتگو در واتساپ':'Chat on WhatsApp'} ↗</a>}
  {email&&<a className={wa?'kb-text-link':'kb-cta-button'} href={`mailto:${email}?subject=${encodeURIComponent(subject)}`}>{fa?'ارسال ایمیل':'Email us'}{wa?' ↗':''}</a>}
  <Link className="kb-text-link" to={`/contact?${query}`}>{fa?'فرم درخواست و راه‌های دیگر':'Enquiry form & other channels'}</Link>
 </div>
}
