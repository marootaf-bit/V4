import {Link,useLocation} from 'react-router-dom'
import {usePublicDict} from '../../lib.jsx'
export default function Hero({image,showImage=true,crumbs=[],title,sub,children}){
 const {lang,t}=usePublicDict(),{pathname}=useLocation(),fa=lang!=='en'
 const kind=pathname==='/contact'?'contact':pathname==='/about'?'about':pathname.startsWith('/projects')?'projects':pathname.startsWith('/news')?'news':['/products','/gallery','/downloads','/partners'].includes(pathname)?'catalogue':'service'
 const list=crumbs.filter(([to])=>to!=='/')
 return <section className={'n6-intro n6-intro--'+kind} aria-labelledby="public-page-title"><div className="n6-container n6-intro-layout"><div className="n6-intro-copy"><nav className="n6-breadcrumb" aria-label={fa?'مسیر صفحه':'Breadcrumb'}><Link to="/">{t('home')}</Link>{list.map(([to,label],i)=><span key={i}><i aria-hidden="true">/</i>{to?<Link to={to}>{label}</Link>:<span aria-current="page">{label}</span>}</span>)}</nav><h1 id="public-page-title">{title}</h1>{sub&&<p>{sub}</p>}{children}</div>{showImage&&<div className="n6-intro-photo"><img src={image||'/images/trade-port.webp'} alt="" fetchpriority="high" width="1200" height="700"/></div>}</div></section>
}
