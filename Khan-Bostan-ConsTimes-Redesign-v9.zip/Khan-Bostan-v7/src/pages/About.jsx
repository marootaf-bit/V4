import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useContent } from '../lib/store.jsx'
import { usePublicDict } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import ContactActions from '../components/public/ContactActions.jsx'
import MarketsCountries from '../components/public/MarketsCountries.jsx'
import Accordion from '../components/public/Accordion.jsx'
import { Reveal } from '../lib/motion.jsx'
export default function About(){const {data}=useContent(),{lang,L}=usePublicDict(),fa=lang!=='en',s=(a,b)=>fa?a:b
const {hash}=useLocation()
 const [activeAnchor,setActiveAnchor]=useState('')
useEffect(()=>{if(!hash)return;const el=document.querySelector(hash);if(!el)return;const reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;const t=setTimeout(()=>el.scrollIntoView({behavior:reduce?'auto':'smooth',block:'start'}),60);return()=>clearTimeout(t)},[hash])
const about=data?.settings?.about||{}
const team=(data.team||[]).map(m=>({id:m.id,photo:m.photo,initials:L(m.name).split(' ').filter(Boolean).slice(0,2).map(w=>w[0]).join(''),...m}))
const company=data?.settings?.company||{}
const profile=(data.documents||[]).find(d=>d.kind==='profile')
const leader=(data.team||[]).find(m=>m.group==='leadership')||null
const leaderInitials=leader?L(leader.name).split(' ').filter(Boolean).slice(0,2).map(w=>w[0]).join(''):''
const values=(about.values||[]).filter(v=>L(v.title))
const rail=[[ '#nature', s('ماهیت شرکت','Our nature')],['#story', s('شکل‌گیری','How it began')],['#fields', s('حوزه‌های فعالیت','Fields of work')],['#role', s('نقش و محدوده','Role & scope')],['#mission', s('مأموریت و ارزش‌ها','Mission & values')],['#method', s('شیوهٔ کار','How we work')],['#management', s('مدیریت و پیام','Management & message')],['#team', s('تیم','The team')],['#countries', s('کشورها','Countries')]]
const fields=[
 ['/products','محصولات ثابت','Established products','پنبهٔ صادراتی و تایر وارداتی؛ خط‌های معرفی‌شدهٔ شرکت با شرایط عرضه بر اساس استعلام.','Cotton exports and tyre imports; the company’s introduced lines, supply terms set by enquiry.'],
 ['/sourcing','تأمین سفارشی','Custom sourcing','شناسایی، بررسی و قیمت‌گیری کالای موردنظر شما از بازار داخلی یا خارجی.','Identifying, reviewing and pricing your goods from domestic or overseas markets.'],
 ['/import','تجارت داخلی و خارجی','Domestic & foreign trade','واردات به افغانستان، صادرات از افغانستان و تأمین در بازار داخل کشور.','Imports to Afghanistan, exports from Afghanistan and supply within the domestic market.'],
 ['/logistics','لوجستیک مستقل','Independent logistics','انتقال، اسناد، امور گمرکی و تحویل برای کالایی که خودتان خریده‌اید.','Transport, documents, customs and delivery for goods you have purchased yourself.']]
return <main id="main" className="v3-editorial n6-about">
<Hero title={s('خان بوستان؛ تجارت و لوجستیک با محوریت افغانستان','Khan Bostan. Trade and logistics centred on Afghanistan.')} sub={s('معرفی کامل شرکت: ماهیت فعالیت، شیوهٔ کار، تیم و بازارها — از دفتر مرکزی در مزارشریف.','A full introduction: what we do, how we work, our team and markets — from our Mazar-e-Sharif head office.')} image="/images/trade-highway.webp" crumbs={[[null,s('دربارهٔ شرکت','About')]]}/>

<section className="v3-section v3-intro-grid" id="nature">
 <figure className="n6-about-lead-photo"><img src="/images/about-office.webp" alt={s('تصویر معرفی فعالیت تجارتی','Illustrative trade activity')} loading="lazy"/><figcaption><span>{s('خان بوستان','KHAN BOSTAN')}</span><b>{s('تجارت از شناخت نیاز شما آغاز می‌شود.','Trade starts with understanding your requirements.')}</b><small>{s('مزارشریف، افغانستان','Mazar-e-Sharif, Afghanistan')}</small></figcaption></figure>
 <Reveal id="about-nature" variant="sm" className="v3-prose">
  <p className="v3-eyebrow">{s('ماهیت شرکت','WHO WE ARE')}</p>
  <h2>{s('یک شرکت تجارتی و لوجستیکی، مستقر در مزارشریف.','A trading and logistics company, based in Mazar-e-Sharif.')}</h2>
  <p>{s('خان بوستان در سه حوزهٔ به‌هم‌پیوسته فعالیت می‌کند: واردات کالا به افغانستان، صادرات محصولات افغانستان به بازارهای خارجی، و تجارت داخلی میان کسب‌وکارهای داخل کشور. در کنار این سه، خدمات لوجستیکی مستقل برای کالایی که مشتری خودش خریده است، بخش جدایی‌ناپذیر کار ماست.','Khan Bostan works across three connected areas: importing goods into Afghanistan, exporting Afghan products to foreign markets, and domestic trade between businesses inside the country. Alongside these, independent logistics for goods clients have purchased themselves is an integral part of our work.')}</p>
  <p>{s('مزارشریف، مرکز ولایت بلخ، یکی از کانون‌های اصلی تجارت شمال افغانستان است؛ نزدیکی آن به مرزهای شمالی و پیوندش با مسیرهای داخلی، هماهنگی واردات از بازارهای منطقه‌ای و آسیایی، صادرات محصولات محلی و تحویل در ولایات را ممکن می‌سازد. دفتر مرکزی شرکت همین‌جاست و گفتگوهای همکاری از همین‌جا پیش می‌رود.','Mazar-e-Sharif, the centre of Balkh province, is one of northern Afghanistan’s main trade hubs; its proximity to the northern borders and links to domestic routes make it possible to coordinate imports from regional and Asian markets, exports of local products, and delivery across the provinces. Our head office is here, and cooperation starts from here.')}</p>
  <p>{s('فعالیت شرکت به یک صنعت یا فهرست ثابت کالا محدود نیست؛ هر درخواست بر اساس نوع کالا، مقدار، مبدأ، مقصد و امکان اجرا بررسی می‌شود.','The company is not confined to one industry or a fixed goods list; each request is reviewed against the goods, volume, origin, destination and execution feasibility.')}</p>
 </Reveal>
</section>

{about.story&&<section className="v3-section" id="story" style={{paddingTop:0}}>
 <div className="v3-heading"><div><p className="v3-eyebrow">{s('شکل‌گیری و مسیر توسعه','HOW IT BEGAN')}</p><h2>{L(about.story.title)}</h2></div></div>
 <div className="ab-story-grid">
  <Reveal id="about-story-copy" variant="sm" className="ab-story-copy">{String(L(about.story.body)).split('\n\n').map((t,i)=><p key={i}>{t}</p>)}
   <Reveal as="ol" id="about-timeline" className="v3-timeline kb-stagger" style={{'--stagger':'70ms'}}>{(about.story.milestones||[]).map((m,i)=><li key={i} style={{'--i':i}}><span>{s('مرحلهٔ ','Stage ')+(i+1)}</span><h3>{L(m.title)}</h3><p>{L(m.text)}</p></li>)}</Reveal>
   <p className="kb-demo-mark">{L(about.story.note)}</p>
  </Reveal>
  <Reveal id="about-story-photo" variant="side" className="ab-story-photo-wrap"><figure className="ab-story-photo"><img src="/images/about-office.webp" alt={s('تصویر نمایشی فضای کاری تجارتی','Illustrative commercial workspace')} loading="lazy"/><figcaption>{s('تصویر نمایشی؛ عکس واقعی شرکت پس از تأیید درج می‌شود.','Illustrative image; a real company photo is added after approval.')}</figcaption></figure></Reveal>
 </div>
</section>}

{leader&&<section className="v3-section" id="management" style={{paddingTop:0}} aria-labelledby="mgmt-title">
 <div className="v3-heading"><div><p className="v3-eyebrow">{s('مدیریت و پیام مدیریت','MANAGEMENT & ITS MESSAGE')}</p><h2 id="mgmt-title">{s('از زبان مسئول شرکت','From the company’s lead')}</h2></div></div>
 <Reveal id="about-leader" variant="sm" style={{'--t-enter':'450ms'}} className="ab-leader-wrap"><article className="ab-leader">
  <div className="ab-leader-photo"><img src={leader.photo||undefined} alt={L(leader.name)} loading="lazy"/>{!leader.photo&&<span className="mono">{leaderInitials}</span>}
   <span className="ab-leader-role">{L(leader.role)}</span></div>
  <div className="ab-leader-body">
   <h3>{L(leader.name)}</h3>
   <p className="ab-leader-bio">{L(leader.bio)}</p>
   <blockquote className="ab-leader-quote">“{L(leader.message)}”</blockquote>
   <p className="kb-demo-mark">{s('معرفی و پیام مدیریت نمایشی است؛ نام، عکس و متن رسمی پس از تأیید مدیریت جایگزین می‌شود.','This introduction and message are demonstrative; the official name, photo and text replace them after management approval.')}</p>
  </div>
 </article></Reveal>
</section>}

<section className="v3-section" id="fields" style={{paddingTop:0}}>
 <div className="v3-heading"><div><p className="v3-eyebrow">{s('حوزه‌های فعالیت','FIELDS OF WORK')}</p><h2>{s('چهار حوزه، یک نقطهٔ تماس','Four fields, one point of contact')}</h2></div></div>
 <Reveal id="about-fields" variant="sm" className="v3-scope-list">{fields.map(([url,t,e,d,de])=><article key={url}><h3><Link to={url} style={{color:'inherit',textDecoration:'none'}}>{s(t,e)} ↗</Link></h3><p>{s(d,de)}</p></article>)}</Reveal>
</section>

<section className="v3-section v3-workspace" id="role" style={{paddingTop:0}}>
 <Reveal id="about-role" variant="sm" className="v3-prose">
  <p className="v3-eyebrow">{s('نقش ما و محدودهٔ مسئولیت','OUR ROLE & SCOPE')}</p>
  <h2>{s('نقش شرکت در هر همکاری، خودِ همکاری تعیین می‌کند.','Each engagement defines our role in it.')}</h2>
  <p>{s('بسته به جایگاه شما در معامله، نقش خان بوستان متفاوت است: گاهی خریدار و هماهنگ‌کنندهٔ کل مسیر است؛ گاهی فقط بخشی از خدمات — انتقال، اسناد یا گمرک — را برمی‌دارد؛ و گاهی تنها نقشش، بررسی بازار و ارائهٔ گزینه برای تصمیم شماست.','Depending on where you stand in a deal, Khan Bostan’s role differs: sometimes buyer and coordinator of the whole journey; sometimes holder of only one service — transport, documents or customs; and sometimes just a market review that puts options on your table.')}</p>
  <div className="v3-scope-list">
   <article><h3>{s('قرارداد، مرز مسئولیت است','The contract is the boundary')}</h3><p>{s('محدودهٔ کار، مسئولیت‌ها، هزینه‌ها و شرایط تحویل پیش از اجرا در قرارداد کتبی درج می‌شود؛ بدون آن مرحلهٔ اجرایی آغاز نمی‌شود.','Scope, responsibilities, costs and delivery terms are written into a contract before execution; execution does not begin without it.')}</p></article>
   <article><h3>{s('گزارش در نقاط توافق‌شده','Reporting at agreed points')}</h3><p>{s('بارگیری، عبور از مرز و رسیدن به مقصد، نقاط گزارش‌دهی معمول‌اند؛ شما در همان نقاط خبر می‌گیرید.','Loading, border crossing and arrival are the usual reporting points; you hear from us exactly there.')}</p></article>
  </div>
  <Link className="v3-link" to="/process">{s('مراحل همکاری از نزدیک','See the process in detail')} ↗</Link>
 </Reveal>
 <Reveal id="about-role-checklist" variant="sm" className="v3-checklist-wrap"><aside className="v3-checklist"><h2>{s('برای تعیین محدوده، این‌ها روشن شود','To set the scope, clarify')}</h2><ul>{(fa?['نوع و مشخصات کالا','مقدار و بسته‌بندی','مبدأ و مقصد','بازهٔ زمانی موردنظر','کدام مرحله با ما باشد: خرید، انتقال، اسناد، گمرک یا تحویل']:['Goods type and specifications','Volume and packing','Origin and destination','Required time window','Which stages are ours: purchase, transport, documents, customs or delivery']).map(x=><li key={x}>{x}</li>)}</ul></aside></Reveal>
</section>

<section className="v3-section ab-mv" id="mission" style={{paddingTop:0}}>
 <div className="v3-heading"><div><p className="v3-eyebrow">{s('مأموریت، چشم‌انداز و ارزش‌ها','MISSION, VISION & VALUES')}</p><h2>{s('چرا و چگونه کار می‌کنیم','Why and how we work')}</h2></div></div>
 <Reveal id="about-mv" variant="sm"><div className="ab-mv-grid">
  <article className="ab-mv-panel"><b>{s('مأموریت','MISSION')}</b><p>{L(about.mission)}</p></article>
  <article className="ab-mv-panel"><b>{s('چشم‌انداز','VISION')}</b><p>{L(about.vision)}</p></article>
 </div></Reveal>
 {values.length>0&&<Reveal id="about-values" variant="sm" className="ab-values">{values.map(v=><article key={L(v.title)}><h3>{L(v.title)}</h3><p>{L(v.text)}</p></article>)}</Reveal>}
</section>

<section className="v3-section" id="method" style={{paddingTop:0}}>
 <div className="v3-heading"><div><p className="v3-eyebrow">{s('شیوهٔ کار با مشتری','HOW WE WORK WITH CLIENTS')}</p><h2>{s('از پیام اول تا تحویل','From first message to delivery')}</h2></div><Link className="v3-link" to="/process">{s('صفحهٔ کامل روند','Full process page')} ↗</Link></div>
 <Reveal as="ol" id="about-method-steps" className="v3-step-list kb-stagger" style={{'--stagger':'80ms'}}>
  {(fa ? [
    ['درخواست', 'نام کالا، مقدار تقریبی، مبدأ و مقصد را می‌فرستید — واتساپ، ایمیل یا فرم.'],
    ['بررسی و پیشنهاد', 'امکان تأمین یا انتقال بررسی و گزینه‌ها با قیمت و شرایط اعلام می‌شود.'],
    ['توافق و قرارداد', 'محدودهٔ کار، مسئولیت‌ها و هزینه‌ها کتبی توافق می‌شود.'],
    ['اجرا و گزارش', 'مراحل توافق‌شده پیش می‌رود و در نقاط توافق‌شده خبر می‌گیرید.'],
  ] : [
    ['Enquiry', 'You send the goods, approximate quantity, origin and destination — WhatsApp, email or the form.'],
    ['Review & proposal', 'We review sourcing or transport feasibility and present options with price and terms.'],
    ['Agreement & contract', 'Scope, responsibilities and costs are agreed in writing.'],
    ['Execution & reporting', 'The agreed stages proceed and you hear from us at the agreed points.'],
  ]).map(([t, p], i) => <li key={t} style={{ '--i': i }}><b>{t}</b><br/>{p}</li>)}
 </Reveal>
 <p className="v3-note">{s('همهٔ مسیر می‌تواند با ما باشد، یا فقط بخشی از خدمات — مثلاً فقط انتقال یا فقط اسناد. انتخاب با شماست.','The whole journey can be ours, or only part of the services — for example just transport or just documents. The choice is yours.')}</p>
 <div className="v3-faq" style={{padding:'0',maxWidth:'none'}}>
  {(fa?[
   ['شرکت در بررسی سفارش چه نقشی دارد؟','درخواست شما را تحلیل می‌کنیم، گزینه‌های تأمین یا انتقال را بررسی و نتیجه را با قیمت و شرایط پیشنهاد می‌کنیم. تصمیم نهایی و توافق با شماست.'],
   ['مشتری چه معلوماتی ارائه می‌کند؟','نام و مشخصات کالا، مقدار تقریبی، مبدأ و مقصد، و در صورت وجود، زمان‌بندی و الزامات خاص (بسته‌بندی، استاندارد، برند).'],
   ['محدودهٔ خدمات چگونه توافق می‌شود؟','در گفتگوی پیش از قرارداد، فهرست دقیق کارهایی که بر عهدهٔ ما می‌شود، هزینه‌ها، مسئولیت‌ها و شرایط تحویل کتبی می‌شود.'],
   ['کدام مراحل را می‌توان به شرکت سپرد؟','هر ترکیبی: خرید و تأمین، انتقال، تهیهٔ اسناد، هماهنگی گمرکی، انبارش و تحویل — یک‌جا یا جداگانه.'],
   ['نقش تأمین‌کنندگان و همکاران لوجستیکی چیست؟','اجرای فیزیکی خرید و حمل معمولاً با تأمین‌کنندگان و کریرهای همکار انجام می‌شود؛ نقش ما انتخاب، هماهنگی و پاسخ‌گویی در برابر شماست. تقسیم کار دقیق در قرارداد درج می‌شود.'],
   ['گزارش و پیگیری در چه نقاطی انجام می‌شود؟','نقاط گزارش‌دهی (معمولاً بارگیری، عبور از مرز و رسیدن به مقصد) در قرارداد توافق می‌شود و در همان نقاط خبر می‌گیرید.'],
  ]:[
   ['What is the company’s role in reviewing an order?','We analyse your request, review sourcing or transport options and propose the outcome with price and terms. The final decision and agreement are yours.'],
   ['What information does the client provide?','The goods and their specifications, approximate quantity, origin and destination, and if any, timing and special requirements (packing, standard, brand).'],
   ['How is the service scope agreed?','In the pre-contract conversation, the exact list of tasks we take on, costs, responsibilities and delivery conditions are put in writing.'],
   ['Which stages can be delegated to the company?','Any combination: purchase and sourcing, transport, document preparation, customs coordination, storage and delivery — together or separately.'],
   ['What role do suppliers and logistics partners play?','Physical purchase and carriage are usually carried out by supplier and carrier partners; our role is selection, coordination and accountability to you. The exact division is written into the contract.'],
   ['At what points does reporting happen?','Reporting points (usually loading, border crossing and arrival) are agreed in the contract and you hear from us at exactly those points.'],
  ]).map(([q,a],i)=><Accordion key={q} defaultOpen={i===0} title={q}><p>{a}</p></Accordion>)}
  <p className="v3-note">{s('تقسیم کار نهایی با تأمین‌کنندگان و همکاران در هر قرارداد مشخص می‌شود؛ موارد بالا سازوکار پیشنهادی کار ما است.','The final division of labour with suppliers and partners is specified in each contract; the above is our proposed way of working.')}</p>
 </div>
</section>

{team.length>0&&<section className="v3-section" id="team" style={{paddingTop:0}}><div className="v3-heading"><div><p className="v3-eyebrow">{s('مدیریت و تیم','MANAGEMENT & TEAM')}</p><h2>{s('کسانی که پاسخ شما را می‌دهند','The people behind your answer')}</h2></div><p>{s('چهره‌ها و نقش‌ها نمایشی‌اند؛ معرفی واقعی اعضا پس از تأیید خودشان با نام و عکس کامل منتشر می‌شود.','Faces and roles are demonstrative; real members are introduced with full names and photos only after their approval.')}</p></div>
<Reveal id="about-team" className="kb-team">{team.map((m,i)=><Reveal as="article" rkey={'member-'+m.id} key={m.id} delay={i*60} className="kb-member">
 <div className="ava">{m.photo?<img src={m.photo} alt={L(m.name)} loading="lazy"/>:<span>{m.initials}</span>}</div>
 <div className="body"><h3>{L(m.name)}</h3><span className="role">{L(m.role)}</span><p>{L(m.bio)}</p></div></Reveal>)}</Reveal>
</section>}

<section className="v3-section" id="countries" style={{paddingTop:0}}>
 <div className="v3-heading"><div><p className="v3-eyebrow">{s('کشورها و بازارها','COUNTRIES & MARKETS')}</p><h2>{s('محور افغانستان، مبدأهای بررسی‌شده','Afghanistan at the centre, reviewed origins around it')}</h2></div></div>
 <Reveal id="about-countries" variant="sm"><MarketsCountries variant="compact"/></Reveal>
</section>

<section className="v3-section" style={{paddingTop:0}}>
 <Reveal id="about-two" variant="sm" className="ab-two-wrap"><div className="ab-two">
  <article className="ab-mini"><h3>{s('روابط تجارتی','Trade relationships')}</h3><p>{s('با تأمین‌کنندگان، همکاران حمل و مشتریان در کشورهای مختلف کار می‌کنیم. نام و نشان هیچ شرکت دیگری تنها با توضیح نوع رابطه و تأیید انتشار معرفی می‌شود؛ ادعای نمایندگی رسمی نمی‌کنیم.','We work with suppliers, freight partners and customers across several countries. No other company’s name or mark is published without a relationship description and publication approval; we claim no official agencies.')}</p><Link className="v3-link" to="/partners">{s('روابط تجارتی','Trade relationships')} ↗</Link></article>
  {profile&&<article className="ab-mini ab-mini-doc"><h3>{s('معرفی‌نامهٔ شرکت','Company profile')}</h3><p>{s('پروفایل نمایشی شرکت (دو صفحه، دو زبانه) آمادهٔ دانلود است؛ نسخهٔ رسمی پس از تأیید جایگزین می‌شود.','The demo company profile (two pages, bilingual) is ready to download; the official version replaces it after approval.')}</p><a className="v3-link" href={profile.file} download>{s('دانلود پروفایل (PDF)','Download profile (PDF)')} ↓</a><Link className="v3-link" to="/downloads" style={{marginInlineStart:10}}>{s('همهٔ اسناد','All documents')} ↗</Link></article>}
 </div></Reveal>
</section>

<div className="kb-wrap kb-business-cta"><h2>{s('از نیاز کسب‌وکارتان بگویید.','Tell us about your business requirement.')}</h2><ContactActions/></div>
</main>}
