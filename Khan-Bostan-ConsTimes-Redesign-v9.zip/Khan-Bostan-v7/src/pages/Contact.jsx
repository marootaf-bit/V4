import { useLocation } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import PublicLoading from '../components/public/PublicLoading.jsx'
import ContactChannels from '../components/public/ContactChannels.jsx'
import ContactForm from '../components/public/ContactForm.jsx'
import Accordion from '../components/public/Accordion.jsx'
import SiteContainer from '../components/public/SiteContainer.jsx'

export default function Contact() {
  const { data, settings } = useContent()
  const { t, L, lang } = usePublicDict()
  const location = useLocation()
  const query = new URLSearchParams(location.search)
  const requested = query.get('kind')
  const kind = ['contact', 'product', 'cooperation', 'sourcing', 'logistics', 'consultation'].includes(requested) ? requested : 'contact'
  const subject = (query.get('subject') || '').slice(0, 160)
  const productName = (query.get('productName') || '').slice(0, 180)
  if (!data) return <PublicLoading />

  const contact = settings.contact ?? {}
  const whatsapp = String(contact.whatsapp ?? '').trim()
  const phone = String(contact.phone ?? '').trim()
  const maskedContact = (value) => /[xX*•]/.test(String(value ?? ''))
  const waUrl = whatsapp && !maskedContact(whatsapp) ? `https://wa.me/${whatsapp.replace(/[^0-9]/g, '')}` : ''
  const phoneUrl = phone && !maskedContact(phone) ? `tel:${phone}` : ''
  const contactIntro = lang === 'fa'
    ? 'برای استعلام محصول، تأمین سفارشی، خدمات لوجستیکی یا مشاوره، از واتساپ یا ایمیل شروع کنید. تلفن، مراجعه و فرم نیز در دسترس‌اند.'
    : 'Start by WhatsApp or email for product, sourcing, logistics or advice enquiries. Phone, office visits and the form are also available.'
  const address = L(contact.address)
  const hours = L(contact.hours)
  const ways = [
    ...(contact.email ? [{ kind: 'mail', label: t('email'), value: contact.email, href: `mailto:${contact.email}`, dir: 'ltr' }] : []),
    ...(phoneUrl ? [{ kind: 'phone', label: t('phone'), value: phone, href: phoneUrl, dir: 'ltr' }] : []),
    ...(waUrl ? [{ kind: 'whatsapp', label: t('whatsapp_l'), value: whatsapp, href: waUrl, external: true, dir: 'ltr' }] : []),
    ...(address ? [{ kind: 'pin', label: t('address'), value: address }] : []),
    ...(hours ? [{ kind: 'clock', label: t('hours'), value: hours }] : []),
  ]
  ways.sort((a,b) => ['whatsapp','mail','phone','pin','clock'].indexOf(a.kind) - ['whatsapp','mail','phone','pin','clock'].indexOf(b.kind))
  const faqs = (data.faq ?? []).filter((item) => item.topic === 'contact')

  return <main id="main" className="v3-editorial n6-contact-page"><Hero image="/images/news-meeting.webp" crumbs={[[null, t('nav_contact')]]} title={lang==='fa'?'از نیاز تجارتی خود بگویید.':'Tell us what your business needs.'} sub={contactIntro}/>
    <section className="v3-section v3-contact-layout n6-contact-surface"><div className="v3-contact-information"><p className="v3-eyebrow">{lang==='fa'?'راه‌های مستقیم گفتگو':'DIRECT CONTACT'}</p><h2>{lang==='fa'?'واتساپ و ایمیل، نقطهٔ شروع.':'Start with WhatsApp or email.'}</h2><div className="v3-contact-methods">{ways.map(item=><div key={item.kind}><b>{item.label}</b>{item.href?<a href={item.href} dir={item.dir} target={item.external?'_blank':undefined} rel={item.external?'noopener noreferrer':undefined}>{item.value} ↗</a>:<p>{item.value}</p>}</div>)}</div><p className="v3-note">{lang==='fa'?'نام کالا، مقدار تقریبی و محل تحویل را در پیام اول بنویسید. برای مراجعهٔ حضوری، پیش از حرکت هماهنگ کنید.':'Include the goods, approximate quantity and delivery location in your first message. Please arrange an office visit before travelling.'}</p></div><div className="v3-enquiry-form"><ContactForm key={location.search} email={contact.email} initialKind={kind} initialSubject={subject} initialProductName={productName} lang={lang} t={t}/></div></section>
    {faqs.length>0&&<section className="v3-faq" aria-labelledby="contact-faq-title"><h2 id="contact-faq-title">{lang==='fa'?'پرسش‌های متداول تماس':'Contact questions'}</h2>{faqs.map((item,i)=><Accordion key={item.id||i} defaultOpen={i===0} title={L(item.q)}><p>{L(item.a)}</p></Accordion>)}</section>}
    <section className="n6-map-section" aria-labelledby="office-map-title"><div className="n6-container n6-section-heading"><div><span className="n6-label">{lang==='fa'?'دفتر مرکزی':'HEAD OFFICE'}</span><h2 id="office-map-title">{lang==='fa'?'در مزارشریف با شما هستیم.':'Based in Mazar-e-Sharif.'}</h2></div><p>{lang==='fa'?'نقشه، شهر مزارشریف را نشان می‌دهد؛ نشانی دقیق دفتر را پیش از مراجعه هماهنگ کنید.':'This map shows Mazar-e-Sharif city. Confirm the exact office address before visiting.'}</p></div><iframe title={lang==='fa'?'نقشهٔ شهر مزارشریف':'Mazar-e-Sharif city map'} src="https://maps.google.com/maps?q=Mazar-e-Sharif%2C%20Afghanistan&output=embed" loading="lazy" referrerPolicy="no-referrer-when-downgrade"/><div className="n6-container"><a className="n6-link" href="https://www.google.com/maps/search/?api=1&query=Mazar-e-Sharif%2C%20Afghanistan" target="_blank" rel="noopener noreferrer">{lang==='fa'?'بازکردن نقشهٔ شهر':'Open city map'} ↗</a></div></section>
  </main>
}
