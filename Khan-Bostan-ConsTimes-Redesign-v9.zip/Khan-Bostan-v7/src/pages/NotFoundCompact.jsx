import { Link } from 'react-router-dom'
import { usePublicDict } from '../lib.jsx'
export default function NotFoundCompact(){
 const {lang}=usePublicDict(),fa=lang!=='en',s=(a,b)=>fa?a:b
 return <main id="main" className="v3-editorial"><section className="v3-section" style={{textAlign:'center',paddingBlock:'90px'}}>
  <div style={{fontSize:64,fontWeight:750,color:'var(--kb-gold)',lineHeight:1}}>404</div>
  <h2 style={{margin:'14px 0 8px'}}>{s('این صفحه پیدا نشد','Page not found')}</h2>
  <p style={{maxWidth:'52ch',margin:'0 auto 22px'}}>{s('نشانی درخواستی در سایت موجود نیست یا جابه‌جا شده است.','The requested address does not exist on this site or has moved.')}</p>
  <Link to="/" className="v3-link" style={{justifyContent:'center'}}>{s('بازگشت به صفحهٔ اصلی','Back to the home page')}</Link>
 </section></main>}
