import { navigation, labelOf } from '../content/navigation.js'
import { Link } from 'react-router-dom'
import { useContent } from '../lib/store.jsx'
import { usePublicDict } from '../lib.jsx'
import Accordion from '../components/public/Accordion.jsx'

export default function Footer() {
 const {settings}=useContent()
 const {lang,L,t}=usePublicDict()
 const fa=lang==='fa'
 const contact=settings.contact||{}
 const main=navigation.filter(item=>!['/'].includes(item.path)).slice(0,6).map(item=>[item.path,labelOf(item,lang)])
 const resources=[['/products',fa?'محصولات':'Products'],['/process',fa?'مراحل همکاری':'Process'],['/news?view=gallery',fa?'گالری':'Gallery'],['/downloads',fa?'دانلودها':'Downloads']]
 const email=String(contact.email||'').trim()
 const sectionsLabel=fa?'بخش‌های سایت':'Site sections'
 const resourcesLabel=fa?'منابع و خدمات':'Resources'
 const linkList=(items)=>items.map(([to,label])=><li key={to}><Link to={to}>{label}</Link></li>)
 return <footer className="kb-footer"><div className="kb-wrap"><div className="kb-footer-grid">
  <div>
   <Link to="/" className="kb-footer-brand"><img src="/brand/khan-boostan-official.png" alt="" width="64" height="64"/><span><b>{L(settings.company?.name)}</b><small>{fa?'تجارت و لوجستیک | مزارشریف، افغانستان':'Trade & logistics | Mazar-e-Sharif, Afghanistan'}</small></span></Link>
   <p>{fa?'واردات به افغانستان، صادرات از افغانستان و تجارت داخلی؛ از مزارشریف، برای کسب‌وکارهای افغانستان و منطقه.':'Imports to and exports from Afghanistan plus domestic trade; from Mazar-e-Sharif for businesses across Afghanistan and the region.'}</p>
   <div className="kb-footer-contact">
    {email&&<><b>{fa?'ایمیل':'Email'}</b><span>{email}</span></>}
    <b>{fa?'دفتر مرکزی':'Head office'}</b><span>{fa?'مزارشریف، افغانستان':'Mazar-e-Sharif, Afghanistan'}</span>
   </div>
  </div>
  <nav className="kb-foot-desktop" aria-label={sectionsLabel}><h3>{sectionsLabel}</h3><ul>{linkList(main)}</ul></nav>
  <nav className="kb-foot-desktop" aria-label={resourcesLabel}><h3>{resourcesLabel}</h3><ul>{linkList(resources)}<li><Link to="/contact">{fa?'شروع درخواست':'Start an enquiry'}</Link></li></ul></nav>
  <Accordion className="kb-foot-m" title={sectionsLabel}><ul>{linkList(main)}</ul></Accordion>
  <Accordion className="kb-foot-m" title={resourcesLabel}><ul>{linkList(resources)}<li><Link to="/contact">{fa?'شروع درخواست':'Start an enquiry'}</Link></li></ul></Accordion>
 </div>
 <div className="kb-footer-bottom"><span>© {new Date().getFullYear()} {L(settings.company?.name)}{fa?' — نسخهٔ نمایشی با محتوای نمونه':' — preview with sample content'}</span><div><Link to="/privacy">{t('nav_privacy')}</Link><Link to="/terms">{t('nav_terms')}</Link></div></div></div></footer>
}
