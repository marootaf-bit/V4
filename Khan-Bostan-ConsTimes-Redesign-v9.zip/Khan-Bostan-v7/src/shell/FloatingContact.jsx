import { useLocation } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { useDict } from '../lib.jsx'
import ContactIcon from '../components/public/ContactIcon.jsx'

/** Data-driven quick contact action; prefers WhatsApp, then phone, then email. */
export default function FloatingContact() {
  const { settings } = useContent()
  const { lang } = useDict()
  const { pathname } = useLocation()
  const contact = settings?.contact ?? {}
  const wa = String(contact.whatsapp ?? '').trim()
  const phone = String(contact.phone ?? '').trim()
  const email = String(contact.email ?? '').trim()

  let action = null
  if (wa) action = { href: `https://wa.me/${wa.replace(/[^0-9]/g, '')}`, label: lang === 'fa' ? 'گفتگو در واتساپ' : 'Chat on WhatsApp', kind: 'wa', external: true }
  else if (phone) action = { href: `tel:${phone}`, label: lang === 'fa' ? 'تماس تلفنی' : 'Call us', kind: 'tel' }
  else if (email) action = { href: `mailto:${email}`, label: lang === 'fa' ? 'ارسال ایمیل' : 'Send email', kind: 'mail' }
  if (!action) return null
  const normalizedPath = pathname.replace(/\/+$/, '') || '/'
  // The About page has prominent, keyboard-accessible contact links in both its hero and closing CTA.
  // Suppress the fixed bubble there so it cannot cover the team cards at any viewport size.
  if (normalizedPath === '/about') return null
  // On the contact page itself the button could sit over the form controls and the
  // submit button; the page already opens with the primary channels.
  if (normalizedPath === '/contact') return null
  const denseMobilePage = ['/', '/contact', '/gallery', '/products', '/news'].includes(normalizedPath)

  return <a className={`${denseMobilePage ? 'tw-hidden sm:tw-flex' : 'tw-flex'} tw-fixed tw-bottom-4 tw-end-4 tw-z-40 tw-h-12 tw-w-12 tw-items-center tw-justify-center tw-rounded-full tw-bg-kb-blue tw-text-white tw-shadow-kb-lift tw-transition-colors hover:tw-bg-kb-navy motion-reduce:tw-transition-none focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-gold focus-visible:tw-ring-offset-2 sm:tw-bottom-5 sm:tw-end-5 sm:tw-h-14 sm:tw-w-14`} href={action.href} aria-label={action.label} title={action.label} {...(action.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}><ContactIcon kind={action.kind} /></a>
}
