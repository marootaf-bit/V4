import { useEffect, useRef, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useContent, useLang } from '../lib/store.jsx'
import { usePublicDict } from '../lib.jsx'
import { navigation, labelOf, groupForPath } from '../content/navigation.js'
import { useScrolled } from '../lib/motion.jsx'

export default function Header() {
 const { settings }=useContent(), {lang,L}=usePublicDict(), {setLang}=useLang()
 const {pathname,search,hash}=useLocation()
 const [mobile,setMobile]=useState(false), [closing,setClosing]=useState(false), [expanded,setExpanded]=useState(null)
 const scrolled=useScrolled(64)
 const closeTimer=useRef(0), closeMenuRef=useRef(()=>{})
 useEffect(()=>()=>clearTimeout(closeTimer.current),[])
 const closeMenu=()=>{ if(!mobile) return; clearTimeout(closeTimer.current); setClosing(true); closeTimer.current=setTimeout(()=>{setMobile(false);setClosing(false)},260) }
 closeMenuRef.current=closeMenu
 const header=useRef(null), panel=useRef(null), trigger=useRef(null)
 const active=groupForPath(pathname)?.path
 const fa=lang==='fa'
 useEffect(()=>{setMobile(false);setExpanded(null)},[pathname,search,hash])
 useEffect(()=>{
  const outside=e=>{if(!header.current?.contains(e.target))setExpanded(null)}
  const escape=e=>{if(e.key==='Escape'){header.current?.querySelector('.kb-desktop-navigation button[aria-expanded="true"]')?.focus();setExpanded(null);closeMenuRef.current()}}
  document.addEventListener('pointerdown',outside);document.addEventListener('keydown',escape)
  return()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',escape)}
 },[])
 useEffect(()=>{
  if(!mobile)return
  const old=document.body.style.overflow
  document.body.style.overflow='hidden'
  panel.current?.querySelector('button')?.focus()
  const trap=e=>{
   if(e.key!=='Tab')return
   const items=[...panel.current.querySelectorAll('a[href],button:not([disabled])')].filter(el=>el.getClientRects().length)
   if(!items.length)return
   if(e.shiftKey && (document.activeElement===items[0] || !panel.current.contains(document.activeElement))){e.preventDefault();items.at(-1).focus()}
   else if(!e.shiftKey && (document.activeElement===items.at(-1) || !panel.current.contains(document.activeElement))){e.preventDefault();items[0].focus()}
  }
  const wide=window.matchMedia('(min-width: 1200px)'), close=()=>{if(wide.matches)setMobile(false)}
  document.addEventListener('keydown',trap);wide.addEventListener('change',close)
  return()=>{document.body.style.overflow=old;document.removeEventListener('keydown',trap);wide.removeEventListener('change',close);trigger.current?.focus()}
 },[mobile])
 const childActive=child=>pathname===child.path.split('?')[0] && (child.path.includes('?')?new URLSearchParams(search).get('view')==='gallery':true)
 return <header className={`kb-navigation${scrolled?' is-scrolled':''}`} ref={header}><div className="kb5-topbar"><div className="kb-wrap"><span>{fa?'مزارشریف، افغانستان | تجارت و لوجستیک':'Mazar-e-Sharif, Afghanistan | Trade & logistics'}</span><em>{fa?'پیش‌نمایش طراحی · دارای محتوای نمونه':'Design preview · includes sample content'}</em></div></div>
  <div className="kb-wrap kb-nav-brand-row"><Link to="/" className="kb-nav-brand"><img src="/brand/khan-boostan-official.png" alt="" width="60" height="60"/><span><b>{L(settings.company?.name)}</b><small>{fa?'تجارت و لوجستیک | مزارشریف، افغانستان':'Trade & logistics | Mazar-e-Sharif, Afghanistan'}</small></span></Link>
   <div className="kb-nav-controls"><div className="kb-language" role="group" aria-label={fa?'زبان سایت':'Language'}>{[['fa','دری'],['en','EN']].map(([value,label])=><button type="button" key={value} onClick={()=>setLang(value)} aria-pressed={lang===value}>{label}</button>)}</div><Link className="kb-nav-enquiry" to="/contact">{fa?'شروع گفتگو':'Start an enquiry'}</Link><button type="button" className="kb-mobile-toggle" ref={trigger} onClick={()=>setMobile(true)} aria-expanded={mobile} aria-controls="site-mobile-navigation">{fa?'منو':'Menu'} <span aria-hidden="true">☰</span></button></div>
  </div>
  <nav className="kb-desktop-navigation" aria-label={fa?'منوی اصلی':'Main navigation'}><ul className="kb-wrap">{navigation.map((item,index)=><li key={item.path} className={active===item.path?'is-active':''} onBlur={e=>{if(!e.currentTarget.contains(e.relatedTarget))setExpanded(current=>current===item.path?null:current)}}><div className="kb-nav-parent"><Link to={item.path} aria-current={pathname===item.path?'page':undefined}>{labelOf(item,lang)}</Link>{item.children.length>0&&<button type="button" aria-expanded={expanded===item.path} aria-controls={`submenu-${index}`} aria-label={`${fa?'زیرمنوی':'Subpages of'} ${labelOf(item,lang)}`} onClick={()=>setExpanded(expanded===item.path?null:item.path)}><span aria-hidden="true">⌄</span></button>}</div>
   {item.children.length>0&&<ul className={`kb-dropdown${expanded===item.path?' is-open':''}`} id={`submenu-${index}`}>{item.children.map(child=><li key={child.path}><Link to={child.path} aria-current={childActive(child)?'page':undefined}>{labelOf(child,lang)}</Link></li>)}</ul>}
  </li>)}</ul></nav>
  {mobile&&<div className={`kb-mobile-overlay${closing?' is-closing':''}`} onClick={e=>{if(e.target===e.currentTarget)closeMenu()}}><div id="site-mobile-navigation" className="kb-mobile-panel" role="dialog" aria-modal="true" aria-label={fa?'فهرست سایت':'Site navigation'} ref={panel}><div className="kb-mobile-panel-head"><b>{fa?'فهرست سایت':'Site navigation'}</b><button type="button" onClick={closeMenu}>{fa?'بستن':'Close'} ×</button></div><nav aria-label={fa?'منوی موبایل':'Mobile navigation'}><ul>{navigation.map(item=><li className={active===item.path?'is-active':''} key={item.path}><Link className="kb-mobile-parent" to={item.path} aria-current={pathname===item.path?'page':undefined}>{labelOf(item,lang)}</Link>{item.children.length>0&&<ul className="kb-mobile-children">{item.children.map(child=><li key={child.path}><Link to={child.path} aria-current={childActive(child)?'page':undefined}>{labelOf(child,lang)}</Link></li>)}</ul>}</li>)}</ul></nav></div></div>}
 </header>
}
