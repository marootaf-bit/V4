import { lazy, Suspense } from 'react'
import { Routes, Route, useLocation, Navigate } from 'react-router-dom'
import { useDict } from './lib.jsx'
import { ScrollProgress } from '../src/lib/motion.jsx'
import SectionNavigation from './components/public/SectionNavigation.jsx'
import PageMeta from './PageMeta.jsx'
import Header from './shell/Header.jsx'
import Footer from './shell/Footer.jsx'
import FloatingContact from './shell/FloatingContact.jsx'
import SkipLink from './components/public/SkipLink.jsx'
import PublicLoading from './components/public/PublicLoading.jsx'

const Markets = lazy(() => import('./pages/Markets.jsx'))
const Process = lazy(() => import('./pages/Process.jsx'))
const BusinessPage = lazy(() => import('./pages/BusinessPage.jsx'))
const ProjectDetail = lazy(() => import('./pages/ProjectDetail.jsx'))
const NewsHub = lazy(() => import('./pages/NewsHub.jsx'))
const Home = lazy(() => import('./pages/Home.jsx'))
const About = lazy(() => import('./pages/About.jsx'))
const TeamRedirect = lazy(() => import('./pages/TeamRedirect.jsx'))
const Products = lazy(() => import('./pages/Products.jsx'))
const ProductDetail = lazy(() => import('./pages/ProductDetail.jsx'))
const NewsDetail = lazy(() => import('./pages/NewsDetail.jsx'))
const Partners = lazy(() => import('./pages/Partners.jsx'))
const Projects = lazy(() => import('./pages/Projects.jsx'))
const Contact = lazy(() => import('./pages/Contact.jsx'))
const Downloads = lazy(() => import('./pages/Downloads.jsx'))
const Legal = lazy(() => import('./pages/Legal.jsx'))
const NotFound = lazy(() => import('./pages/NotFound.jsx'))

export default function SiteShell() {
  const { lang } = useDict()
  const { pathname } = useLocation()
  const normalizedPath = pathname.replace(/\/+$/, '') || '/'
  const routeHasPrimaryAction = ['/', '/about', '/activities', '/import', '/export', '/process', '/products', '/gallery', '/partners', '/projects', '/contact'].includes(normalizedPath) || normalizedPath.startsWith('/products/') || normalizedPath.startsWith('/news/')
  const showFooterCta = !routeHasPrimaryAction
  const printAbout = normalizedPath === '/about'
  const printHidden = printAbout ? 'print:tw-hidden' : ''
  return <div className={`public-site tw-flex tw-min-h-screen tw-flex-col tw-overflow-x-clip tw-bg-white tw-font-sans tw-text-kb-ink ${printAbout ? 'print:tw-min-h-0 print:tw-overflow-visible print:tw-bg-white' : ''}`}>
    <SkipLink lang={lang} />
    <div className={printHidden}><ScrollProgress /></div>
    <PageMeta />
    <div className={printHidden}><Header /></div>
    <SectionNavigation />
    <Suspense fallback={<PublicLoading />}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/team" element={<TeamRedirect />} />
        <Route path="/activities" element={<BusinessPage page="activities" />} />
        <Route path="/trade-guide" element={<LegacyRedirect to="/news" />} />
        <Route path="/import" element={<BusinessPage page="import" />} />
        <Route path="/export" element={<BusinessPage page="export" />} />
        <Route path="/process" element={<Process />} />
        <Route path="/markets" element={<Markets />} />
        <Route path="/sourcing" element={<BusinessPage page="sourcing" />} />
        <Route path="/domestic-trade" element={<BusinessPage page="domestic-trade" />} />
        <Route path="/logistics" element={<BusinessPage page="logistics" />} />
        <Route path="/projects/:slug" element={<ProjectDetail />} />
        <Route path="/products" element={<Products />} />
        <Route path="/products/:slug" element={<ProductDetail />} />
        <Route path="/news" element={<NewsHub />} />
        <Route path="/news/:slug" element={<NewsDetail />} />
        <Route path="/gallery" element={<LegacyRedirect to="/news" gallery />} />
        <Route path="/partners/:slug" element={<LegacyRedirect to="/partners" />} />
        <Route path="/partners" element={<Partners />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/downloads" element={<Downloads />} />
        <Route path="/careers" element={<LegacyRedirect to="/about" />} />
        <Route path="/privacy" element={<Legal kind="privacy" />} />
        <Route path="/terms" element={<Legal kind="terms" />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
    <div className={printHidden}><Footer showCta={showFooterCta} /></div>
    <FloatingContact />
  </div>
}

function LegacyRedirect({to,gallery=false}) {
 const {search}=useLocation()
 const params=new URLSearchParams(search)
 if(gallery)params.set("view","gallery")
 return <Navigate replace to={{pathname:to,search:params.toString()?`?${params}`:""}}/>
}
