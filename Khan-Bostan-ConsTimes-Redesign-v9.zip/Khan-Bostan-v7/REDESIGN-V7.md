# Reference redesign v7

This revision retains v6 home, about, service, product, catalogue, projects and contact layouts and completes eight remaining page types. All existing company content and bilingual routes remain.

| Page | New structure |
| --- | --- |
| Markets | Selectable conceptual Afghanistan network, country dossier with photograph and enquiry, import/export/domestic paths, market notes and FAQ |
| Process | Three enquiry modes, continuous four-stage roadmap with inputs and outputs, logistics photograph and checklist |
| Partners | Supplier/company/client relationship, photographed directory, cooperation requirements |
| Downloads | Featured document with actual PDF cover, category filters, real file metadata and download links |
| Gallery | Three album covers, counts, category filters, captioned mosaic and shared lightbox |
| News | Editorial masthead, search and categories, lead story, side stories and article grid |
| Article | Large cover, reading column with contents navigation, practical takeaway and related articles |
| Project detail | Cover, project facts, need and scope, execution stages, challenge/solution, result and photo gallery |

Visual references: NaviX logistics for process and business explanation; HAGUE and Digitro for editorial hierarchy; Conztru for case presentation. Shared navy, blue, gold, typography and spacing maintain one company identity. Stock and generated imagery illustrate services; they do not establish company facilities, partnerships or completed contracts. Demo labels remain.

## Document correction
Two downloadable demo PDFs were regenerated with correctly shaped right-to-left Dari text. Their preview images are rasterized from their actual first pages. Company profile: two pages. Product catalogue: five pages covering the eight existing records. Demo file metadata now reflects the generated files.

## Validation and limits
Architecture check: eight top navigation sections and eighteen fixed pages. Production build succeeds. Server rendering: 78/78 route-language combinations; referenced media exist and checked internal destinations resolve. All seven PDF pages were rasterized for inspection. Browser preview service is unavailable in this environment; viewport appearance, keyboard interactions, gallery navigation and animations still need browser verification. SSR checks do not establish those behaviours.

Source package excludes node_modules, dist, generated CSS, temporary QA files and caches. It remains a React frontend: the admin is read-only and enquiries use the existing email workflow. No Laravel/SQLite backend is implemented by this revision.
