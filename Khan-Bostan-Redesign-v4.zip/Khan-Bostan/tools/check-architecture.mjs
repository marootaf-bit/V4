import assert from 'node:assert/strict'
import fs from 'node:fs'
import { navigation, fixedPages, groupForPath } from '../src/content/navigation.js'
assert.equal(navigation.length,8)
assert.equal(fixedPages.length,18)
assert.equal(new Set(fixedPages.map(page=>page.path)).size,18)
for(const [path,parent] of [['/sourcing','/activities'],['/import','/activities'],['/export','/activities'],['/domestic-trade','/activities'],['/markets','/about'],['/partners','/about'],['/process','/logistics'],['/downloads','/news'],['/products/sample-rice','/products'],['/projects/project-1','/projects'],['/news/story-1','/news']]) assert.equal(groupForPath(path)?.path,parent,path)
const shell=fs.readFileSync(new URL('../src/SiteShell.jsx',import.meta.url),'utf8')
for(const page of fixedPages)assert.ok(shell.includes(`path="${page.path}"`),`Missing route: ${page.path}`)
const business=JSON.parse(fs.readFileSync(new URL('../src/content/business.json',import.meta.url)))
for(const [key,page] of Object.entries(business)){
 for(const lang of ['fa','en']){
  assert.ok(page.title[lang]&&page.intro[lang],key)
  for(const card of page.cards)assert.ok(card.title[lang]&&card.body[lang],key)
  for(const item of page.faq)assert.ok(item.q[lang]&&item.a[lang],key)
 }
 const asset=new URL(`../deploy${page.image}`,import.meta.url)
 assert.ok(fs.existsSync(asset),`Missing service image: ${page.image}`)
}
console.log('PASS: 8 primary sections; 18 fixed pages; grouped detail routes; bilingual service content and images.')
