export default {
  content: {
    relative: true,
    files: ['./src/**/*.{js,jsx,ts,tsx,html}'],
  },
  prefix: 'tw-',
  corePlugins: { preflight: false },
  theme: {
    extend: {
      colors: {
        kb: {
          blue: '#0168B4',
          navy: '#082F4C',
          gold: '#E3C27A',
          'gold-soft': '#F6EBD0',
          ink: '#202A35',
          body: '#425565',
          muted: '#5F6F7A',
          paper: '#F5F7F9',
          line: '#DCE5EB',
          control: '#82909B',
          white: '#FFFFFF',
        },
      },
      fontFamily: {
        sans: ['Vazirmatn', 'Noto Sans Arabic', 'Tahoma', 'Arial', 'sans-serif'],
        english: ['Inter', 'system-ui', 'Segoe UI', 'Arial', 'sans-serif'],
        head: ['Vazirmatn', 'Noto Sans Arabic', 'Tahoma', 'Arial', 'sans-serif'],
      },
      boxShadow: {
        kb: '0 18px 42px -30px rgba(8,47,76,.32)',
        'kb-lift': '0 20px 40px -27px rgba(8,47,76,.4)',
      },
      borderRadius: {
        kb: '8px',
        'kb-lg': '12px',
      },
    },
  },
  plugins: [],
}
