# Content revision

The active catalogue now contains only the two product lines supplied by the client: cotton exports and tyre imports. Other product lines can be added after the client provides their names. Product illustrations are symbolic SVG assets, not photographs of stock.

Invented sample team members, testimonials, partner records, product records and project records have been removed from active data. News has been replaced with clearly labelled evergreen enquiry guides, not claimed company events. Project and relationship pages describe cooperation scope without claiming completed contracts.

Geography, business audience and capabilities follow the client brief. No numerical track record, offices abroad, guaranteed timings, prices, certification or stock claims have been added. Contact details require owner confirmation before publication. The contact form prepares an email draft; it has no sending backend.
