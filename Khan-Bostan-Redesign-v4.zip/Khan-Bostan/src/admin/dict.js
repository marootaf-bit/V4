/* Admin UI dictionary + collection schemas (bilingual fa/en) */

export const A = {
  fa: {
    appName: 'پنل مدیریت خان بوستان', signIn: 'ورود', signOut: 'خروج',
    email: 'ایمیل', password: 'رمز عبور', signingIn: 'در حال ورود…',
    loginTitle: 'ورود به پنل مدیریت', loginHint: 'با حساب مدیر سایت وارد شوید.',
    badLogin: 'ایمیل یا رمز عبور نادرست است.', tooMany: 'کوشش بیش از حد؛ ۱۵ دقیقه صبر کنید.',
    dashboard: 'داشبورد', content: 'محتوا', trade: 'بخش تجارتی', system: 'سیستم',
    requests: 'درخواست‌ها', settings: 'تنظیمات', account: 'حساب کاربری', viewSite: 'مشاهدهٔ سایت',
    items: 'مورد', published: 'منتشرشده', draft: 'پیش‌نویس', all: 'همه', search: 'جستجو…',
    newItem: 'مورد جدید', edit: 'ویرایش', del: 'حذف', save: 'ذخیره', saving: 'در حال ذخیره…',
    cancel: 'انصراف', close: 'بستن', status: 'وضعیت', order: 'ترتیب', updated: 'به‌روزشده',
    actions: 'عمل‌ها', confirmDelete: 'این مورد برای همیشه حذف شود؟', saved: 'ذخیره شد.',
    deleted: 'حذف شد.', failed: 'خطا در انجام عملیات.', empty: 'موردی وجود ندارد.',
    upload: 'بارگذاری', uploading: 'در حال بارگذاری…', pickFile: 'انتخاب فایل',
    imageHint: 'JPG / PNG / WEBP / SVG تا ۸ مگابایت', fileHint: 'فقط PDF تا ۸ مگابایت',
    addRow: 'افزودن سطر', removeRow: 'حذف سطر', url: 'نشانی', fa: 'دری', en: 'انگلیسی',
    statsOverview: 'نمای کلی', last14: 'فعالیت ۱۴ روز اخیر', recent: 'آخرین تغییرات',
    byStatus: 'درخواست‌ها بر اساس وضعیت', byKind: 'بر اساس موضوع', totalItems: 'مجموع محتوا',
    uploadsCount: 'فایل‌های بارگذاری‌شده', initialPass: 'فایل رمز اولیه هنوز روی سرور است — از بخش حساب آن را تغییر دهید.',
    new: 'جدید', read: 'خوانده‌شده', done: 'انجام‌شده', markRead: 'خوانده‌شده', markDone: 'انجام‌شده',
    markNew: 'برگشت به جدید', noRequests: 'درخواستی ثبت نشده است.', caller: 'درخواست‌کننده',
    phone: 'تلفن', message: 'متن', subject: 'موضوع', kind: 'نوع', date: 'تاریخ', ip: 'IP',
    generalSettings: 'تنظیمات عمومی', editJson: 'ویرایش JSON', invalidJson: 'JSON نامعتبر است.',
    changePass: 'تغییر رمز عبور', currentPass: 'رمز فعلی', newPass: 'رمز جدید (حداقل ۱۰ نویسه)',
    repeatPass: 'تکرار رمز جدید', passMismatch: 'رمز جدید و تکرار آن یکسان نیست.',
    passChanged: 'رمز عبور تغییر کرد.', notifyEmail: 'ایمیل دریافت اطلاعیه‌ها',
    sectionsHint: 'نمایش یا پنهان‌سازی بخش‌های سایت — اطلاعات بخش پنهان‌شده حفظ می‌شود و لینک‌های آن از منو و فوتر حذف می‌گردد.',
    showDemo: 'نمایش محتوای آزمایشی',
    showFacts: 'نمایش آمار در یک نگاه', showNews: 'نمایش اخبار', showProducts: 'نمایش محصولات',
    showCareers: 'نمایش فرصت‌های شغلی', showTeam: 'نمایش تیم و پیام مدیریت',
    showPartners: 'نمایش همکاران و برندها', showProjects: 'نمایش سوابق همکاری',
    showGallery: 'نمایش گالری عکس و ویدیو', showTestimonials: 'نمایش نظرات مشتریان',
    showDownloads: 'نمایش مرکز دانلود', showFaq: 'نمایش پرسش‌های متداول',
    reorderHint: 'ترتیب نمایش در سایت با فلش‌ها تغییر می‌کند.',
    demoItem: 'آزمایشی', featured: 'ویژه', yes: 'بله', no: 'خیر', none: '—',
    lang: 'زبان', reload: 'بارگذاری دوباره', back: 'بازگشت', openEditor: 'بازکردن ویرایشگر',
    title: 'عنوان', name: 'نام', image: 'تصویر', category: 'دسته', unsaved: 'تغییرات ذخیره نشده'
  },
  en: {
    appName: 'Khan Boostan admin', signIn: 'Sign in', signOut: 'Sign out',
    email: 'Email', password: 'Password', signingIn: 'Signing in…',
    loginTitle: 'Admin sign-in', loginHint: 'Use the site administrator account.',
    badLogin: 'Wrong email or password.', tooMany: 'Too many attempts — wait 15 minutes.',
    dashboard: 'Dashboard', content: 'Content', trade: 'Trade', system: 'System',
    requests: 'Requests', settings: 'Settings', account: 'Account', viewSite: 'View site',
    items: 'items', published: 'Published', draft: 'Draft', all: 'All', search: 'Search…',
    newItem: 'New item', edit: 'Edit', del: 'Delete', save: 'Save', saving: 'Saving…',
    cancel: 'Cancel', close: 'Close', status: 'Status', order: 'Order', updated: 'Updated',
    actions: 'Actions', confirmDelete: 'Delete this item permanently?', saved: 'Saved.',
    deleted: 'Deleted.', failed: 'Action failed.', empty: 'Nothing here yet.',
    upload: 'Upload', uploading: 'Uploading…', pickFile: 'Choose file',
    imageHint: 'JPG / PNG / WEBP / SVG up to 8 MB', fileHint: 'PDF only, up to 8 MB',
    addRow: 'Add row', removeRow: 'Remove row', url: 'URL', fa: 'Dari', en: 'English',
    statsOverview: 'Overview', last14: 'Activity — last 14 days', recent: 'Recent changes',
    byStatus: 'Requests by status', byKind: 'By topic', totalItems: 'Total content items',
    uploadsCount: 'Uploaded files', initialPass: 'The initial-password file is still on the server — change it under Account.',
    new: 'New', read: 'Read', done: 'Done', markRead: 'Mark read', markDone: 'Mark done',
    markNew: 'Back to new', noRequests: 'No requests recorded.', caller: 'Requester',
    phone: 'Phone', message: 'Message', subject: 'Subject', kind: 'Kind', date: 'Date', ip: 'IP',
    generalSettings: 'General settings', editJson: 'Edit JSON', invalidJson: 'Invalid JSON.',
    changePass: 'Change password', currentPass: 'Current password', newPass: 'New password (min. 10 characters)',
    repeatPass: 'Repeat new password', passMismatch: 'New password and confirmation differ.',
    passChanged: 'Password changed.', notifyEmail: 'Notification email',
    sectionsHint: 'Show or hide site sections — hidden sections keep their data and their links are removed from menus and footer.',
    showDemo: 'Show demo content',
    showFacts: 'Show at-a-glance stats', showNews: 'Show news', showProducts: 'Show products',
    showCareers: 'Show careers', showTeam: 'Show team & management message',
    showPartners: 'Show partners & brands', showProjects: 'Show track record',
    showGallery: 'Show photo & video gallery', showTestimonials: 'Show client testimonials',
    showDownloads: 'Show download centre', showFaq: 'Show FAQ',
    reorderHint: 'Site order changes with the arrows.',
    demoItem: 'Demo', featured: 'Featured', yes: 'Yes', no: 'No', none: '—',
    lang: 'Language', reload: 'Reload', back: 'Back', openEditor: 'Open editor',
    title: 'Title', name: 'Name', image: 'Image', category: 'Category', unsaved: 'Unsaved changes'
  }
}

/* field types: bi | bitext | text | textarea | image | images | file | select | bool | date | repeat | json */
const bi = (fa, en) => ({ fa, en })

export const COLLECTIONS = {
  products: {
    label: bi('محصولات', 'Products'), group: 'content', titleKey: 'name', imageKey: 'image',
    fields: [
      { k: 'name', t: 'bi', label: bi('نام محصول', 'Product name'), req: true },
      { k: 'category', t: 'select', label: bi('دسته‌بندی', 'Category'), from: 'categories', labelKey: 'name' },
      { k: 'short', t: 'bi', label: bi('توضیح کوتاه', 'Short description') },
      { k: 'description', t: 'bitext', label: bi('توضیحات کامل', 'Full description') },
      { k: 'image', t: 'image', label: bi('تصویر اصلی', 'Main image') },
      { k: 'gallery', t: 'images', label: bi('گالری', 'Gallery') },
      { k: 'specs', t: 'repeat', label: bi('مشخصات (متناسب با نوع محصول)', 'Specifications (per product type)'), fields: [
        { k: 'k', t: 'bi', label: bi('عنوان', 'Key') }, { k: 'v', t: 'bi', label: bi('مقدار', 'Value') }
      ] },
      { k: 'brand', t: 'text', label: bi('برند (در صورت تأیید)', 'Brand (if confirmed)') },
      { k: 'origin', t: 'bi', label: bi('کشور مبدأ', 'Country of origin') },
      { k: 'packaging', t: 'bi', label: bi('نوع بسته‌بندی', 'Packaging') },
      { k: 'unit', t: 'bi', label: bi('واحد عرضه', 'Supply unit') },
      { k: 'moq', t: 'text', label: bi('حداقل مقدار سفارش (فقط اگر مشخص است)', 'Minimum order (only if known)') },
      { k: 'status', t: 'select', label: bi('وضعیت عرضه', 'Supply status'), opts: [
        { v: 'available', l: bi('موجود', 'Available') }, { v: 'on_request', l: bi('قابل تأمین', 'On request') },
        { v: 'inquiry', l: bi('نیازمند استعلام', 'Requires inquiry') }
      ] },
      { k: 'featured', t: 'bool', label: bi('ویژه', 'Featured') },
      { k: 'demo', t: 'bool', label: bi('محتوای آزمایشی', 'Demo content') }
    ]
  },
  categories: {
    label: bi('دسته‌بندی‌ها', 'Categories'), group: 'content', titleKey: 'name',
    fields: [
      { k: 'name', t: 'bi', label: bi('نام دسته', 'Category name'), req: true },
      { k: 'description', t: 'bitext', label: bi('توضیح', 'Description') }
    ]
  },
  news: {
    label: bi('اخبار', 'News'), group: 'content', titleKey: 'title', imageKey: 'image',
    fields: [
      { k: 'title', t: 'bi', label: bi('عنوان', 'Title'), req: true },
      { k: 'date', t: 'date', label: bi('تاریخ', 'Date') },
      { k: 'category', t: 'select', label: bi('نوع خبر', 'News type'), opts: [
        { v: 'news', l: bi('خبر', 'News') }, { v: 'note', l: bi('یادداشت', 'Note') }, { v: 'announce', l: bi('اطلاعیه', 'Announcement') }
      ] },
      { k: 'image', t: 'image', label: bi('تصویر', 'Image') },
      { k: 'excerpt', t: 'bitext', label: bi('خلاصه', 'Excerpt') },
      { k: 'body', t: 'bitext', label: bi('متن', 'Body') },
      { k: 'source', t: 'text', label: bi('منبع (در صورت بازنشر)', 'Source (if republished)') },
      { k: 'featured', t: 'bool', label: bi('ویژه', 'Featured') },
      { k: 'demo', t: 'bool', label: bi('محتوای آزمایشی', 'Demo content') }
    ]
  },
  documents: {
    label: bi('اسناد', 'Documents'), group: 'content', titleKey: 'title',
    fields: [
      { k: 'title', t: 'bi', label: bi('عنوان', 'Title'), req: true },
      { k: 'kind', t: 'select', label: bi('نوع سند', 'Document type'), opts: [
        { v: 'profile', l: bi('پروفایل شرکت', 'Company profile') }, { v: 'catalog', l: bi('کتالوگ', 'Catalogue') },
        { v: 'certificate', l: bi('گواهی‌نامه', 'Certificate') }, { v: 'other', l: bi('سایر', 'Other') }
      ] },
      { k: 'description', t: 'bitext', label: bi('توضیح', 'Description') },
      { k: 'file', t: 'file', label: bi('فایل PDF', 'PDF file') },
      { k: 'lang', t: 'select', label: bi('زبان سند', 'Document language'), opts: [
        { v: 'fa', l: bi('دری', 'Dari') }, { v: 'en', l: bi('انگلیسی', 'English') }, { v: 'fa+en', l: bi('دوزبانه', 'Bilingual') }
      ] },
      { k: 'size', t: 'text', label: bi('حجم فایل (مثلاً 250KB)', 'File size (e.g. 250KB)') },
      { k: 'updated', t: 'date', label: bi('تاریخ به‌روزرسانی', 'Updated') },
      { k: 'demo', t: 'bool', label: bi('محتوای آزمایشی', 'Demo content') }
    ]
  },
  gallery: {
    label: bi('گالری عکس و ویدیو', 'Photo & video gallery'), group: 'content', titleKey: 'caption', imageKey: 'image',
    fields: [
      { k: 'image', t: 'image', label: bi('تصویر (یا پیش‌نمایش ویدیو)', 'Image (or video poster)'), req: true },
      { k: 'video', t: 'text', label: bi('نشانی ویدیو (اختیاری — MP4)', 'Video URL (optional — MP4)') },
      { k: 'poster', t: 'image', label: bi('پیش‌نمایش ویدیو', 'Video poster') },
      { k: 'caption', t: 'bi', label: bi('عنوان/کپشن', 'Caption') },
      { k: 'album', t: 'bi', label: bi('آلبوم', 'Album') },
      { k: 'demo', t: 'bool', label: bi('محتوای آزمایشی', 'Demo content') }
    ]
  },
  faq: {
    label: bi('پرسش‌های پرتکرار', 'FAQ'), group: 'content', titleKey: 'q',
    fields: [
      { k: 'topic', t: 'select', label: bi('موضوع', 'Topic'), opts: [
        { v: 'general', l: bi('عمومی', 'General') }, { v: 'import', l: bi('واردات', 'Import') },
        { v: 'export', l: bi('صادرات', 'Export') }, { v: 'order', l: bi('سفارش و تحویل', 'Order & delivery') }
      ] },
      { k: 'q', t: 'bi', label: bi('پرسش', 'Question'), req: true },
      { k: 'a', t: 'bitext', label: bi('پاسخ', 'Answer') }
    ]
  },
  brands: {
    label: bi('برندها', 'Brands'), group: 'trade', titleKey: 'name', imageKey: 'logo',
    fields: [
      { k: 'name', t: 'bi', label: bi('نام برند', 'Brand name'), req: true },
      { k: 'category', t: 'select', label: bi('دسته‌بندی', 'Category'), from: 'categories', labelKey: 'name' },
      { k: 'logo', t: 'image', label: bi('لوگو', 'Logo') },
      { k: 'relation', t: 'bi', label: bi('نوع رابطه با خان بوستان (دقیق)', 'Relation to Khan Boostan (exact)') },
      { k: 'website', t: 'text', label: bi('وب‌سایت رسمی (اختیاری)', 'Official website (optional)') },
      { k: 'description', t: 'bitext', label: bi('توضیح', 'Description') },
      { k: 'demo', t: 'bool', label: bi('محتوای آزمایشی', 'Demo content') }
    ]
  },
  partners: {
    label: bi('همکاران و روابط تجارتی', 'Partners & relations'), group: 'trade', titleKey: 'name', imageKey: 'logo',
    fields: [
      { k: 'name', t: 'bi', label: bi('نام', 'Name'), req: true },
      { k: 'kind', t: 'select', label: bi('نوع رابطه (تفکیک دقیق)', 'Relation type (exact)'), opts: [
        { v: 'agency', l: bi('نمایندگی رسمی', 'Official agency') }, { v: 'partner', l: bi('شریک تجارتی', 'Trade partner') },
        { v: 'supplier', l: bi('تأمین‌کننده', 'Supplier') }, { v: 'client', l: bi('مشتری', 'Client') },
        { v: 'brand', l: bi('برند عرضه‌شده', 'Brand offered') }, { v: 'affiliate', l: bi('شرکت وابسته', 'Affiliated company') }
      ] },
      { k: 'country', t: 'bi', label: bi('کشور', 'Country') },
      { k: 'field', t: 'bi', label: bi('زمینهٔ فعالیت', 'Field of activity') },
      { k: 'since', t: 'text', label: bi('از سال', 'Since') },
      { k: 'logo', t: 'image', label: bi('لوگو', 'Logo') },
      { k: 'website', t: 'text', label: bi('وب‌سایت رسمی (اختیاری)', 'Official website (optional)') },
      { k: 'description', t: 'bitext', label: bi('توضیح کوتاه نوع رابطه', 'Short relation description') },
      { k: 'featured', t: 'bool', label: bi('ویژه', 'Featured') },
      { k: 'demo', t: 'bool', label: bi('محتوای آزمایشی', 'Demo content') }
    ]
  },
  projects: {
    label: bi('سوابق همکاری', 'Track record & cases'), group: 'trade', titleKey: 'title', imageKey: 'image',
    fields: [
      { k: 'title', t: 'bi', label: bi('عنوان', 'Title'), req: true },
      { k: 'client', t: 'bi', label: bi('نام مشتری (فقط با اجازهٔ انتشار)', 'Client name (only with permission)') },
      { k: 'sector', t: 'bi', label: bi('حوزهٔ فعالیت / نوع کالا', 'Sector / goods type') },
      { k: 'year', t: 'text', label: bi('سال یا دوره', 'Year or period') },
      { k: 'market', t: 'bi', label: bi('محل یا بازار (در صورت امکان انتشار)', 'Location / market (if publishable)') },
      { k: 'image', t: 'image', label: bi('تصویر', 'Image') },
      { k: 'need', t: 'bitext', label: bi('خلاصهٔ نیاز مشتری', 'Client need summary') },
      { k: 'action', t: 'bitext', label: bi('نقش و اقدامات خان بوستان', 'Khan Boostan role & actions') },
      { k: 'result', t: 'bitext', label: bi('نتیجهٔ قابل اثبات', 'Provable result') },
      { k: 'featured', t: 'bool', label: bi('ویژه (نمایش در صفحهٔ اصلی)', 'Featured (show on home)') },
      { k: 'demo', t: 'bool', label: bi('محتوای آزمایشی', 'Demo content') }
    ]
  },
  testimonials: {
    label: bi('نظرات مشتریان', 'Testimonials'), group: 'trade', titleKey: 'name',
    fields: [
      { k: 'quote', t: 'bitext', label: bi('متن نظر', 'Quote'), req: true },
      { k: 'name', t: 'bi', label: bi('نام', 'Name') },
      { k: 'role', t: 'bi', label: bi('سمت', 'Role') },
      { k: 'company', t: 'bi', label: bi('شرکت', 'Company') },
      { k: 'demo', t: 'bool', label: bi('محتوای آزمایشی', 'Demo content') }
    ]
  },
  team: {
    label: bi('تیم', 'Team'), group: 'trade', titleKey: 'name', imageKey: 'photo',
    fields: [
      { k: 'name', t: 'bi', label: bi('نام', 'Name'), req: true },
      { k: 'role', t: 'bi', label: bi('سمت', 'Role') },
      { k: 'group', t: 'select', label: bi('گروه', 'Group'), opts: [
        { v: 'leadership', l: bi('هیئت رهبری', 'Leadership') }, { v: 'trade', l: bi('تیم تجارتی', 'Trade team') },
        { v: 'logistics', l: bi('لجستیک', 'Logistics') }, { v: 'support', l: bi('پشتیبانی', 'Support') }
      ] },
      { k: 'photo', t: 'image', label: bi('عکس', 'Photo') },
      { k: 'bio', t: 'bitext', label: bi('معرفی کوتاه', 'Short bio') },
      { k: 'message', t: 'bitext', label: bi('پیام', 'Message') },
      { k: 'demo', t: 'bool', label: bi('محتوای آزمایشی', 'Demo content') }
    ]
  },
  jobs: {
    label: bi('فرصت‌های شغلی', 'Jobs'), group: 'trade', titleKey: 'title',
    fields: [
      { k: 'title', t: 'bi', label: bi('عنوان بست', 'Job title'), req: true },
      { k: 'location', t: 'bi', label: bi('محل کار', 'Location') },
      { k: 'type', t: 'bi', label: bi('نوع همکاری', 'Type') },
      { k: 'deadline', t: 'date', label: bi('آخرین مهلت', 'Deadline') },
      { k: 'summary', t: 'bitext', label: bi('خلاصه', 'Summary') },
      { k: 'body', t: 'bitext', label: bi('شرح و شرایط', 'Duties & requirements') }
    ]
  },
  facts: {
    label: bi('آمار (در یک نگاه)', 'Facts'), group: 'trade', titleKey: 'label',
    fields: [
      { k: 'label', t: 'bi', label: bi('عنوان', 'Label'), req: true },
      { k: 'value', t: 'bi', label: bi('مقدار', 'Value'), req: true }
    ]
  }
}

export const COLLECTION_ORDER = [
  'products', 'categories', 'news', 'documents', 'gallery', 'faq', 'brands',
  'partners', 'projects', 'testimonials', 'team', 'jobs', 'facts'
]

/* settings schema: which keys get a structured form (rest → JSON editor) */
export const SETTINGS_FORMS = {
  company: ['name:bi', 'legal:bi', 'tagline:bi', 'summary:bitext', 'about:bitext', 'approach:bitext'],
  contact: ['phone:text', 'whatsapp:text', 'email:text', 'notifyEmail:text', 'address:bi', 'hours:bi',
    'facebook:text', 'instagram:text', 'linkedin:text', 'twitter:text', 'youtube:text', 'mapUrl:text'],
  hero: ['title:bi', 'text:bitext', 'image:image'],
  seo: ['title:bi', 'description:bitext']
}

/* human labels for settings fields (fa / en) */
export const FIELD_LABELS = {
  name: bi('نام', 'Name'), legal: bi('نام رسمی', 'Legal name'), tagline: bi('شعار کوتاه', 'Tagline'),
  summary: bi('خلاصهٔ معرفی', 'Summary'), about: bi('دربارهٔ شرکت', 'About'), approach: bi('رویکرد کاری', 'Approach'),
  phone: bi('تلفن', 'Phone'), whatsapp: bi('واتساپ', 'WhatsApp'), email: bi('ایمیل', 'Email'),
  notifyEmail: bi('ایمیل اطلاعیه‌ها', 'Notification email'), address: bi('آدرس', 'Address'), hours: bi('ساعات کاری', 'Office hours'),
  title: bi('عنوان', 'Title'), text: bi('متن', 'Text'), image: bi('تصویر', 'Image'),
  description: bi('توضیحات', 'Description'), intro: bi('معرفی', 'Intro'), body: bi('متن کامل', 'Full text'),
  points: bi('نکات کلیدی', 'Key points'), history: bi('تاریخچه', 'History'), mission: bi('رسالت', 'Mission'),
  vision: bi('چشم‌انداز', 'Vision'), values: bi('ارزش‌ها', 'Values'), structure: bi('ساختار', 'Structure'),
  sourcing: bi('تأمین بر اساس درخواست', 'Sourcing on request'), industries: bi('حوزه‌ها', 'Industries'),
  markets: bi('بازارها', 'Markets'), quality: bi('کنترل کیفیت', 'Quality control'),
  supplierPrinciples: bi('اصول انتخاب تأمین‌کننده', 'Supplier principles'),
  facebook: bi('فیسبوک (لینک)', 'Facebook (URL)'), instagram: bi('اینستاگرام (لینک)', 'Instagram (URL)'),
  linkedin: bi('لینکدین (لینک)', 'LinkedIn (URL)'), twitter: bi('ایکس/توییتر (لینک)', 'X/Twitter (URL)'),
  youtube: bi('یوتیوب (لینک)', 'YouTube (URL)'), mapUrl: bi('لینک نقشه (اختیاری)', 'Map link (optional)'),
  audience: bi('مخاطبان و مشتریان هدف', 'Target audience'), required: bi('معلومات موردنیاز برای آغاز', 'Information required to start'),
  registration: bi('معلومات ثبت و جواز (قابل انتشار)', 'Registration info (publishable)'), certifications: bi('گواهی‌نامه‌ها و عضویت‌ها', 'Certifications & memberships'),
  achievements: bi('دستاوردها', 'Achievements'), csr: bi('مسئولیت اجتماعی', 'Social responsibility'),
  relation: bi('نوع رابطه', 'Relation type'), field: bi('زمینهٔ فعالیت', 'Field'), market: bi('بازار', 'Market'),
  origin: bi('کشور مبدأ', 'Origin'), brand: bi('برند', 'Brand'), packaging: bi('بسته‌بندی', 'Packaging'),
  unit: bi('واحد عرضه', 'Supply unit'), moq: bi('حداقل سفارش', 'Min. order'), status: bi('وضعیت عرضه', 'Supply status'),
  source: bi('منبع', 'Source'), video: bi('ویدیو', 'Video'), poster: bi('پیش‌نمایش ویدیو', 'Video poster'),
  size: bi('حجم', 'Size'), lang: bi('زبان', 'Language'), updated: bi('به‌روزرسانی', 'Updated'),
  deadline: bi('آخرین مهلت', 'Deadline'), logo: bi('لوگو', 'Logo'), website: bi('وب‌سایت', 'Website'),
  fa: bi('دری', 'Dari'), en: bi('انگلیسی', 'English')
}

export const SETTINGS_LABELS = {
  company: bi('شرکت', 'Company'), contact: bi('تماس', 'Contact'), hero: bi('بخش اصلی (هیرو)', 'Hero'),
  seo: bi('سئو', 'SEO'), sections: bi('بخش‌های سایت', 'Site sections'), pages: bi('صفحات', 'Pages'),
  about: bi('درباره ما', 'About'), activities: bi('فعالیت‌ها', 'Activities')
}
