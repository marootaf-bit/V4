export const navigation = [
 {path:'/',fa:'خانه',en:'Home',children:[]},
 {path:'/about',fa:'دربارهٔ شرکت',en:'About',children:[
  {path:'/markets',fa:'بازارهای فعالیت',en:'Markets'},
  {path:'/partners',fa:'روابط تجارتی',en:'Trade relationships'}]},
 {path:'/products',fa:'محصولات',en:'Products',children:[]},
 {path:'/activities',fa:'خدمات تجارتی',en:'Trade services',children:[
  {path:'/sourcing',fa:'تأمین سفارشی کالا',en:'Custom sourcing'},
  {path:'/import',fa:'واردات به افغانستان',en:'Import to Afghanistan'},
  {path:'/export',fa:'صادرات از افغانستان',en:'Export from Afghanistan'},
  {path:'/domestic-trade',fa:'تجارت و تأمین داخلی',en:'Domestic trade'}]},
 {path:'/logistics',fa:'خدمات لوجستیکی',en:'Logistics',children:[
  {path:'/process',fa:'مراحل همکاری و درخواست',en:'How cooperation works'}]},
 {path:'/projects',fa:'پروژه‌ها',en:'Projects',children:[]},
 {path:'/news',fa:'اخبار و رسانه‌ها',en:'News & media',children:[
  {path:'/news?view=gallery',fa:'گالری عکس و ویدیو',en:'Photo & video gallery'},
  {path:'/downloads',fa:'دانلودها و کاتالوگ‌ها',en:'Downloads & catalogues'}]},
 {path:'/contact',fa:'تماس و درخواست',en:'Contact',children:[]},
]
export const labelOf = (item,lang) => item[lang === 'en' ? 'en' : 'fa']
export const normalizedPath = (path) => path.replace(/\/+$/, '').toLowerCase() || '/'
export function groupForPath(path) {
 const clean=normalizedPath(path)
 return navigation.find(item => item.path===clean || (item.path!=='/' && clean.startsWith(item.path+'/')) || item.children.some(child=>child.path.split('?')[0]===clean || clean.startsWith(child.path.split('?')[0]+'/')))
}
export const fixedPages = [...navigation.flatMap(item=>[item,...item.children.filter(child=>!child.path.includes('?'))]),
 {path:'/privacy',fa:'حریم خصوصی',en:'Privacy'}, {path:'/terms',fa:'شرایط استفاده',en:'Terms'}]
