import SiteContainer from './public/SiteContainer.jsx'

// Reserve the first screen while asynchronous company-page content loads.
export default function CompanyLoading({ lang = 'fa' }) {
  return <main id="main" className="tw-flex-1 tw-py-10" aria-busy="true"><span className="tw-sr-only" role="status">{lang === 'fa' ? 'در حال دریافت محتوا…' : 'Loading content…'}</span><div className="tw-h-56 tw-animate-pulse tw-bg-kb-paper sm:tw-h-72 motion-reduce:tw-animate-none" aria-hidden="true" /><SiteContainer className="tw-grid tw-gap-3 tw-py-7" aria-hidden="true"><span className="tw-h-5 tw-w-40 tw-animate-pulse tw-rounded tw-bg-kb-paper motion-reduce:tw-animate-none" /><span className="tw-h-4 tw-w-full tw-max-w-3xl tw-animate-pulse tw-rounded tw-bg-kb-paper motion-reduce:tw-animate-none" /><span className="tw-h-4 tw-w-2/3 tw-animate-pulse tw-rounded tw-bg-kb-paper motion-reduce:tw-animate-none" /></SiteContainer></main>
}
