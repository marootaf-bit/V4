import ContactMethodIcon from './ContactMethodIcon.jsx'
import SiteContainer from './SiteContainer.jsx'

export default function ContactChannels({ items = [], lang, t, intro = '' }) {
  const visibleItems = items.filter((item) => String(item.value ?? '').trim())
  if (!visibleItems.length && !intro) return null
  return <section className="tw-bg-kb-paper tw-py-8 sm:tw-py-10" aria-labelledby="contact-channels-title"><SiteContainer>
    {visibleItems.length > 0 && <>
      <h2 id="contact-channels-title" className="tw-mb-5 tw-font-head tw-text-2xl tw-font-bold tw-text-kb-navy">{t('ways')}</h2>
      <ul id="contact-ways" className="tw-grid tw-scroll-mt-28 tw-gap-3 sm:tw-grid-cols-2 lg:tw-grid-cols-2">{visibleItems.map((item) => <li className="tw-flex tw-min-h-20 tw-items-center tw-gap-3 tw-rounded-kb-lg tw-border tw-border-kb-line tw-bg-white tw-p-4" key={`${item.kind}-${item.label}`}><span className="tw-flex tw-h-10 tw-w-10 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-full tw-bg-white tw-text-kb-blue"><ContactMethodIcon kind={item.kind} /></span><div className="tw-min-w-0"><strong className="tw-block tw-text-xs tw-font-bold tw-text-kb-navy">{item.label}</strong>{item.href ? <a className="tw-mt-1 tw-block tw-break-words tw-text-sm tw-leading-5 tw-text-kb-blue hover:tw-underline focus-visible:tw-rounded-sm focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue" href={item.href} dir={item.dir} {...(item.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}>{item.value}</a> : <span className="tw-mt-1 tw-block tw-break-words tw-text-sm tw-leading-5 tw-text-kb-body" dir={item.dir}>{item.value}</span>}</div></li>)}</ul>
    </>}
    {intro && <p className="tw-mt-4 tw-max-w-3xl tw-text-sm tw-leading-7 tw-text-kb-body">{intro}</p>}
  </SiteContainer></section>
}
