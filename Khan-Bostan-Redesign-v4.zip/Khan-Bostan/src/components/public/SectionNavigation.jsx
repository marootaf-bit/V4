import { Link, useLocation } from 'react-router-dom'
import { usePublicDict } from '../../lib.jsx'
import { groupForPath, labelOf } from '../../content/navigation.js'
export default function SectionNavigation(){
 const {pathname,search}=useLocation(),{lang}=usePublicDict()
 const group=groupForPath(pathname)
 if(!group?.children.length)return null
 const items=[group,...group.children]
 return <nav className="kb-section-navigation" aria-label={lang==='fa'?'صفحه‌های این بخش':'Pages in this section'}><div className="kb-wrap"><span>{labelOf(group,lang)}</span>{items.map(item=><Link key={item.path} to={item.path} aria-current={pathname===item.path.split('?')[0] && (item.path.includes('?')?search.includes('view=gallery'):!search.includes('view=gallery'))?'page':undefined}>{labelOf(item,lang)}</Link>)}</div></nav>
}
