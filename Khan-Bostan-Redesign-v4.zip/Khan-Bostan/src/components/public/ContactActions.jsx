import { Link } from 'react-router-dom'
import { useContent } from '../../lib/store.jsx'
import { usePublicDict } from '../../lib.jsx'
export default function ContactActions({kind='contact',subject=''}){
 const {settings}=useContent(),{lang}=usePublicDict(),fa=lang==='fa'
 const contact=settings.contact??{},raw=String(contact.whatsapp??''),digits=raw.replace(/\D/g,'')
 const wa=!/[xX*•]/.test(raw)&&digits.length>=7&&digits.length<=15?`https://wa.me/${digits}?text=${encodeURIComponent(subject)}`:''
 const email=String(contact.email??'').trim()
 const query=new URLSearchParams({kind,subject})
 return <div className="kb-actions">{wa&&<a className="kb-text-link" href={wa} target="_blank" rel="noopener noreferrer">{fa?'گفتگو در واتساپ':'Chat on WhatsApp'} ↗</a>}{email&&<a className="kb-text-link" href={`mailto:${email}?subject=${encodeURIComponent(subject)}`}>{fa?'ارسال ایمیل':'Email us'} ↗</a>}<Link className="kb-text-link" to={`/contact?${query}`}>{fa?'فرم و سایر راه‌های تماس':'Form & other contact options'}</Link></div>
}
