export default function SiteContainer({ as: Element = 'div', className = '', children, ...props }) {
  const width = /(?:^|\s)tw-max-w-/.test(className) ? '' : 'tw-max-w-[1320px]'
  return <Element className={`tw-mx-auto tw-w-full ${width} tw-px-4 sm:tw-px-6 lg:tw-px-8 ${className}`.trim()} {...props}>{children}</Element>
}
