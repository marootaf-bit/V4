import { usePublicDict } from '../../lib.jsx'

export default function FaqList({ items = [], plus = false }) {
  const { L } = usePublicDict()
  const visibleItems = items.filter((item) => L(item.q) && L(item.a))
  if (!visibleItems.length) return null
  return <div className="tw-divide-y tw-divide-kb-line tw-border-y tw-border-kb-line">{visibleItems.map((item, index) => <details className="tw-group tw-py-4" key={item.id ?? index} open={index === 0}>
    <summary className="tw-flex tw-cursor-pointer tw-list-none tw-items-center tw-justify-between tw-gap-4 tw-text-start tw-font-bold tw-leading-7 tw-text-kb-ink marker:tw-hidden focus-visible:tw-rounded-kb focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{L(item.q)}<span className="tw-flex tw-h-8 tw-w-8 tw-shrink-0 tw-items-center tw-justify-center tw-rounded-full tw-border tw-border-kb-line tw-text-kb-blue" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M5 12h14" />{!plus && <path d="M12 5v14" />}</svg></span></summary>
    <div className="tw-max-w-3xl tw-pt-3 tw-text-sm tw-leading-7 tw-text-kb-body">{L(item.a)}</div>
  </details>)}</div>
}
