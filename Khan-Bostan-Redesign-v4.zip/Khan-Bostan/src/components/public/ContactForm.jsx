import { useState } from 'react'
import { Link } from 'react-router-dom'
import ContactMethodIcon from './ContactMethodIcon.jsx'

const KIND_OPTIONS = [
  ['contact', 'kind_general'],
  ['product', 'kind_product'],
  ['cooperation', 'kind_partner'],
  ['sourcing', 'kind_sourcing'],
  ['logistics', 'kind_logistics'],
  ['consultation', 'kind_consultation'],
]

export default function ContactForm({ email, initialKind = 'contact', initialSubject = '', initialProductName = '', lang, t, variant = 'full' }) {
  const compact = variant === 'home'
  const recipient = String(email ?? '').trim()
  const canSubmit = Boolean(recipient)
  const safeInitialKind = KIND_OPTIONS.some(([value]) => value === initialKind) ? initialKind : 'contact'
  const [form, setForm] = useState({ kind: safeInitialKind, name: '', company: '', phone: '', email: '', subject: initialSubject, msg: '', productName: String(initialProductName ?? '').slice(0, 180), productQuantity: '', productDestination: '', productOrigin: '', productSpecifications: '' })
  const [errors, setErrors] = useState({})
  const [sent, setSent] = useState(false)
  const validateField = (key, value) => {
    const text = String(value ?? '').trim()
    if (key === 'name' && !text) return lang === 'fa' ? 'نام خود را بنویسید.' : 'Please enter your name.'
    if (key === 'phone') {
      if (!text) return lang === 'fa' ? 'شمارهٔ تماس را بنویسید.' : 'Please enter your phone number.'
      const normalized = text.replace(/[\u0660-\u0669\u06F0-\u06F9]/g, (digit) => String(digit.charCodeAt(0) >= 0x06F0 ? digit.charCodeAt(0) - 0x06F0 : digit.charCodeAt(0) - 0x0660))
      const digitCount = (normalized.match(/[0-9]/g) ?? []).length
      if (!/^\+?[0-9][0-9\s().-]*[0-9]$/.test(normalized) || digitCount < 7 || digitCount > 15) return lang === 'fa' ? 'شمارهٔ معتبر با ۷ تا ۱۵ رقم وارد کنید.' : 'Enter a valid phone number with 7 to 15 digits.'
    }
    if (key === 'email' && text && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(text)) return lang === 'fa' ? 'نشانی ایمیل معتبر نیست.' : 'That email address looks invalid.'
    if (key === 'msg' && !compact && !text) return lang === 'fa' ? 'متن پیام را بنویسید.' : 'Please enter your message.'
    if (['product', 'sourcing', 'logistics'].includes(form.kind) && ['productName', 'productQuantity', 'productDestination'].includes(key) && !text) {
      const messages = {
        productName: lang === 'fa' ? 'نام کالا را بنویسید.' : 'Please enter the product or goods.',
        productQuantity: lang === 'fa' ? 'مقدار موردنیاز را بنویسید.' : 'Please enter the required quantity.',
        productDestination: lang === 'fa' ? 'مقصد را بنویسید.' : 'Please enter the destination.',
      }
      return messages[key]
    }
    return ''
  }
  const setField = (key) => (event) => {
    const value = event.target.value
    setForm((current) => ({ ...current, [key]: value }))
    setErrors((current) => {
      if (!Object.hasOwn(current, key)) return current
      const error = validateField(key, value)
      const next = { ...current }
      if (error) next[key] = error
      else delete next[key]
      return next
    })
  }
  const kindLabel = t(KIND_OPTIONS.find(([value]) => value === form.kind)?.[1] ?? 'kind_general')

  const onSubmit = (event) => {
    event.preventDefault()
    const next = {}
    const fieldsToValidate = ['name', 'phone', 'email', 'msg', ...(['product', 'sourcing', 'logistics'].includes(form.kind) ? ['productName', 'productQuantity', 'productDestination'] : [])]
    for (const key of fieldsToValidate) {
      const error = validateField(key, form[key])
      if (error) next[key] = error
    }
    setErrors(next)
    if (Object.keys(next).length) return
    if (!recipient) return
    const subject = `[${kindLabel}] ${form.subject.trim() || (lang === 'fa' ? 'پیام از وبسایت' : 'Website message')}`
    const quoteDetails = ['product', 'sourcing', 'logistics'].includes(form.kind) ? [
      [lang === 'fa' ? 'کالا' : 'Goods', form.productName],
      [lang === 'fa' ? 'مقدار' : 'Quantity', form.productQuantity],
      [lang === 'fa' ? 'مقصد' : 'Destination', form.productDestination],
      [lang === 'fa' ? 'مبدأ پیشنهادی' : 'Preferred origin', form.productOrigin],
      [lang === 'fa' ? 'مشخصات' : 'Specifications', form.productSpecifications],
    ].filter(([, value]) => String(value ?? '').trim()).map(([label, value]) => `${label}: ${String(value).trim()}`) : []
    const body = [form.msg.trim(), ...quoteDetails, '', '—', `${t('name')}: ${form.name.trim()}`, form.company.trim() && `${t('company_l')}: ${form.company.trim()}`, form.phone.trim() && `${t('phone_l')}: ${form.phone.trim()}`, form.email.trim() && `${t('email_l')}: ${form.email.trim()}`].filter(Boolean).join('\n')
    window.location.href = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    setSent(true)
  }

  const fieldClass = 'tw-min-h-11 tw-w-full tw-rounded-kb tw-border tw-border-kb-control tw-bg-white tw-px-3 tw-py-2 tw-text-sm tw-text-kb-ink tw-outline-none placeholder:tw-text-kb-muted focus:tw-border-kb-blue focus:tw-ring-2 focus:tw-ring-kb-blue/20'
  const labelClass = 'tw-mb-1.5 tw-block tw-text-xs tw-font-bold tw-text-kb-body'
  const requiredMark = lang === 'fa' ? ' *' : ' *'

  return <section className="kb-contact-form-open" aria-labelledby={compact ? undefined : 'contact-form-title'} aria-label={compact ? t('form_title') : undefined}>
    {!compact && <h2 id="contact-form-title" className="tw-text-xl tw-font-bold tw-text-kb-navy">{t('form_title')}</h2>}
    <p className={`${compact ? 'tw-mb-4' : 'tw-mt-2'} tw-text-sm tw-leading-6 tw-text-kb-muted`}>{t('form_note')}</p>
    <form className={compact ? '' : 'tw-mt-5'} noValidate onSubmit={onSubmit}>
      <fieldset>
        <legend className="tw-sr-only">{t('form_title')}</legend>

        <div className="tw-grid tw-gap-4 sm:tw-grid-cols-2">
          {!compact && <fieldset className="tw-min-w-0 tw-border-0 tw-p-0 sm:tw-col-span-2">
            <legend className={labelClass}>{t('kind')}</legend>
            <div className="tw-flex tw-flex-wrap tw-gap-2" role="group" aria-label={t('kind')}>
              {KIND_OPTIONS.map(([value, key]) => <button type="button" key={value} aria-pressed={form.kind === value} onClick={() => setForm((current) => ({ ...current, kind: value }))} className={`tw-inline-flex tw-min-h-10 tw-items-center tw-justify-center tw-rounded-full tw-border tw-px-4 tw-text-xs tw-font-bold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue ${form.kind === value ? 'tw-border-kb-blue tw-bg-kb-blue tw-text-white' : 'tw-border-kb-control tw-bg-white tw-text-kb-body hover:tw-border-kb-blue hover:tw-text-kb-blue'}`}>{t(key)}</button>)}
            </div>
          </fieldset>}
          <div>
            <label className={labelClass} htmlFor="f-name">{t('name')}{requiredMark}</label>
            <input id="f-name" className={fieldClass} placeholder={t('name_ph')} value={form.name} onChange={setField('name')} required aria-invalid={!!errors.name} aria-describedby={errors.name ? 'e-name' : undefined} />
            {errors.name && <p id="e-name" role="alert" className="tw-mt-1 tw-text-xs tw-text-[#A33C32]">{errors.name}</p>}
          </div>
          {!compact && <div>
            <label className={labelClass} htmlFor="f-company">{t('company_l')}</label>
            <input id="f-company" className={fieldClass} value={form.company} onChange={setField('company')} />
          </div>}
          <div>
            <label className={labelClass} htmlFor="f-phone">{t('phone_l')}{requiredMark}</label>
            <input id="f-phone" type="tel" inputMode="tel" autoComplete="tel" className={fieldClass} dir="ltr" style={{ textAlign: 'end' }} placeholder={t('phone_ph')} value={form.phone} onChange={setField('phone')} required aria-invalid={!!errors.phone} aria-describedby={errors.phone ? 'e-phone' : undefined} />
            {errors.phone && <p id="e-phone" role="alert" className="tw-mt-1 tw-text-xs tw-text-[#A33C32]">{errors.phone}</p>}
          </div>
          <div>
            <label className={labelClass} htmlFor="f-email">{t('email_l')}</label>
            <input id="f-email" type="email" className={fieldClass} dir="ltr" style={{ textAlign: 'end' }} placeholder={compact ? t('email_ph') : undefined} value={form.email} onChange={setField('email')} aria-invalid={!!errors.email} aria-describedby={errors.email ? 'e-email' : undefined} />
            {errors.email && <p id="e-email" role="alert" className="tw-mt-1 tw-text-xs tw-text-[#A33C32]">{errors.email}</p>}
          </div>
          {!compact && <div className="sm:tw-col-span-2">
            <label className={labelClass} htmlFor="f-subject">{t('subject_l')}</label>
            <input id="f-subject" className={fieldClass} value={form.subject} onChange={setField('subject')} />
          </div>}
          {!compact && ['product', 'sourcing', 'logistics'].includes(form.kind) && <fieldset className="tw-min-w-0 tw-border-0 tw-p-0 sm:tw-col-span-2">
            <legend className={labelClass}>{lang === 'fa' ? 'مشخصات کالا و مسیر درخواست' : 'Goods and route details'}</legend>
            <p className="tw-mb-3 tw-text-xs tw-leading-5 tw-text-kb-muted">{lang === 'fa' ? 'نام کالا، مقدار و مقصد برای آغاز بررسی لازم است؛ موارد دیگر را در صورت دانستن تکمیل کنید.' : 'Goods, quantity and destination are needed to start a review; complete the other fields if known.'}</p>
            <div className="tw-grid tw-gap-4 sm:tw-grid-cols-2">
              {[
                { key: 'productName', fa: 'نام کالا', en: 'Product or goods', required: true, maxLength: 180 },
                { key: 'productQuantity', fa: 'مقدار موردنیاز', en: 'Required quantity', required: true, maxLength: 120 },
                { key: 'productDestination', fa: 'مقصد (کشور یا شهر)', en: 'Destination (country or city)', required: true, maxLength: 120 },
                { key: 'productOrigin', fa: 'مبدأ کالا، اگر معلوم است', en: 'Origin of goods, if known', maxLength: 120 },
                { key: 'productSpecifications', fa: 'مشخصات، درجه یا بسته‌بندی', en: 'Specifications, grade or packaging', multiline: true, maxLength: 500, full: true },
              ].map((item) => <div key={item.key} className={item.full ? 'sm:tw-col-span-2' : ''}>
                <label className={labelClass} htmlFor={`f-${item.key}`}>{lang === 'fa' ? item.fa : item.en}{item.required ? requiredMark : ''}</label>
                {item.multiline
                  ? <textarea id={`f-${item.key}`} className={`${fieldClass} tw-min-h-24 tw-resize-y`} rows="3" maxLength={item.maxLength} value={form[item.key]} onChange={setField(item.key)} aria-invalid={!!errors[item.key]} aria-describedby={errors[item.key] ? `e-${item.key}` : undefined} />
                  : <input id={`f-${item.key}`} className={fieldClass} maxLength={item.maxLength} value={form[item.key]} onChange={setField(item.key)} required={!!item.required} aria-invalid={!!errors[item.key]} aria-describedby={errors[item.key] ? `e-${item.key}` : undefined} />}
                {errors[item.key] && <p id={`e-${item.key}`} role="alert" className="tw-mt-1 tw-text-xs tw-text-[#A33C32]">{errors[item.key]}</p>}
              </div>)}
            </div>
          </fieldset>}
          <div className="sm:tw-col-span-2">
            <label className={labelClass} htmlFor="f-msg">{t('message_l')}{!compact && requiredMark}</label>
            <textarea id="f-msg" className={`${fieldClass} tw-min-h-32 tw-resize-y`} rows="5" placeholder={t('message_ph')} value={form.msg} onChange={setField('msg')} required={!compact} aria-invalid={!!errors.msg} aria-describedby={errors.msg ? 'e-msg' : undefined} />
            {errors.msg && <p id="e-msg" role="alert" className="tw-mt-1 tw-text-xs tw-text-[#A33C32]">{errors.msg}</p>}
          </div>
        </div>
        <button type="submit" disabled={!canSubmit} className="tw-mt-5 tw-inline-flex tw-min-h-11 tw-items-center tw-gap-2 tw-rounded-kb tw-bg-kb-gold tw-px-5 tw-text-sm tw-font-bold tw-text-kb-navy hover:tw-bg-kb-navy hover:tw-text-white disabled:tw-cursor-not-allowed disabled:tw-opacity-60 disabled:hover:tw-bg-kb-gold focus-visible:tw-outline-none focus-visible:tw-ring-2 focus-visible:tw-ring-kb-blue">{t('send')}<ContactMethodIcon kind="external" /></button>
        {sent && <p role="status" className="tw-mt-3 tw-rounded-kb tw-bg-kb-paper tw-p-3 tw-text-xs tw-leading-5 tw-text-kb-body">{lang === 'fa' ? 'برنامهٔ ایمیل با پیام آماده باز شد؛ آن را ارسال کنید. اگر باز نشد، مستقیماً ایمیل بزنید.' : 'Your email app opened with the message ready — press send there. If it did not open, email us directly.'}</p>}
      </fieldset>
    </form>
    <p className="tw-mt-5 tw-border-t tw-border-kb-line tw-pt-4 tw-text-[11px] tw-leading-5 tw-text-kb-muted">{lang === 'fa' ? 'این فورم برنامهٔ ایمیل شما را با پیش‌نویس باز می‌کند؛ وب‌سایت معلومات را ارسال یا ذخیره نمی‌کند. برای فرستادن پیام، خودتان در برنامهٔ ایمیل «ارسال» را بزنید.' : 'This form opens an email draft in your email app; this site does not send or store the details. Press Send in your email app to deliver the message.'}{!compact && <> <Link className="tw-font-bold tw-text-kb-blue hover:tw-underline" to="/privacy">{t('nav_privacy')}</Link></>}</p>
  </section>
}
