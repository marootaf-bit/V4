import { Link } from 'react-router-dom'
import { usePublicDict } from '../../lib.jsx'
import HeroSnapshot from './HeroSnapshot.jsx'

export default function Hero({ image, showImage = true, showSnapshot = false, crumbs = [], title, sub, children }) {
  const { t, lang } = usePublicDict()
  return <><section className="kb-page-hero" aria-labelledby="public-page-title"><div className="kb-wrap kb-page-hero-layout"><div>
    <nav className="kb-breadcrumb" aria-label={lang === 'fa' ? 'مسیر صفحه' : 'Breadcrumb'}><Link to="/">{t('home')}</Link>{crumbs.map(([to,label],index)=><span className="tw-inline-flex tw-items-center tw-gap-2" key={index}><span aria-hidden="true">/</span>{to?<Link to={to}>{label}</Link>:<span aria-current={index===crumbs.length-1?'page':undefined}>{label}</span>}</span>)}</nav>
    <h1 id="public-page-title">{title}</h1>{sub&&<p>{sub}</p>}{children&&<div className="kb-page-actions">{children}</div>}
    </div>{showImage&&<img className="kb-page-hero-image" src={image||'/images/hero-trade.webp'} alt="" width="600" height="400" fetchpriority="high"/>}</div></section>{showSnapshot&&<HeroSnapshot/>}</>
}
