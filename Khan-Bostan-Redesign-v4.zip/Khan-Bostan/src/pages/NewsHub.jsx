import { lazy, Suspense } from 'react'
import { useSearchParams } from 'react-router-dom'
import PublicLoading from '../components/public/PublicLoading.jsx'
const News=lazy(()=>import('./News.jsx'))
const Gallery=lazy(()=>import('./Gallery.jsx'))
export default function NewsHub(){const [params]=useSearchParams();return <Suspense fallback={<PublicLoading/>}>{params.get('view')==='gallery'?<Gallery/>:<News/>}</Suspense>}
