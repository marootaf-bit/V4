import { Link, useParams } from 'react-router-dom'
import { useContent } from '../lib/store.jsx'
import { usePublicDict, publicSlug, publicItemName } from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import NotFoundCompact from './NotFoundCompact.jsx'
import ContactActions from '../components/public/ContactActions.jsx'
export default function ProjectDetail(){
 const {slug}=useParams(),{data}=useContent(),{L,lang}=usePublicDict(),fa=lang==='fa'
 const project=(data?.projects??[]).find(item=>item.id===slug||publicSlug(item.id)===slug)
 if(!project)return <NotFoundCompact/>
 const title=publicItemName(L(project.title))
 const fields=fa?[['نیاز مشتری','need'],['نقش خان بوستان','action'],['نتیجهٔ همکاری','result']]:[['Client need','need'],['Khan Bostan’s role','action'],['Outcome','result']]
 return <main id="main" className="tw-flex-1"><Hero title={title} sub={[L(project.sector),project.year,L(project.market)].filter(Boolean).join(' · ')} image={project.image} crumbs={[["/projects",fa?'پروژه‌ها':'Projects'],[null,title]]}/><section className="kb-section"><div className="kb-wrap"><div className="kb-business-grid">{fields.filter(([,key])=>L(project[key])).map(([label,key])=><article className="kb-business-card" key={key}><h2>{label}</h2><p>{L(project[key])}</p></article>)}</div><div className="kb-actions"><Link className="kb-text-link" to="/projects">{fa?'بازگشت به پروژه‌ها':'Back to projects'}</Link></div></div></section><div className="kb-wrap kb-business-cta"><h2>{fa?'درخواست مشابهی دارید؟':'Have a similar requirement?'}</h2><ContactActions kind="cooperation" subject={title}/></div></main>
}
