import { Navigate } from 'react-router-dom'
import { useContent } from '../../src/lib/store.jsx'
import { usePublicDict, publicRecords } from '../lib.jsx'
import CompanyLoading from '../components/CompanyLoading.jsx'

export default function TeamRedirect() {
  const { data, settings } = useContent()
  const { lang } = usePublicDict()
  if (!data) return <CompanyLoading lang={lang} />
  const hasTeam = settings.sections?.showTeam !== false && publicRecords(data.team ?? []).length > 0
  return <Navigate replace to={hasTeam ? '/about#team' : '/about'} />
}
