import { usePublicDict } from '../lib.jsx'
import PrimaryLink from '../components/public/PrimaryLink.jsx'

export default function NotFoundCompact() {
  const { t } = usePublicDict()
  return <main id="main" className="tw-grid tw-min-h-[50vh] tw-flex-1 tw-place-items-center tw-px-4 tw-py-12 tw-text-center sm:tw-px-6"><div><h1 className="tw-mb-3 tw-font-head tw-text-3xl tw-font-bold tw-text-kb-navy">{t('notfound_t')}</h1><p className="tw-mb-6 tw-text-sm tw-leading-6 tw-text-kb-muted">{t('notfound_d')}</p><PrimaryLink to="/">{t('back_home')}</PrimaryLink></div></main>
}
