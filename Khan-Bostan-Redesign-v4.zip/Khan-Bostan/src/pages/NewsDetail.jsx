import {Link,useParams} from 'react-router-dom'
import {useContent} from '../lib/store.jsx'
import {usePublicDict} from '../lib.jsx'
import Hero from '../components/public/Hero.jsx'
import NotFoundCompact from './NotFoundCompact.jsx'
import ContactActions from '../components/public/ContactActions.jsx'
export default function NewsDetail(){const {slug}=useParams(),{data}=useContent(),{lang,L}=usePublicDict(),fa=lang!=='en',p=data.news.find(x=>x.id===slug);if(!p)return <NotFoundCompact/>;return <main id="main" className="v3-editorial"><Hero title={L(p.title)} sub={L(p.summary)} showImage={false} crumbs={[["/news",fa?'راهنماها و رسانه‌ها':'Guides & media'],[null,L(p.title)]]}/><section className="v3-section v3-intro-grid"><aside className="v3-rail"><b>{fa?'راهنمای همکاری':'Cooperation guide'}</b><Link to="/sourcing">{fa?'تأمین سفارشی':'Custom sourcing'}</Link><Link to="/logistics">{fa?'لوجستیک':'Logistics'}</Link><Link to="/process">{fa?'مراحل همکاری':'Process'}</Link></aside><article className="v3-prose">{L(p.body).split('\n\n').map(t=><p key={t}>{t}</p>)}<h2>{fa?'درخواست خود را مطرح کنید':'Share your requirement'}</h2><ContactActions subject={L(p.title)}/></article></section></main>}
