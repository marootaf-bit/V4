import { navigation, labelOf } from '../content/navigation.js'
import { Link } from 'react-router-dom'
import { useContent } from '../lib/store.jsx'
import { usePublicDict } from '../lib.jsx'

export default function Footer() {
 const {settings}=useContent()
 const {lang,L,t}=usePublicDict()
 const fa=lang==='fa'
 const main=navigation.map(item=>[item.path,labelOf(item,lang)])
 const more=navigation.flatMap(item=>item.children.map(child=>[child.path,labelOf(child,lang)]))
 return <footer className="kb-footer"><div className="kb-wrap"><div className="kb-footer-grid"><div><Link to="/" className="kb-footer-brand"><img src="/brand/khan-boostan-official.png" alt="" width="76" height="76"/><span><b>{L(settings.company?.name)}</b><small>{fa?'تجارت جهانی | آینده بهتر':'Global Trade | Better Future'}</small></span></Link><p>{fa?'با هم، به سوی آینده‌ای بهتر. برای گفتگو دربارهٔ نیاز بازار و فرصت‌های همکاری با ما در تماس باشید.':'Together towards a better future. Talk to us about your market needs and opportunities for cooperation.'}</p></div><nav aria-label={fa?'پیوندهای اصلی':'Footer navigation'}><h3>{fa?'شناخت خان بوستان':'Explore Khan Bostan'}</h3><ul>{main.map(([to,label])=><li key={to}><Link to={to}>{label}</Link></li>)}</ul></nav><nav aria-label={fa?'منابع و همکاری':'Resources and cooperation'}><h3>{fa?'منابع و همکاری':'Resources & cooperation'}</h3><ul>{more.map(([to,label])=><li key={to}><Link to={to}>{label}</Link></li>)}</ul></nav></div><div className="kb-footer-bottom"><span>© {new Date().getFullYear()} {L(settings.company?.name)}</span><div><Link to="/privacy">{t('nav_privacy')}</Link><Link to="/terms">{t('nav_terms')}</Link></div></div></div></footer>
}
